#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
qa_sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:?Android SDK not configured}}"
tools="$qa_sdk_root/build-tools/35.0.0"
android_jar="$qa_sdk_root/platforms/android-35/android.jar"
build='.qa-android-vib/provider'
mkdir -p "$build/classes" "$build/dex" "$build/assets"
cp .qa-android-vib/game/game.html "$build/assets/game.html"
javac -source 8 -target 8 -classpath "$android_jar" -d "$build/classes" android-vib/provider/*.java
mapfile -t classes < <(find "$build/classes" -name '*.class' -type f)
"$tools/d8" --min-api 26 --lib "$android_jar" --output "$build/dex" "${classes[@]}"
"$tools/aapt" package -f -M android-vib/provider/AndroidManifest.xml -I "$android_jar" -A "$build/assets" -F "$build/unsigned.apk"
zip -j "$build/unsigned.apk" "$build/dex/classes.dex"
keytool -genkeypair -noprompt -keystore "$build/debug.keystore" -storepass android -keypass android \
  -alias androiddebugkey -dname 'CN=Ephemeral Emulator QA' -keyalg RSA -validity 2
"$tools/zipalign" -f 4 "$build/unsigned.apk" "$build/aligned.apk"
"$tools/apksigner" sign --ks "$build/debug.keystore" --ks-pass pass:android --out "$build/uri-provider.apk" "$build/aligned.apk"
"$tools/apksigner" verify "$build/uri-provider.apk"
python3 - <<'PY'
import hashlib,zipfile
from pathlib import Path
with zipfile.ZipFile('.qa-android-vib/provider/uri-provider.apk') as archive:
    digest=hashlib.sha256(archive.read('assets/game.html')).hexdigest()
assert digest=='98033fbebc8c5fefafdaa2d8e07e41faee25d5fc9681a132077b6417a9f75b87'
print('PASS content provider APK contains the exact unchanged production HTML',digest)
PY
