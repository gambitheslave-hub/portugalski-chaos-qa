# ETAP VI.B — Android emulator QA 0.4.1

Ten pakiet jest nową, oddzielną infrastrukturą. Nie modyfikuje wydanego HTML,
archiwów, workflow Chromium, R12 ani dotychczasowej historii. Oba istniejące
archiwa są sprawdzane po SHA-256, a HTML jest kopiowany do izolowanego katalogu
QA. HTTP serwuje dokładnie te bajty. To nie jest WebView ani desktopowa
emulacja widoku telefonu: Playwright Android steruje rzeczywistą aplikacją
Chrome w uruchomionym AVD.

## Zakres i dowody

`scenarios.json` opisuje A01–A08 dla HTTP, A09 dla Android `file://`, A10 dla
Android `content://` oraz P01 dla telefonu fizycznego (zawsze NOT RUN w tym jobie).
PASS jest nadawany dopiero po wykonaniu asercji. Brak Chrome, AVD, uprawnień
URI, DownloadManager lub obsługi DocumentsUI daje BLOCKED z przyczyną.
Niezgodność zatwierdzonych danych albo nieskuteczna ochrona szkicu daje FAIL.

Restart oznacza `am force-stop com.android.chrome`, potwierdzenie braku PID
i uruchomienie nowego procesu. Profil Chrome pozostaje ten sam. Nie ma
`pm clear`, kasowania IndexedDB, migracji, fake-indexeddb ani adaptera pamięci.
Do importu używa się pustego drugiego originu HTTP, nie wyczyszczonej bazy.
Controlled abort w A08 dotyczy prawdziwej transakcji IndexedDB w nowym profilu
QA; źródła i plik HTML nie są edytowane.

Eksport musi pojawić się w `/sdcard/Download`, zostać pobrany przez adb i
zgadzać z natywnym stanem oraz dziennikiem. Zdarzenie download albo samo
wygenerowanie Blob nie wystarcza. Import wybiera faktyczny plik w natywnym
Android DocumentsUI; nie zastępuje importu bezpośrednim zapisem do IndexedDB.
Automatyzacja selektorów DocumentsUI może nie działać w konkretnym obrazie —
wtedy raportuje BLOCKED i zachowuje screenshot.

A09 kopiuje HTML przez adb bez zmiany bajtów, sprawdza SHA na emulatorze
i próbuje nawigacji `file:///sdcard/Download/CHAOS_041_QA.html`.
A10 buduje mały podpisany debug APK z read-only ContentProvider i Activity,
która udziela Chrome rzeczywistego `FLAG_GRANT_READ_URI_PERMISSION`.
APK zawiera identyczny HTML jako asset, bez mechaniki gry. Jest instalowany
wyłącznie po potwierdzeniu `ro.kernel.qemu=1` na izolowanym emulatorze.
Nie włącza się `--disable-web-security` ani flag omijających politykę URI.
HTTP, file i content mają osobne wyniki; emulator nie dowodzi zachowania
na fizycznym telefonie ani retencji 24 h.

## Konfiguracja

- GitHub-hosted Ubuntu 24.04; KVM; nowy AVD bez snapshotów i z `-wipe-data`.
- Android API 35, `google_apis_playstore`, x86_64, profil Pixel 6.
- Rzeczywisty Chrome z obrazu AVD; wersja zapisywana z `dumpsys package`.
  Brak preinstalowanego Chrome daje BLOCKED, bez pobierania przypadkowego APK.
- Node.js 24, Playwright 1.62.0, Python 3.12, Java 17, build-tools 35.0.0.
- Uprawnienia workflow: `contents: read`, `actions: read`; brak własnych sekretów.
  Automatyczny `GITHUB_TOKEN` służy wyłącznie do odczytu wcześniejszego runu.
- Warunek wejścia: run 39174216484 ma `completed/success` i znany commit.
- HTTP: stałe originy `http://127.0.0.1:8765` oraz `:8766` przez `adb reverse`.
- Artifact `android-vib-<run>-<attempt>`, 30 dni: JSON, CSV, Markdown, trace,
  screenshots strony i ekranu emulatora, surowe object stores, pliki eksportu,
  PID, logcat, activity, logi SDK i builda pomocniczego APK.

## Pierwsze wykonanie

Workflow `.github/workflows/android-emulator-041-vib.yml` jest oddzielny od
zaliczonego desktopowego workflow. Uruchamia się przy push na gałąź QA, PR
oraz ręcznie, gdy GitHub udostępni `workflow_dispatch` dla tego pliku.
Pierwsze push/PR nie wymaga modyfikacji main. Kod jest nowy i wymaga wykonania
na runnerze; kontrola składni i gotowy YAML nie certyfikują Androida.
