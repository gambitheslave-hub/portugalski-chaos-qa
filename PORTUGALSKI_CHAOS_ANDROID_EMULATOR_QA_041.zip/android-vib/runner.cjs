'use strict';
// Run only on a disposable real AVD. No storage shim, game modification or profile clearing.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const crypto=require('node:crypto'),assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process');
const {_android}=require('playwright');
const {expect: baseExpect}=require('@playwright/test');
const expect=baseExpect.configure({timeout:20000});
const ROOT=path.resolve(__dirname,'..');
const OUT=path.resolve(process.env.QA_OUTPUT || path.join(ROOT,'.qa-android-vib/results'));
fs.mkdirSync(OUT,{recursive:true});
const scenarios=require('./scenarios.json');
const report={environment:{platform:'REAL ANDROID EMULATOR, NOT PHYSICAL PHONE',
  run_id:process.env.GITHUB_RUN_ID || null,run_attempt:process.env.GITHUB_RUN_ATTEMPT || null,
  commit_sha:process.env.QA_HEAD_SHA || process.env.GITHUB_SHA || null,
  branch:process.env.GITHUB_HEAD_REF || process.env.GITHUB_REF_NAME || null,
  run_url:process.env.GITHUB_RUN_ID?`https://github.com/${process.env.GITHUB_REPOSITORY}/actions/runs/${process.env.GITHUB_RUN_ID}`:null,
  host_system:execFileSync('uname',['-a'],{encoding:'utf8'}).trim(),
  host_os:fs.readFileSync('/etc/os-release','utf8'),node:process.version,playwright:require('playwright/package.json').version,
  html_sha256:null,physical_phone:false},
  results:scenarios.map(s=>({...s,status:'NOT RUN',actual:'Case not reached',native_indexeddb:false,evidence:[]}))};
const write=(file,data)=>fs.writeFileSync(file,JSON.stringify(data,null,2)+'\n');
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const row=id=>report.results.find(r=>r.id===id);
let device,context,page,serial,session=0,serverA,serverB,exported,committed,traceActive=false;
const logs=[],processes=[];
let activeCase;
class Blocked extends Error {}
const adb=(...args)=>execFileSync('adb',[...(serial?['-s',serial]:[]),...args],{encoding:'utf8',timeout:30000}).trim();
const save=()=>write(path.join(OUT,'android-results.json'),report);
const RAW=async()=>{
  const db=await new Promise((ok,fail)=>{const r=indexedDB.open('portugalski_chaos_foundation_v0_4_ODDZIELNA');r.onsuccess=()=>ok(r.result);r.onerror=()=>fail(r.error);});
  try{return await new Promise((ok,fail)=>{
    const tx=db.transaction(['kv','events'],'readonly'),k=tx.objectStore('kv').getAllKeys(),v=tx.objectStore('kv').getAll(),e=tx.objectStore('events').getAll();
    tx.oncomplete=()=>ok({kv:k.result.map((key,i)=>({key,value:v.result[i]})),events:e.result});tx.onabort=()=>fail(tx.error);
  });}finally{db.close();}
};
const BACKUP=async()=>{const db=await ChaosStorage04.open();try{const b=await ChaosStorage04.backup(db);ChaosEngine04.validateBackup(b);return b;}finally{db.close();}};
async function snapshot(label){
  const data=await page.evaluate(RAW),backup=await page.evaluate(BACKUP);
  assert.equal(backup.state.revision,data.events.length);assert.deepEqual(backup.events,data.events);
  if(data.kv.length) assert.deepEqual(data.kv,[{key:'state',value:backup.state}]);
  row(activeCase).native_indexeddb=true;
  write(path.join(OUT,`${activeCase}-${label}.json`),{raw:data,backup});return {raw:data,backup};
}
function instrument(p){
  p.on('console',m=>logs.push({case:activeCase,type:m.type(),text:m.text()}));
  p.on('pageerror',e=>{logs.push({case:activeCase,type:'pageerror',text:String(e)});});
}
async function screenshot(label){
  if(page && !page.isClosed()) await page.screenshot({path:path.join(OUT,`${activeCase}-${label}-page.png`),fullPage:true}).catch(e=>logs.push({case:activeCase,screenshot_error:String(e)}));
  if(device) await device.screenshot({path:path.join(OUT,`${activeCase}-${label}-device.png`)}).catch(e=>logs.push({case:activeCase,screenshot_error:String(e)}));
}
async function stopTrace(){
  if(context && traceActive){await context.tracing.stop({path:path.join(OUT,`${activeCase}-session-${session}.trace.zip`)});traceActive=false;}
}
async function launch(url='http://127.0.0.1:8765/game.html'){
  assert(!context);context=await device.launchBrowser({pkg:'com.android.chrome'});
  // Android's DownloadManager, not host-side saveAs, must produce the export proof.
  context.setDefaultTimeout(20000);await context.tracing.start({screenshots:true,snapshots:true,sources:true});traceActive=true;session++;
  page=await context.newPage();instrument(page);const response=await page.goto(url,{waitUntil:'domcontentloaded'});
  assert(response && response.ok());assert.equal(hash(await response.body()),'98033fbebc8c5fefafdaa2d8e07e41faee25d5fc9681a132077b6417a9f75b87');
  await page.waitForFunction(()=>window.ChaosStorage04 && document.querySelector('#save-state').textContent==='Dziennik odczytany.');
  const native=await page.evaluate(()=>({factory:Object.prototype.toString.call(indexedDB),open:Function.prototype.toString.call(IDBFactory.prototype.open),name:ChaosStorage04.NAME,origin:location.origin,user_agent:navigator.userAgent}));
  assert.equal(native.factory,'[object IDBFactory]');assert(native.open.includes('[native code]'));assert.equal(native.name,'portugalski_chaos_foundation_v0_4_ODDZIELNA');
  logs.push({case:activeCase,native});row(activeCase).native_indexeddb=true;
  return page;
}
async function forceStop(){
  const before=adb('shell','pidof','com.android.chrome');assert(before,'Chrome process not found');
  await screenshot('before-force-stop');await stopTrace();
  adb('shell','am','force-stop','com.android.chrome');
  let remaining='';for(let i=0;i<40;i++){remaining=adb('shell','sh','-c','pidof com.android.chrome || true');if(!remaining)break;await delay(100);}
  assert.equal(remaining,'','Chrome process still running');
  if(context) await context.close().catch(()=>{});context=null;page=null;
  processes.push({case:activeCase,pid_before:before,confirmed_absent_after_force_stop:true});
  return before;
}
async function restart(url='http://127.0.0.1:8765/game.html'){
  const before=await forceStop();await launch(url);const after=adb('shell','pidof','com.android.chrome');
  assert(after && before!==after,'Expected a newly launched browser process');
  processes.at(-1).pid_after=after;
}
async function question(){
  const field=page.locator('#field-0');
  if(await field.count()) return;
  await page.locator('[id="select-SC04.STORM"]').click();await page.locator('#recall').click();await expect(field).toBeVisible();
}
async function draft(value){await page.locator('#field-0').fill(value);await expect(page.locator('#save-state')).toHaveText('Wszystkie zlecone zmiany zatwierdzone.');}
async function nativeFilePicker(filename){
  await page.locator('#import').click();
  // Exercise DocumentsUI rather than inject a host path into Android Chrome.
  try {
    await device.tap({text:filename},{timeout:15000});
  } catch(first) {
    await device.screenshot({path:path.join(OUT,`${activeCase}-documents-ui.png`)}).catch(()=>{});
    try {
      await device.tap({desc:/Show roots|Open navigation drawer/},{timeout:3000});
      await device.tap({text:'Downloads'},{timeout:5000});
      await device.tap({text:filename},{timeout:10000});
    } catch(second) {throw new Blocked(`Android DocumentsUI could not select ${filename}: ${second}`);}
  }
}
async function downloadExport(){
  const prefix='PORTUGALSKI_CHAOS_04_BACKUP';
  const list=()=>adb('shell','sh','-c',`ls -1 /sdcard/Download/${prefix}*.json 2>/dev/null || true`).split('\n').filter(Boolean);
  const before=new Set(list());await page.locator('#export').click();
  const deadline=Date.now()+45000;let created;
  while(Date.now()<deadline){
    created=list().find(name=>!before.has(name));if(created)break;
    // Native Chrome may display a first-download location confirmation.
    await device.tap({text:/^(Download|Allow)$/},{timeout:300}).catch(()=>{});await delay(500);
  }
  if(!created)throw new Blocked('No new JSON appeared in Android Download; no host-side export is counted as PASS');
  const dest=path.join(OUT,'A05-actual-export-from-android.json');adb('pull',created,dest);
  const parsed=JSON.parse(fs.readFileSync(dest,'utf8'));
  assert.deepEqual(parsed,committed.backup);
  logs.push({case:activeCase,download_path:created,sha256:hash(fs.readFileSync(dest))});
  return {androidPath:created,hostPath:dest,filename:path.posix.basename(created),backup:parsed};
}
async function uriPage(kind){
  if(context){await stopTrace();await context.close();context=null;page=null;}
  context=await device.launchBrowser({pkg:'com.android.chrome'});
  context.setDefaultTimeout(15000);await context.tracing.start({screenshots:true,snapshots:true,sources:true});traceActive=true;session++;
  if(kind==='file'){
    page=await context.newPage();instrument(page);
    try{await page.goto('file:///sdcard/Download/CHAOS_041_QA.html',{waitUntil:'domcontentloaded',timeout:15000});}
    catch(e){await screenshot('file-navigation-blocked');throw new Blocked(`Android file URI navigation: ${e}`);}
  } else {
    const apk=path.join(ROOT,'.qa-android-vib/provider/uri-provider.apk');
    if(!fs.existsSync(apk))throw new Blocked('Read-only ContentProvider APK could not be built; see provider-build.log');
    adb('install','-r',apk);
    adb('shell','am','start','-n','qa.portugalski.chaos.vib/.OpenHtmlActivity');
    for(let i=0;i<60;i++){page=context.pages().find(p=>p.url().startsWith('content://qa.portugalski.chaos.vib/'));if(page)break;await delay(250);}
    if(!page){await screenshot('content-navigation-blocked');throw new Blocked('Chrome did not expose the granted content URI as an executable HTML page');}
    instrument(page);
  }
  await page.waitForFunction(()=>window.ChaosStorage04 || document.readyState==='complete',{},{timeout:15000});
  const state=await page.evaluate(()=>({url:location.href,origin:location.origin,status:document.querySelector('#status')?.textContent,native:Object.prototype.toString.call(indexedDB),api:typeof window.ChaosStorage04}));
  logs.push({case:activeCase,uri_state:state});
  if(state.api==='undefined' || state.status?.includes('BLOCKED'))throw new Blocked(`URI HTML/IndexedDB not available: ${JSON.stringify(state)}`);
  try{await page.waitForFunction(()=>document.querySelector('#save-state').textContent==='Dziennik odczytany.',{},{timeout:15000});}
  catch(e){throw new Blocked(`Native URI database did not open: ${state.status}`);}
  assert.equal(state.native,'[object IDBFactory]');row(activeCase).native_indexeddb=true;
}
async function uriPersistence(kind){
  await uriPage(kind);await question();await draft(`${kind}-native-draft`);const before=await snapshot('uri-before');
  const pid=await forceStop();await uriPage(kind);const next=adb('shell','pidof','com.android.chrome');assert(next && next!==pid);
  await expect(page.locator('#field-0')).toHaveValue(`${kind}-native-draft`);assert.deepEqual(await snapshot('uri-after'),before);
}
async function execute(id,action){
  activeCase=id;const item=row(id);const start=Date.now();
  try{
    if(context && !traceActive){await context.tracing.start({screenshots:true,snapshots:true,sources:true});traceActive=true;}
    await action();assert(!logs.some(l=>l.case===id && l.type==='pageerror'),'Uncaught browser JavaScript error');
    item.status='PASS';item.actual='All scenario assertions completed against native Android browser/storage';
  }
  catch(error){item.status=error instanceof Blocked?'BLOCKED':'FAIL';item.actual=String(error.stack||error);}
  finally{
    await screenshot('final');await stopTrace().catch(e=>{item.status='FAIL';item.actual+=`\nTrace save error: ${e}`;});
    item.duration_seconds=(Date.now()-start)/1000;item.evidence=fs.readdirSync(OUT).filter(f=>f.startsWith(`${id}-`));
    write(path.join(OUT,`${id}-result.json`),item);save();console.log(id,item.status);
  }
}
async function run(){
  try{
    assert.equal(process.env.GITHUB_ACTIONS,'true','Run on actual GitHub Actions only');
    const devices=adb('devices').split('\n').slice(1).filter(l=>/\tdevice$/.test(l));assert.equal(devices.length,1);
    serial=devices[0].split('\t')[0];assert(serial.startsWith('emulator-'));
    assert.equal(adb('shell','getprop','ro.kernel.qemu'),'1','A physical device is forbidden in this job');
    Object.assign(report.environment,{serial,android_release:adb('shell','getprop','ro.build.version.release'),android_api:adb('shell','getprop','ro.build.version.sdk'),android_build:adb('shell','getprop','ro.build.fingerprint'),chrome_package:adb('shell','dumpsys','package','com.android.chrome').split('\n').filter(l=>/versionName=|dataDir=/.test(l)).join('\n')});
    assert.equal(report.environment.android_api,'35','Unexpected Android API');
    if(!adb('shell','pm','path','com.android.chrome').startsWith('package:'))throw new Blocked('CHROME_NOT_INSTALLED_IN_AVD');
    const html=fs.readFileSync(path.join(ROOT,'.qa-android-vib/game/game.html'));report.environment.html_sha256=hash(html);
    assert.equal(hash(html),'98033fbebc8c5fefafdaa2d8e07e41faee25d5fc9681a132077b6417a9f75b87');
    const make=port=>new Promise((resolve,reject)=>{const s=http.createServer((q,r)=>{if(q.url!=='/game.html'){r.writeHead(404);r.end();return;}r.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});r.end(html);});s.once('error',reject);s.listen(port,'127.0.0.1',()=>resolve(s));});
    serverA=await make(8765);serverB=await make(8766);adb('reverse','tcp:8765','tcp:8765');adb('reverse','tcp:8766','tcp:8766');
    adb('shell','am','set-debug-app','--persistent','com.android.chrome');
    adb('push',path.join(ROOT,'.qa-android-vib/game/game.html'),'/sdcard/Download/CHAOS_041_QA.html');
    assert.equal(adb('shell','sha256sum','/sdcard/Download/CHAOS_041_QA.html').split(/\s+/)[0],hash(html));
    const found=await _android.devices();assert.equal(found.length,1);device=found[0];report.environment.model=device.model();
    await execute('A01',async()=>{await launch();await question();await draft('emulator-committed');committed=await snapshot('commit');assert(committed.backup.state.revision>=3);});
    await execute('A02',async()=>{if(row('A01').status!=='PASS')throw new Blocked('A01 prerequisite failed');const before=await snapshot('before-reload');await page.reload();await expect(page.locator('#field-0')).toHaveValue('emulator-committed');assert.deepEqual(await snapshot('after-reload'),before);});
    await execute('A03',async()=>{if(row('A01').status!=='PASS')throw new Blocked('A01 prerequisite failed');const before=await snapshot('before-restart');await restart();await expect(page.locator('#field-0')).toHaveValue('emulator-committed');assert.deepEqual(await snapshot('after-restart'),before);});
    await execute('A04',async()=>{if(!page)throw new Blocked('No working HTTP browser');await draft('emulator-protected-draft');await page.locator('#pause').click();await page.locator('#resume').click();await page.locator('#help').click();await page.locator('#back').click();await expect(page.locator('#field-0')).toHaveValue('emulator-protected-draft');const before=await snapshot('draft-before');await restart();await page.locator('#refresh').click();await expect(page.locator('#status')).toContainText('Odczyt i replay dziennika zakończone');await expect(page.locator('#field-0')).toHaveValue('emulator-protected-draft');assert.deepEqual(await snapshot('draft-recovered'),before);committed=before;});
    await execute('A05',async()=>{if(!page)throw new Blocked('No working HTTP browser');committed=await snapshot('export-expected');exported=await downloadExport();});
    await execute('A06',async()=>{if(!exported)throw new Blocked('Actual Android export A05 unavailable');await forceStop();await launch('http://127.0.0.1:8766/game.html');assert.deepEqual((await snapshot('empty-origin')).raw,{kv:[],events:[]});await nativeFilePicker(exported.filename);await expect(page.locator('#status')).toContainText('Dziennik i stan odtworzone');assert.deepEqual((await snapshot('imported')).backup,exported.backup);await restart('http://127.0.0.1:8766/game.html');assert.deepEqual((await snapshot('import-after-restart')).backup,exported.backup);});
    await execute('A07',async()=>{if(row('A06').status!=='PASS')throw new Blocked('A06 prerequisite failed');const before=await snapshot('before-corrupt'),bad=JSON.parse(JSON.stringify(before.backup));bad.state.revision++;const file=path.join(OUT,'A07-corrupt-backup.json');write(file,bad);adb('push',file,'/sdcard/Download/CHAOS_CORRUPT_QA.json');await nativeFilePicker('CHAOS_CORRUPT_QA.json');await expect(page.locator('#status')).toContainText('Import odrzucony');assert.deepEqual(await snapshot('after-corrupt'),before);});
    await execute('A08',async()=>{await restart();await question();const before=await snapshot('before-abort');await page.evaluate(()=>{const P=IDBObjectStore.prototype,native=P.put;window.__qaAbort=false;P.put=function(...a){const r=Reflect.apply(native,this,a);if(this.name==='kv'&&a[1]==='state')r.addEventListener('success',()=>{this.transaction.abort();window.__qaAbort=true;P.put=native;},{once:true});return r;};});await page.locator('#field-0').fill('unsaved-after-real-abort');await expect(page.locator('#status')).toContainText('ZAPIS NIEPOTWIERDZONY');assert.equal(await page.evaluate(()=>window.__qaAbort),true);assert.deepEqual(await snapshot('after-abort'),before);await page.locator('#refresh').click();await expect(page.locator('#status')).toContainText('ODŚWIEŻENIE WSTRZYMANE');await expect(page.locator('#field-0')).toHaveValue('unsaved-after-real-abort');});
    if(process.env.QA_TEST_URIS!=='false'){
      await execute('A09',()=>uriPersistence('file'));
      await execute('A10',()=>uriPersistence('content'));
    }else{row('A09').actual=row('A10').actual='URI probes disabled by explicit workflow input';}
  }catch(error){report.infrastructure_error=String(error.stack||error);for(const item of report.results)if(item.status==='NOT RUN'&&item.id!=='P01'){item.status='BLOCKED';item.actual=report.infrastructure_error;}}
  finally{
    if(context){await stopTrace().catch(()=>{});await context.close().catch(()=>{});}if(device)await device.close().catch(()=>{});
    if(serverA)await new Promise(resolve=>serverA.close(resolve));if(serverB)await new Promise(resolve=>serverB.close(resolve));
    write(path.join(OUT,'android-browser-log.json'),logs);write(path.join(OUT,'process-restarts.json'),processes);
    row('P01').actual='Physical phone not connected or exercised; emulator evidence does not cover this case';
    try{fs.writeFileSync(path.join(OUT,'adb-logcat.txt'),adb('logcat','-d','-v','threadtime'));fs.writeFileSync(path.join(OUT,'adb-activity.txt'),adb('shell','dumpsys','activity','activities'));}catch(e){report.adb_log_error=String(e);}
    save();
  }
  const required=report.results.filter(r=>/^A0[1-8]$/.test(r.id));
  process.exitCode=required.every(r=>r.status==='PASS')&&!report.results.some(r=>r.status==='FAIL')?0:1;
}
run().catch(error=>{report.fatal_error=String(error.stack||error);save();console.error(error);process.exitCode=1;});
