"""Verify immutable inputs and the successful desktop prerequisite; extract to QA only."""
import hashlib
import json
import os
from pathlib import Path
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = Path(os.environ.get('QA_OUTPUT', ROOT / '.qa-android-vib/results')).resolve()
HTML = 'URUCHOM_PORTUGALSKI_CHAOS_0_4_1_HARDENING_OFFLINE.html'
HTML_SHA = '98033fbebc8c5fefafdaa2d8e07e41faee25d5fc9681a132077b6417a9f75b87'
ARCHIVE = 'PORTUGALSKI_CHAOS_0_4_1_INTEGRITY_HARDENING_PAKIET.zip'
EXPECTED = {
    ARCHIVE: '079234f995485697579d64741742758b345dd5bba9285afde8649546b6ba3b1f',
    'PORTUGALSKI_CHAOS_BROWSER_INDEXEDDB_041.zip': '8f0a658eaba599ad53c0680cddf40bf1fc371e8e0391c00de4d44b487febb182',
}


def prepare():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    inputs = {}
    for filename, expected in EXPECTED.items():
        actual = hashlib.sha256((ROOT / filename).read_bytes()).hexdigest()
        assert actual == expected, f'Input archive changed: {filename}'
        inputs[filename] = actual
    with zipfile.ZipFile(ROOT / ARCHIVE) as archive:
        prefix = 'PORTUGALSKI_CHAOS_0_4_1_HARDENING/'
        manifest = archive.read(prefix + 'SHA256SUMS.txt').decode()
        count = 0
        for line in manifest.splitlines():
            checksum, name = line.split(maxsplit=1)
            assert hashlib.sha256(archive.read(prefix + name)).hexdigest() == checksum, name
            count += 1
        assert archive.testzip() is None
        content = archive.read(prefix + HTML)
    assert hashlib.sha256(content).hexdigest() == HTML_SHA
    game = ROOT / '.qa-android-vib/game'; game.mkdir(parents=True, exist_ok=True)
    (game / 'game.html').write_bytes(content)
    (OUTPUT / 'input-integrity.json').write_text(json.dumps({'archives': inputs, 'html_sha256': HTML_SHA, 'manifest_entries': count}, indent=2) + '\n')
    if os.environ.get('GITHUB_ACTIONS') == 'true':
        repository = os.environ['GITHUB_REPOSITORY']
        assert repository == 'gambitheslave-hub/portugalski-chaos-qa'
        token = os.environ['GITHUB_TOKEN']
        def fetch(suffix):
            request = urllib.request.Request('https://api.github.com/repos/' + repository + suffix,
                headers={'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json'})
            with urllib.request.urlopen(request, timeout=30) as response:
                return json.load(response)
        run = fetch('/actions/runs/39174216484')
        assert run['status'] == 'completed' and run['conclusion'] == 'success'
        assert run['head_sha'] == 'dbd407dcc3409fdfe4c3dcf119dd8f752b0dc1ae'
        jobs = fetch('/actions/runs/39174216484/jobs?per_page=100')
        assert any(j['name'] == 'real-chromium-indexeddb' and j['conclusion'] == 'success' for j in jobs['jobs'])
        (OUTPUT / 'desktop-prerequisite-run.json').write_text(json.dumps(run, indent=2) + '\n')
        (OUTPUT / 'desktop-prerequisite-jobs.json').write_text(json.dumps(jobs, indent=2) + '\n')
    print(f'PASS immutable archives, {count} manifest entries, production HTML {HTML_SHA}')


if __name__ == '__main__':
    prepare()
