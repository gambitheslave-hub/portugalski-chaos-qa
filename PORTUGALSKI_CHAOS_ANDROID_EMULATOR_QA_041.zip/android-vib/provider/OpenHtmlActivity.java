package qa.portugalski.chaos.vib;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

/** Supply an actual Android content URI grant to the real Chrome application. */
public final class OpenHtmlActivity extends Activity {
    public void onCreate(Bundle state) {
        super.onCreate(state);
        Uri uri = Uri.parse("content://qa.portugalski.chaos.vib/game.html");
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(uri, "text/html"); view.setPackage("com.android.chrome");
        view.setClipData(ClipData.newRawUri("unchanged 0.4.1 HTML", uri));
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(view); finish();
    }
}
