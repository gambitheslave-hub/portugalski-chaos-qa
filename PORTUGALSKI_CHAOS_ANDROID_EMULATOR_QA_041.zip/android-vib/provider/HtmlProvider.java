package qa.portugalski.chaos.vib;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Read-only test fixture; contains the unchanged release asset, no game logic. */
public final class HtmlProvider extends ContentProvider {
    private File html;
    public boolean onCreate() {
        html = new File(getContext().getFilesDir(), "game.html");
        try (InputStream input = getContext().getAssets().open("game.html");
             FileOutputStream output = new FileOutputStream(html)) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            return true;
        } catch (Exception error) { return false; }
    }
    private void check(Uri uri) throws FileNotFoundException {
        if (!"/game.html".equals(uri.getPath())) throw new FileNotFoundException("Unknown asset");
    }
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        check(uri);
        if (!"r".equals(mode)) throw new FileNotFoundException("Read only");
        return ParcelFileDescriptor.open(html, ParcelFileDescriptor.MODE_READ_ONLY);
    }
    public String getType(Uri uri) { return "text/html"; }
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String order) {
        MatrixCursor cursor = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
        cursor.addRow(new Object[]{"game.html", html.length()}); return cursor;
    }
    public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    public int delete(Uri uri, String selection, String[] args) { throw new UnsupportedOperationException(); }
    public int update(Uri uri, ContentValues values, String selection, String[] args) { throw new UnsupportedOperationException(); }
}
