"""Generate per-case Android evidence; missing execution never becomes PASS."""
import csv
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SCENARIOS = json.loads((Path(__file__).parent / 'scenarios.json').read_text())


def render(data, output):
    output.mkdir(parents=True, exist_ok=True)
    env = data['environment']
    fields = ['id', 'scope', 'name', 'status', 'expected', 'actual', 'native_indexeddb', 'evidence',
              'commit_sha', 'branch', 'run_id', 'run_url', 'android_release', 'android_api', 'chrome_package', 'html_sha256']
    with (output / 'MACIERZ_ANDROID_EMULATOR_0_4_1.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader()
        for result in data['results']:
            row = {key: result.get(key, env.get(key, '')) for key in fields}
            writer.writerow({key: json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else value for key, value in row.items()})
    lines = ['# RAPORT ANDROID EMULATOR QA 0.4.1 — ETAP VI.B', '',
             'PASS oznacza wykonanie wszystkich asercji danego przypadku na prawdziwym AVD i rzeczywistej przeglądarce. Sam workflow nie jest certyfikacją. Emulator nie jest fizycznym telefonem.', '',
             '## Środowisko i identyfikacja', '', '```json', json.dumps(env, ensure_ascii=False, indent=2), '```', '',
             '## Macierz', '', '| ID | Zakres | Status | Natywny IndexedDB użyty w wykonaniu |', '| --- | --- | --- | --- |']
    lines += [f"| {r['id']} | {r['scope']} | {r['status']} | {r.get('native_indexeddb', False)} |" for r in data['results']]
    for r in data['results']:
        lines += ['', f"## {r['id']} — {r['name']}: {r['status']}", '', 'Oczekiwane: ' + r['expected'], '',
                  'Rzeczywiste:', '', '```text', str(r['actual']), '```', '', 'Dowody: ' + (', '.join(r.get('evidence', [])) or 'brak wykonania / brak screenshotów Androida')]
    lines += ['', '## Granice', '',
              'HTTP localhost, Android file URI i Android content URI są odrębnymi zakresami. Brak możliwości otwarcia URI lub użycia storage daje BLOCKED z przyczyną. Jeśli zapis działa, lecz dane nie przeżywają restartu, wynik jest FAIL. Fizyczny telefon i retencja 24 h: NOT RUN.', '',
              'Wynik desktop Chromium/IndexedDB run 39174216484 jest wcześniejszym, oddzielnym dowodem. Nie nadaje statusu PASS żadnemu testowi Androida.']
    (output / 'RAPORT_ANDROID_EMULATOR_0_4_1.md').write_text('\n'.join(lines) + '\n')


def main():
    output = Path(os.environ.get('QA_OUTPUT', ROOT / '.qa-android-vib/results')).resolve()
    result = output / 'android-results.json'
    if result.exists():
        data = json.loads(result.read_text())
    else:
        data = {'environment': {'run_id': os.environ.get('GITHUB_RUN_ID'), 'commit_sha': os.environ.get('QA_HEAD_SHA'),
                'branch': os.environ.get('GITHUB_HEAD_REF') or os.environ.get('GITHUB_REF_NAME'), 'physical_phone': False,
                'platform': 'Android runner not reached / infrastructure failed before browser execution'},
                'results': [{**s, 'status': 'NOT RUN' if s['id'] == 'P01' else 'BLOCKED',
                             'actual': 'Physical phone not exercised' if s['id'] == 'P01' else 'Workflow/SDK/AVD/browser setup did not produce native results; inspect setup logs',
                             'native_indexeddb': False, 'evidence': []} for s in SCENARIOS]}
        output.mkdir(parents=True, exist_ok=True)
        result.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    render(data, output)


if __name__ == '__main__':
    main()
