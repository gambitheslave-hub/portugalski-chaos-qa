"""Render actual native results, or an explicit infrastructure block, as Markdown/CSV."""
import argparse
import csv
import json
import os
from pathlib import Path
from scenarios import SCENARIOS


def render(data, output):
    output.mkdir(parents=True, exist_ok=True)
    env = data['environment']
    columns = ['id','name','status','expected','actual','native_indexeddb','commit_sha','branch',
               'run_id','run_url','chromium_version','system','html_sha256','evidence']
    rows = []
    for case in data['results']:
        rows.append({**{key: case.get(key, '') for key in ('id','name','status','expected','actual','native_indexeddb','evidence')},
                     'commit_sha': env.get('head_commit_sha'), 'branch': env.get('branch'),
                     **{key: env.get(key) for key in ('run_id','run_url','chromium_version','system','html_sha256')}})
    with (output / 'MACIERZ_BROWSER_INDEXEDDB_0_4_1.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=columns);writer.writeheader()
        for row in rows:
            writer.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in row.items()})
    lines=['# RAPORT BROWSER / INDEXEDDB 0.4.1','',
           'Statusy pochodzą z wykonania scenariuszy albo z jawnie opisanej blokady infrastruktury. Testy Node nie są dowodem natywnego IndexedDB.','',
           '## Kontekst','', '```json',json.dumps(env,ensure_ascii=False,indent=2),'```','',
           '## Macierz','', '| Test | Status | Natywny IndexedDB w wykonaniu |','| --- | --- | --- |']
    lines += [f"| {r['id']} — {r['name']} | {r['status']} | {r['native_indexeddb']} |" for r in rows]
    for row in rows:
        actual = row['actual'] if isinstance(row['actual'],str) else json.dumps(row['actual'],ensure_ascii=False,indent=2)
        lines += ['',f"## {row['id']} — {row['status']}",'',f"Oczekiwane: {row['expected']}",'',
                  'Rzeczywiste:','', '```text',actual,'```','', 'Dowody: ' + (', '.join(row['evidence']) or 'brak wykonania / artefaktów przeglądarki')]
    lines += ['', '## Granice','',
              'Zakres: Linux Chromium przez HTTP localhost. `file://` i Android `content://`: NOT RUN. Retencja 24 h: NOT RUN. Test kontrolowanego abortu nie symuluje magazynu danych; operacje i rollback wykonuje natywne IndexedDB. Test limitu dotyczy 10000 zdarzeń aplikacji, nie fizycznego wyczerpania dysku.',
              '', 'Emulator Android jest osobnym jobem, uruchamianym wyłącznie po sukcesie głównych testów. Nie jest fizycznym telefonem.']
    (output/'RAPORT_BROWSER_INDEXEDDB_0_4_1.md').write_text('\n'.join(lines)+'\n')
    return rows


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--results',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path);args=parser.parse_args()
    if args.results.exists():
        data=json.loads(args.results.read_text())
    else:
        reason='BLOCKED: browser runner did not produce results; inspect GitHub Actions setup/install logs'
        data={'environment':{'head_commit_sha':os.environ.get('QA_HEAD_SHA') or os.environ.get('GITHUB_SHA'),
              'branch':os.environ.get('GITHUB_HEAD_REF') or os.environ.get('GITHUB_REF_NAME'),
              'run_id':os.environ.get('GITHUB_RUN_ID'),'run_url':os.environ.get('QA_RUN_URL'),
              'chromium_version':None,'system':None,'html_sha256':None},
              'results':[{'id':key,'name':name,'expected':expected,'status':'BLOCKED','actual':reason,
                          'native_indexeddb':False,'evidence':[]} for key,(name,expected) in SCENARIOS.items()]}
        args.output.mkdir(parents=True,exist_ok=True)
        (args.output/'results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    render(data,args.output)


if __name__=='__main__':
    main()
