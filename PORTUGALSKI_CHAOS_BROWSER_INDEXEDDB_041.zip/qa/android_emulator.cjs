'use strict';
// Separate experimental emulator check; never represents a physical telephone.
const { _android } = require('playwright');
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const output = path.resolve(process.env.QA_OUTPUT || '.qa/android/current');
fs.mkdirSync(output, { recursive: true });
const html = fs.readFileSync(path.resolve('releases/0.4.1/URUCHOM_PORTUGALSKI_CHAOS_0_4_1_HARDENING_OFFLINE.html'));
const result = { id:'ANDROID_EMULATOR', status:'NOT RUN', physical_phone:false,
  run_id:process.env.GITHUB_RUN_ID, commit_sha:process.env.GITHUB_SHA,
  native_indexeddb:false, html_sha256:crypto.createHash('sha256').update(html).digest('hex'), evidence:[] };
const adb = (...args) => execFileSync('adb',args,{encoding:'utf8',timeout:20000}).trim();
const backup = async page => page.evaluate(async () => {
  const db=await ChaosStorage04.open();
  try {const b=await ChaosStorage04.backup(db);ChaosEngine04.validateBackup(b);return b;}
  finally {db.close();}
});
const server = http.createServer((request,response) => {
  if (request.url !== '/game.html') {response.writeHead(404);response.end();return;}
  response.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});response.end(html);
});
(async () => {
  let device,context;
  try {
    assert.equal(process.env.GITHUB_ACTIONS,'true','Run on GitHub Actions only');
    assert.equal(result.html_sha256,'98033fbebc8c5fefafdaa2d8e07e41faee25d5fc9681a132077b6417a9f75b87');
    assert.equal(adb('shell','getprop','ro.kernel.qemu'),'1','Only an emulator may be used');
    result.android_release=adb('shell','getprop','ro.build.version.release');
    result.android_build=adb('shell','getprop','ro.build.fingerprint');
    const installed=adb('shell','pm','path','com.android.chrome');
    if (!installed.startsWith('package:')) throw Error('CHROME_NOT_INSTALLED_IN_AVD');
    await new Promise((resolve,reject) => {server.once('error',reject);server.listen(8765,'127.0.0.1',resolve);});
    adb('reverse','tcp:8765','tcp:8765');
    const devices=await _android.devices();assert.equal(devices.length,1,'Expected exactly one emulator');
    device=devices[0];result.model=device.model();
    context=await device.launchBrowser({pkg:'com.android.chrome'});
    await context.tracing.start({screenshots:true,snapshots:true,sources:true});
    let page=await context.newPage();await page.goto('http://127.0.0.1:8765/game.html');
    await page.locator('[id="select-SC04.STORM"]').click();await page.locator('#recall').click();
    result.user_agent=await page.evaluate(()=>navigator.userAgent);
    assert.equal(await page.evaluate(()=>Object.prototype.toString.call(indexedDB)),'[object IDBFactory]');
    result.native_indexeddb=true;
    await page.locator('#field-0').fill('android-emulator-draft');
    await page.waitForFunction(()=>document.querySelector('#save-state').textContent==='Wszystkie zlecone zmiany zatwierdzone.');
    const before=await backup(page);result.pid_before=adb('shell','pidof','com.android.chrome');
    await page.screenshot({path:path.join(output,'before-restart.png'),fullPage:true});
    await context.tracing.stop({path:path.join(output,'trace-before.zip')});await context.close();context=null;
    adb('shell','am','force-stop','com.android.chrome');
    assert.equal(adb('shell','sh','-c','pidof com.android.chrome || true'),'');
    context=await device.launchBrowser({pkg:'com.android.chrome'});
    await context.tracing.start({screenshots:true,snapshots:true,sources:true});
    page=await context.newPage();await page.goto('http://127.0.0.1:8765/game.html');
    await page.locator('#field-0').waitFor();
    assert.equal(await page.locator('#field-0').inputValue(),'android-emulator-draft');
    assert.deepEqual(await backup(page),before);
    result.pid_after=adb('shell','pidof','com.android.chrome');assert.notEqual(result.pid_before,result.pid_after);
    await page.screenshot({path:path.join(output,'after-restart.png'),fullPage:true});
    await context.tracing.stop({path:path.join(output,'trace-after.zip')});
    result.status='PASS';result.actual='Native IndexedDB journal and draft survive Chrome process force-stop/relaunch on Android emulator, same profile and localhost origin';
  } catch(error) {
    result.status=result.native_indexeddb?'FAIL':'BLOCKED';result.reason=String(error.stack || error);
    process.exitCode=1;
  } finally {
    if(context) await context.close().catch(()=>{});
    if(device) await device.close().catch(()=>{});
    if(server.listening) await new Promise(resolve=>server.close(resolve));
    result.evidence=fs.readdirSync(output);
    fs.writeFileSync(path.join(output,'android-result.json'),JSON.stringify(result,null,2)+'\n');
    console.log(JSON.stringify(result,null,2));
  }
})().catch(error=>{console.error(error);process.exitCode=1;});
