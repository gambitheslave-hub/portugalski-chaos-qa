"""T01–T10 in real Linux Chromium on GitHub Actions; release files stay unchanged."""
import copy
import functools
import hashlib
import json
import os
import platform
import sys
import tempfile
import threading
import time
import traceback
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from qa import HTML, HTML_SHA, RELEASE, verify
from playwright.sync_api import expect, sync_playwright
from scenarios import SCENARIOS

DB = 'portugalski_chaos_foundation_v0_4_ODDZIELNA'
RAW = r"""async () => {
  const db = await new Promise((ok, fail) => {
    const r = indexedDB.open('portugalski_chaos_foundation_v0_4_ODDZIELNA');
    r.onsuccess = () => ok(r.result); r.onerror = () => fail(r.error);
  });
  try {
    return await new Promise((ok, fail) => {
      const tx = db.transaction(['kv','events'], 'readonly');
      const keys = tx.objectStore('kv').getAllKeys(), values = tx.objectStore('kv').getAll();
      const events = tx.objectStore('events').getAll();
      tx.oncomplete = () => ok({kv:keys.result.map((key,i)=>({key,value:values.result[i]})),events:events.result});
      tx.onabort = () => fail(tx.error || Error('raw read aborted'));
    });
  } finally { db.close(); }
}"""
BACKUP = """async () => {
  const db = await ChaosStorage04.open();
  try { const b = await ChaosStorage04.backup(db); ChaosEngine04.validateBackup(b); return b; }
  finally { db.close(); }
}"""
# The hook preserves native requests. Both provisional writes succeed before
# tx.abort(); no mock, substitute store or change to shipping code is involved.
ARM_ABORT = r"""() => {
  const P=IDBObjectStore.prototype, put=P.put, add=P.add;
  window.__fault={eventSuccess:0,stateSuccess:0,aborted:false};
  P.add=function(...args) {
    const r=Reflect.apply(add,this,args);
    if(this.name==='events') r.addEventListener('success',()=>++__fault.eventSuccess);
    return r;
  };
  P.put=function(...args) {
    const r=Reflect.apply(put,this,args);
    if(this.name==='kv' && args[1]==='state') r.addEventListener('success',()=>{
      ++__fault.stateSuccess; this.transaction.abort(); __fault.aborted=true;
      P.put=put; P.add=add;
    },{once:true});
    return r;
  };
}"""


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def browser_pid(profile):
    needle = f'--user-data-dir={profile}'.encode()
    for process in Path('/proc').glob('[0-9]*'):
        try:
            args = (process / 'cmdline').read_bytes().split(b'\0')
            if needle in args and not any(a.startswith(b'--type=') for a in args):
                return int(process.name)
        except OSError:
            pass
    raise RuntimeError('Cannot identify the Chromium browser PID for this profile')


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass


class Case:
    def __init__(self, playwright, origin, profiles, output, identifier, environment):
        self.playwright, self.origin = playwright, origin
        self.profiles, self.output, self.environment = profiles, output / identifier, environment
        self.output.mkdir(parents=True, exist_ok=True)
        self.profile = Path(profiles) / identifier
        self.context = self.page = None
        self.sessions, self.notes, self.console, self.requests, self.errors = [], [], [], [], []
        self.block_external = self.native_idb = False
        self.read_number = 0

    def note(self, message, **details):
        self.notes.append({'message': message, **details})

    def route(self, route):
        if urlsplit(route.request.url).netloc == urlsplit(self.origin).netloc:
            route.continue_()
        else:
            self.note('External request blocked', url=route.request.url)
            route.abort('internetdisconnected')

    def instrument(self, page):
        page.on('console', lambda message: self.console.append({'type':message.type,'text':message.text}))
        page.on('pageerror', lambda error: self.errors.append(str(error)))

    def launch(self, path=HTML, profile=None):
        assert self.context is None
        self.profile = Path(profile) if profile else self.profile
        self.context = self.playwright.chromium.launch_persistent_context(
            str(self.profile), headless=True, accept_downloads=True, viewport={'width':390,'height':844})
        self.context.set_default_timeout(15000)
        self.context.tracing.start(screenshots=True, snapshots=True, sources=True)
        if self.block_external:
            self.context.route('**/*', self.route)
        self.context.on('request', lambda request: self.requests.append(request.url))
        self.page = self.context.pages[0]; self.instrument(self.page)
        self.pid = browser_pid(self.profile)
        version = self.context.browser.version
        self.environment['chromium_version'] = version
        self.sessions.append({'pid':self.pid,'profile':str(self.profile),'origin':self.origin,'chromium_version':version})
        response = self.page.goto(self.origin + '/' + path, wait_until='domcontentloaded')
        assert response and response.ok
        served_sha = hashlib.sha256(response.body()).hexdigest()
        assert served_sha == hashlib.sha256((RELEASE / path).read_bytes()).hexdigest()
        if path == HTML:
            assert served_sha == HTML_SHA
        self.note('Browser received exact unchanged HTML bytes', path=path, sha256=served_sha)
        self.page.wait_for_function("document.querySelector('#save-state').textContent === 'Dziennik odczytany.'")
        assert self.page.evaluate('location.origin') == self.origin
        native = self.page.evaluate("({factory:Object.prototype.toString.call(indexedDB),open:Function.prototype.toString.call(IDBFactory.prototype.open),db:ChaosStorage04.NAME})")
        assert native['factory'] == '[object IDBFactory]' and '[native code]' in native['open']
        assert native['db'] == DB
        self.native_idb = True; self.note('Native IndexedDB verified', **native)
        return self.page

    def screenshot(self, name):
        if self.page and not self.page.is_closed():
            self.page.screenshot(path=str(self.output / f'{name}.png'), full_page=True, timeout=10000)

    def close(self):
        if self.context is None:
            return
        number = len(self.sessions)
        try:
            self.screenshot(f'session-{number:02d}')
            self.context.tracing.stop(path=str(self.output / f'trace-{number:02d}.zip'))
        finally:
            self.context.close(); self.context = self.page = None
        deadline = time.monotonic() + 8
        while Path(f'/proc/{self.pid}').exists() and time.monotonic() < deadline:
            time.sleep(0.05)
        assert not Path(f'/proc/{self.pid}').exists(), 'Whole Chromium process did not terminate'
        self.note('Whole browser process terminated', pid=self.pid)

    def restart(self, path=HTML):
        old = self.pid; self.close(); page = self.launch(path)
        assert self.pid != old
        self.note('Restarted process, same profile and origin', old_pid=old, new_pid=self.pid)
        return page

    def raw(self, page=None):
        data = (page or self.page).evaluate(RAW)
        self.read_number += 1
        write_json(self.output / f'raw-stores-{self.read_number:02d}.json', data)
        return data

    def backup(self, page=None):
        page = page or self.page; result = page.evaluate(BACKUP); raw = self.raw(page)
        assert result['state']['revision'] == len(raw['events'])
        assert [e['id'] for e in raw['events']] == list(range(1,len(raw['events'])+1))
        assert raw['events'] == result['events']
        if raw['kv']:
            assert raw['kv'] == [{'key':'state','value':result['state']}]
        return result

    def select(self, mission='SC04.STORM'):
        self.page.locator(f'[id="select-{mission}"]').click()
        self.page.locator('#recall').click()
        expect(self.page.locator('#field-0')).to_be_visible()

    def draft(self, value, page=None):
        page = page or self.page; page.locator('#field-0').fill(value)
        expect(page.locator('#save-state')).to_have_text('Wszystkie zlecone zmiany zatwierdzone.')

    def download(self, button, filename, page=None):
        page = page or self.page
        with page.expect_download() as event:
            page.locator(button).click()
        download = event.value; path = self.output / filename; download.save_as(path)
        assert download.failure() is None and path.is_file() and path.stat().st_size > 0
        self.note('Real browser download', suggested_filename=download.suggested_filename,
                  saved_as=filename, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        return path, json.loads(path.read_text())

    def finish(self):
        try:
            self.close()
        finally:
            write_json(self.output / 'browser-log.json', {'sessions':self.sessions,'notes':self.notes,
                       'console':self.console,'page_errors':self.errors,'requests':self.requests})


def t01(c):
    c.launch(); c.select(); c.draft('acab')
    before = c.raw(); c.backup(); write_json(c.output / 'committed-before.json', before)
    c.restart(); expect(c.page.locator('#field-0')).to_have_value('acab')
    assert c.raw() == before
    write_json(c.output / 'read-after-process-restart.json', c.raw())
    c.note('Committed state and journal unchanged after full process restart')


def t02(c):
    c.launch(); c.select(); c.draft('committed'); before = c.raw()
    c.page.evaluate(ARM_ABORT); c.page.locator('#field-0').fill('must-abort')
    expect(c.page.locator('#status')).to_contain_text('ZAPIS NIEPOTWIERDZONY')
    fault = c.page.evaluate('window.__fault')
    assert fault == {'eventSuccess':1,'stateSuccess':1,'aborted':True}, fault
    assert c.raw() == before
    c.note('Real transaction aborted after both success events; both stores unchanged', fault=fault)
    c.restart(); assert c.raw() == before
    expect(c.page.locator('#field-0')).to_have_value('committed')


def t03(c):
    c.launch(); c.select()
    other = c.context.new_page(); c.instrument(other); other.goto(c.origin + '/' + HTML)
    expect(other.locator('#field-0')).to_be_visible()
    base = c.backup()['state']['revision']; c.draft('winner'); winning = c.raw()
    assert c.backup()['state']['revision'] == base + 1
    other.locator('#field-0').fill('loser-unsaved')
    expect(other.locator('#status')).to_contain_text('CONFLICT')
    assert c.raw(other) == winning
    expect(other.locator('#field-0')).to_have_value('loser-unsaved')
    other.screenshot(path=str(c.output / 'stale-tab-conflict.png'), full_page=True)
    _, draft = c.download('#draft-download','stale-tab-rescue.json',other)
    assert draft['draft']['values'] == ['loser-unsaved']
    c.note('Two native tabs: stale revision rejected, winner preserved', stale_revision=base, committed_revision=base+1)


def t04(c):
    c.launch(); c.select(); c.page.locator('#field-0').fill('pause-draft'); c.page.locator('#pause').click()
    expect(c.page.locator('#resume')).to_be_visible()
    assert c.backup()['state']['runs']['SC04.STORM']['draft']['values'] == ['pause-draft']
    c.page.locator('#resume').click(); expect(c.page.locator('#field-0')).to_have_value('pause-draft')
    c.page.locator('#help').click(); c.page.locator('#back').click()
    expect(c.page.locator('#field-0')).to_have_value('pause-draft')
    before = c.raw(); c.restart(); expect(c.page.locator('#field-0')).to_have_value('pause-draft')
    assert c.raw() == before
    c.page.evaluate(ARM_ABORT); c.page.locator('#field-0').fill('unsaved-after-error')
    expect(c.page.locator('#status')).to_contain_text('ZAPIS NIEPOTWIERDZONY')
    assert c.raw() == before
    expect(c.page.locator('#pause')).to_be_disabled()
    c.page.locator('#refresh').click(); expect(c.page.locator('#status')).to_contain_text('ODŚWIEŻENIE WSTRZYMANE')
    expect(c.page.locator('#field-0')).to_have_value('unsaved-after-error')
    _, rescued = c.download('#draft-download','uncommitted-draft.json')
    assert rescued['kind'] == 'CHAOS_04_UNCOMMITTED_DRAFT' and rescued['draft']['values'] == ['unsaved-after-error']
    _, committed = c.download('#export','last-committed.json')
    assert committed['state'] == before['kv'][0]['value'] and committed['events'] == before['events']
    c.note('Committed draft survives pause/help/restart; failed draft stays in UI and rescue download, never falsely committed')


def t05(c):
    c.launch(); c.select(); c.draft('export-draft'); committed = c.backup()
    path, downloaded = c.download('#export','valid-backup.json'); assert downloaded == committed
    c.close(); c.launch(profile=Path(c.profiles)/'T05-empty-import')
    assert c.raw() == {'kv':[],'events':[]}
    c.page.locator('#import').set_input_files(str(path))
    expect(c.page.locator('#status')).to_contain_text('Dziennik i stan odtworzone')
    assert c.backup() == downloaded
    c.restart(); assert c.backup() == downloaded
    expect(c.page.locator('#field-0')).to_have_value('export-draft')
    c.note('Actual downloaded JSON restored into empty native profile and survives process restart')


def t06(c):
    c.launch(); c.select(); c.draft('untouched'); damaged = copy.deepcopy(c.backup())
    damaged['state']['revision'] += 1
    path = c.output/'deliberately-corrupt.json'; write_json(path,damaged)
    for target in ('populated','empty'):
        if target == 'empty':
            c.close(); c.launch(profile=Path(c.profiles)/'T06-empty')
        before = c.raw(); c.page.locator('#import').set_input_files(str(path))
        expect(c.page.locator('#status')).to_contain_text('Import odrzucony')
        assert c.raw() == before
        c.screenshot(f'corrupt-rejected-{target}')
        c.note('Corrupt backup rejected; neither store changed', database=target)


def t07(c):
    c.launch('baseline/URUCHOM_PORTUGALSKI_CHAOS_FUNDAMENT_0_4_OFFLINE.html')
    c.select(); c.draft('acabou'); c.page.locator('#answer').click(); c.page.locator('#next').click()
    c.draft('baseline-draft'); before = c.raw(); old = c.backup()
    assert old['state']['runs']['SC04.STORM']['attempts']
    write_json(c.output/'native-history-created-by-0.4.json',before)
    c.restart(); expect(c.page.locator('#field-0')).to_have_value('baseline-draft')
    assert c.raw() == before and c.backup() == old
    c.note('0.4 native history read unchanged by 0.4.1; same profile, origin, schema and DB name; no migration')


def t08(c):
    c.launch(); c.select(); c.draft('acabou'); c.page.locator('#answer').click(); c.page.locator('#next').click()
    c.draft('storm-draft'); c.page.locator('#missions').click(); c.select('SC04.FEIRA'); c.draft('de')
    c.page.locator('#answer').click(); c.page.locator('#next').click(); c.draft('feira-draft')
    before = c.raw(); backup = c.backup()
    assert all(backup['state']['runs'][m]['attempts'] for m in ('SC04.STORM','SC04.FEIRA'))
    c.restart(); assert c.raw() == before
    expect(c.page.locator('#field-0')).to_have_value('feira-draft')
    c.page.locator('#missions').click(); c.page.locator('[id="select-SC04.STORM"]').click()
    expect(c.page.locator('#field-0')).to_have_value('storm-draft')
    assert c.raw()['events'][:len(before['events'])] == before['events']
    c.note('Both mission drafts and attempts remain in one native journal across process restart')


def t09(c):
    c.block_external = True; c.launch(); c.select(); c.draft('offline-draft'); before = c.raw()
    c.restart(); expect(c.page.locator('#field-0')).to_have_value('offline-draft'); assert c.raw() == before
    assert all(urlsplit(url).netloc == urlsplit(c.origin).netloc for url in c.requests)
    outcome = c.page.evaluate("async () => {try{await fetch('https://example.com/chaos-network-probe');return 'unexpected-success';}catch(e){return 'blocked';}}")
    assert outcome == 'blocked' and any(n['message']=='External request blocked' for n in c.notes)
    c.note('Local HTTP app works with external page requests blocked; deliberate fetch rejected; not file:// or content:// certification')


def t10(c):
    c.launch()
    c.page.evaluate("""async () => {
      const E=ChaosEngine04,S=ChaosStorage04; let state=E.fresh(),events=[];
      for(let i=1;i<=10000;i++) {
        const action=i===2?'START':'SELECT',payload=i===2?{lesson:false}:{missionId:'SC04.STORM'};
        const out=E.reduce(state,action,payload,i);state=out.next;events.push(out.event);
      }
      const b={kind:'CHAOS_04_BACKUP',version:E.SCHEMA,state,events};E.validateBackup(b);
      const db=await S.open();try{await S.restore(db,b);}finally{db.close();}
    }""")
    c.page.reload(wait_until='domcontentloaded'); expect(c.page.locator('#field-0')).to_be_visible(timeout=120000)
    before = c.raw(); assert len(before['events'])==10000 and before['kv'][0]['value']['revision']==10000
    c.page.locator('#field-0').fill('draft-at-journal-limit')
    expect(c.page.locator('#status')).to_contain_text('SZKIC NIEZAPISANY')
    expect(c.page.locator('#status')).to_contain_text('limit dziennika')
    expect(c.page.locator('#save-state')).not_to_have_text('Wszystkie zlecone zmiany zatwierdzone.')
    assert c.raw()==before
    path,rescue=c.download('#draft-download','limit-draft-rescue.json')
    assert rescue['draft']['values']==['draft-at-journal-limit'] and path.stat().st_size>0
    c.note('Actual 10000-event app limit with native IndexedDB; dirty draft not falsely acknowledged; not an OS quota exhaustion test')


def run():
    if os.environ.get('GITHUB_ACTIONS') != 'true':
        raise RuntimeError('Certification runner requires real GitHub Actions; local runs are not certification')
    output=Path(os.environ.get('QA_OUTPUT',ROOT/'.qa/browser/current')).resolve();output.mkdir(parents=True,exist_ok=False)
    event_path=os.environ.get('GITHUB_EVENT_PATH');event=json.loads(Path(event_path).read_text()) if event_path else {}
    environment={
        'timestamp_utc':datetime.now(timezone.utc).isoformat(),'system':platform.platform(),
        'os_release':Path('/etc/os-release').read_text(),'python':sys.version.split()[0],
        'head_commit_sha':event.get('pull_request',{}).get('head',{}).get('sha',os.environ.get('GITHUB_SHA')),
        'actions_commit_sha':os.environ.get('GITHUB_SHA'),
        'branch':os.environ.get('GITHUB_HEAD_REF') or os.environ.get('GITHUB_REF_NAME'),
        'run_id':os.environ.get('GITHUB_RUN_ID'),'run_attempt':os.environ.get('GITHUB_RUN_ATTEMPT'),
        'run_url':f"{os.environ.get('GITHUB_SERVER_URL','https://github.com')}/{os.environ.get('GITHUB_REPOSITORY')}/actions/runs/{os.environ.get('GITHUB_RUN_ID')}",
        'chromium_version':None,'html_sha256':None,'scope':'Linux Chromium; native IndexedDB; localhost HTTP only',
    }
    records=[{'id':key,'name':name,'expected':expected,'status':'NOT RUN','actual':'Case not reached',
              'native_indexeddb':False,'evidence':[]} for key,(name,expected) in SCENARIOS.items()]
    report={'environment':environment,'results':records};server=thread=None
    try:
        verify();assert RELEASE.is_dir(),'Tracked release sources missing'
        environment['html_sha256']=hashlib.sha256((RELEASE/HTML).read_bytes()).hexdigest()
        assert environment['html_sha256']==HTML_SHA
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(RELEASE)))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        origin=f'http://127.0.0.1:{server.server_port}';environment['origin']=origin
        with tempfile.TemporaryDirectory(prefix='chaos-native-profiles-') as profiles,sync_playwright() as playwright:
            for record,action in zip(records,(t01,t02,t03,t04,t05,t06,t07,t08,t09,t10)):
                case=Case(playwright,origin,profiles,output,record['id'],environment);started=time.monotonic()
                try:
                    action(case);assert not case.errors,case.errors
                    record.update(status='PASS',actual=case.notes)
                except Exception as error:
                    record.update(status='FAIL' if case.native_idb else 'BLOCKED',actual=f'{type(error).__name__}: {error}')
                    (case.output/'failure.txt').write_text(traceback.format_exc())
                finally:
                    try:
                        case.finish()
                    except Exception as error:
                        record.update(status='FAIL',actual=f'Evidence/process cleanup failure: {error}')
                    record['native_indexeddb']=case.native_idb
                    record['duration_seconds']=round(time.monotonic()-started,3)
                    record['evidence']=[str(p.relative_to(output)) for p in case.output.iterdir() if p.is_file()]
                    write_json(output/'results.json',report);print(record['id'],record['status'],flush=True)
        verify()
    except Exception as error:
        report['infrastructure_error']=f'{type(error).__name__}: {error}'
        for record in records:
            if record['status']=='NOT RUN':
                record.update(status='BLOCKED',actual=f'Infrastructure: {type(error).__name__}: {error}')
        (output/'infrastructure-error.txt').write_text(traceback.format_exc())
    finally:
        if server:
            server.shutdown();server.server_close()
        if thread:
            thread.join(timeout=5)
        write_json(output/'results.json',report)
    return 0 if all(row['status']=='PASS' for row in records) and not report.get('infrastructure_error') else 1


if __name__=='__main__':
    sys.exit(run())
