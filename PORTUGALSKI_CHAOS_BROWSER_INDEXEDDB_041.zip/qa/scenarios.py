"""Certification expectations shared by the runner and report."""
SCENARIOS = {
    'T01': ('Commit i restart procesu', 'Zatwierdzony stan i dziennik identyczne po zakończeniu procesu Chromium i uruchomieniu nowego PID z tym samym profilem i originem.'),
    'T02': ('Atomowy abort', 'Abort natywnej transakcji po success obu provisional requests; brak zmiany kv/state i events.'),
    'T03': ('Konflikt dwóch kart', 'Zapis ze starą rewizją odrzucony; historia zwycięzcy niezmieniona, szkic przegranej karty dostępny.'),
    'T04': ('Ochrona szkicu', 'Zatwierdzony szkic przeżywa pauzę, pomoc i restart. Przy abort niezapisany tekst zostaje w UI i pobranym pliku; refresh wymaga zabezpieczenia szkicu.'),
    'T05': ('Eksport i import JSON', 'Pobrany plik zawiera zatwierdzony stan i dziennik; import do pustego profilu odtwarza je dokładnie i przeżywa restart.'),
    'T06': ('Uszkodzona kopia', 'Uszkodzony JSON odrzucony w pustej i zapełnionej bazie; surowe dane obu object stores niezmienione.'),
    'T07': ('Zgodność 0.4 → 0.4.1', 'Historia i szkic z niezmienionego HTML 0.4 odczytane bez zmian przez HTML 0.4.1 na identycznym originie.'),
    'T08': ('Dwie misje po restarcie', 'Próby i szkice obu misji zachowane we wspólnym dzienniku po restarcie; przełączenie misji zachowuje wcześniejsze zdarzenia.'),
    'T09': ('Bez zewnętrznej sieci', 'Przy blokadzie żądań spoza localhost UI i natywny zapis działają po restarcie; kontrolny fetch zewnętrzny odrzucony.'),
    'T10': ('Limit szkicu', 'Przy rzeczywistym limicie 10000 zdarzeń szkic nie jest fałszywie potwierdzony; stan i dziennik niezmienione, szkic można pobrać.'),
}
