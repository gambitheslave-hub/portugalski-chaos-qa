#!/usr/bin/env bash
# Run from a reviewed QA checkout using an already authenticated Git/gh account.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
repo='gambitheslave-hub/portugalski-chaos-qa'
branch='qa/browser-indexeddb-041'
test "$(git branch --show-current)" = "$branch"
test -z "$(git status --porcelain)" || { echo 'Commit or preserve outstanding changes before publishing.' >&2; exit 1; }
origin=$(git remote get-url origin)
case "$origin" in
  "https://github.com/$repo.git"|"https://github.com/$repo"|"git@github.com:$repo.git") ;;
  *) echo 'Unexpected origin; publication stopped.' >&2; exit 1 ;;
esac
python3 scripts/qa.py verify
gh auth status >/dev/null
git push -u origin "HEAD:refs/heads/$branch"
if ! gh pr view "$branch" --repo "$repo" --json url --jq .url; then
  gh pr create --repo "$repo" --base main --head "$branch" --draft \
    --title 'QA: native Chromium and IndexedDB certification for 0.4.1' \
    --body-file docs/PR_BROWSER_INDEXEDDB_0_4_1.md
fi
head_sha=$(git rev-parse HEAD)
run_id=''
for attempt in {1..30}; do
  run_id=$(gh run list --repo "$repo" --branch "$branch" --commit "$head_sha" \
    --workflow qa.yml --limit 10 --json databaseId --jq '.[0].databaseId // empty')
  if [ -n "$run_id" ]; then break; fi
  sleep 2
done
test -n "$run_id" || { echo 'BLOCKED: no Actions run found after push/PR; inspect repository Actions settings.' >&2; exit 1; }
destination=".qa/downloaded/$run_id"
mkdir -p "$destination"
status=0
gh run watch "$run_id" --repo "$repo" --exit-status || status=$?
gh run view "$run_id" --repo "$repo" --json headSha,event,status,conclusion,jobs,url > "$destination/run.json"
gh run view "$run_id" --repo "$repo" --log > "$destination/actions.log" || status=1
gh run download "$run_id" --repo "$repo" --dir "$destination/artifacts" || status=1
printf 'Run: https://github.com/%s/actions/runs/%s\nEvidence: %s\n' "$repo" "$run_id" "$destination"
exit "$status"
