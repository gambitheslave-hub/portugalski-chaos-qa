#!/usr/bin/env python3
"""Verify the frozen release; run tests only in disposable copies."""
import argparse
import hashlib
import json
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / 'PORTUGALSKI_CHAOS_0_4_1_INTEGRITY_HARDENING_PAKIET.zip'
EXPECTED = '079234f995485697579d64741742758b345dd5bba9285afde8649546b6ba3b1f'
PACKAGE = 'PORTUGALSKI_CHAOS_0_4_1_HARDENING'
RELEASE = ROOT / 'releases' / '0.4.1'
HTML = 'URUCHOM_PORTUGALSKI_CHAOS_0_4_1_HARDENING_OFFLINE.html'
HTML_SHA = '98033fbebc8c5fefafdaa2d8e07e41faee25d5fc9681a132077b6417a9f75b87'
WORK = ROOT / '.qa'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def result_dir(label):
    base = WORK / 'results'
    base.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    return Path(tempfile.mkdtemp(prefix=f'{stamp}-{label}-', dir=base))


def manifest(root):
    expected = {}
    for line in (root / 'SHA256SUMS.txt').read_text().splitlines():
        if not line.strip():
            continue
        checksum, name = line.split(maxsplit=1)
        rel = PurePosixPath(name)
        if not re.fullmatch(r'[0-9a-f]{64}', checksum) or rel.is_absolute() or '..' in rel.parts:
            raise ValueError(f'Invalid manifest entry: {name}')
        if name in expected:
            raise ValueError(f'Duplicate manifest entry: {name}')
        path = root / name
        if path.is_symlink() or not path.is_file() or digest(path) != checksum:
            raise ValueError(f'SHA-256 mismatch: {path}')
        expected[name] = checksum
    return expected


def verify():
    if not ARCHIVE.is_file():
        raise FileNotFoundError(f'BLOCKED: archive unavailable: {ARCHIVE.name}')
    if digest(ARCHIVE) != EXPECTED:
        raise ValueError('BLOCKED: archive SHA-256 mismatch')
    WORK.mkdir(exist_ok=True)
    frozen = WORK / 'frozen'
    if not frozen.exists():
        with tempfile.TemporaryDirectory(prefix='extract-', dir=WORK) as staging:
            with zipfile.ZipFile(ARCHIVE) as archive:
                seen = set()
                for entry in archive.infolist():
                    name = PurePosixPath(entry.filename)
                    if (name.is_absolute() or '..' in name.parts or '\\' in entry.filename
                            or not name.parts or name.parts[0] != PACKAGE
                            or stat.S_ISLNK(entry.external_attr >> 16)
                            or entry.filename in seen):
                        raise ValueError(f'Unsafe ZIP entry: {entry.filename}')
                    seen.add(entry.filename)
                if archive.testzip() is not None:
                    raise ValueError('ZIP CRC mismatch')
                archive.extractall(staging)
            manifest(Path(staging) / PACKAGE)
            Path(staging).rename(frozen)
            # TemporaryDirectory tolerates the moved staging directory.
    package = frozen / PACKAGE
    with zipfile.ZipFile(ARCHIVE) as archive:
        if (package / 'SHA256SUMS.txt').read_bytes() != archive.read(f'{PACKAGE}/SHA256SUMS.txt'):
            raise ValueError('Frozen manifest differs from the verified archive')
    entries = manifest(package)
    actual = {str(p.relative_to(package)) for p in package.rglob('*') if p.is_file()}
    if actual != set(entries) | {'SHA256SUMS.txt'}:
        raise ValueError('Extracted package file set differs from the manifest')
    baseline = manifest(package / 'baseline')
    if digest(package / HTML) != HTML_SHA:
        raise ValueError('Production HTML SHA-256 differs from the required release')
    if RELEASE.exists():
        release_files = {str(p.relative_to(RELEASE)) for p in RELEASE.rglob('*') if p.is_file()}
        if release_files != actual:
            raise ValueError('Tracked release file set differs from the original ZIP')
        for name in actual:
            path = RELEASE / name
            if path.is_symlink() or path.read_bytes() != (package / name).read_bytes():
                raise ValueError(f'Tracked release differs from ZIP: {name}')
        print('PASS tracked releases/0.4.1: all 83 files byte-for-byte identical to ZIP', flush=True)
    print(f'PASS archive SHA-256; frozen manifest {len(entries)}/{len(entries)}; baseline {len(baseline)}/{len(baseline)}', flush=True)
    return package


def node_tests():
    package = verify()
    results = result_dir('node')
    commands = [
        ('engine', ['node', '--test', '--test-isolation=none', '--test-reporter=tap', 'tests/engine.test.cjs']),
        ('hardening', ['node', '--test', '--test-isolation=none', '--test-reporter=tap', 'tests/hardening.test.cjs']),
        ('stress', ['node', 'tests/stress_replay.cjs']),
        ('build', [sys.executable, 'tests/check_build.py']),
    ]
    summary = []
    try:
        with tempfile.TemporaryDirectory(prefix='node-', dir=WORK) as temporary:
            copy = Path(temporary) / PACKAGE
            shutil.copytree(package, copy)
            for label, command in commands:
                with (results / f'{label}.log').open('w') as log:
                    completed = subprocess.run(command, cwd=copy, stdout=log, stderr=subprocess.STDOUT, timeout=180)
                record = {'test': label, 'exit_code': completed.returncode}
                summary.append(record)
                if completed.returncode:
                    raise RuntimeError(f'{label} failed; see the new log')
                if label in ('engine', 'hardening'):
                    expected_count = 21 if label == 'engine' else 14
                    log_text = (results / f'{label}.log').read_text()
                    counts = dict(re.findall(r'^# (tests|pass|fail|skipped|cancelled) (\d+)$', log_text, re.M))
                    record['counts'] = counts
                    if counts != {'tests': str(expected_count), 'pass': str(expected_count), 'fail': '0', 'skipped': '0', 'cancelled': '0'}:
                        raise RuntimeError(f'{label}: unexpected test counts: {counts}')
                print(f'PASS {label}: {results / (label + ".log")}', flush=True)
            for path in [*copy.glob('src/*.js'), *copy.glob('tests/*.cjs'), copy / 'probes.cjs']:
                subprocess.run(['node', '--check', str(path)], check=True, timeout=30)
            if any(digest(copy / name) != checksum for name, checksum in manifest(package).items()):
                raise ValueError('Test copy changed a packaged file')
    finally:
        (results / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
        verify()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['verify', 'node'])
    args = parser.parse_args()
    try:
        node_tests() if args.command == 'node' else verify()
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, zipfile.BadZipFile) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
