#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
for tool in python3 node npm sha256sum unzip git; do
  command -v "$tool" >/dev/null
done
python3 -c 'import sys; assert sys.version_info >= (3, 12), "Python 3.12+ required"'
node -e 'if (Number(process.versions.node.split(".")[0]) !== 24 || !process.release.lts) throw Error("Node.js 24 LTS required")'
python3 --version
node --version
sha256sum -c SHA256SUMS.archive.txt
python3 scripts/qa.py verify

# Reuse an already installed, exactly pinned Playwright package when available.
# No browser or system package is installed in Codex Cloud.
python3 -m venv --system-site-packages .venv
if ! .venv/bin/python -c 'from importlib.metadata import version; assert version("playwright") == "1.62.0"' 2>/dev/null; then
  .venv/bin/python -m pip --timeout 20 --retries 1 install -r requirements-qa.txt
fi
.venv/bin/python -c 'from playwright.sync_api import sync_playwright; from importlib.metadata import version; print("Playwright", version("playwright"))'
printf '%s\n' 'READY: python3 scripts/qa.py node' 'Native Chromium: GitHub Actions workflow only.'
