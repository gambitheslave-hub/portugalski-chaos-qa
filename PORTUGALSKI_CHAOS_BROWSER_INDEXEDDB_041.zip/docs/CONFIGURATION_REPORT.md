# Raport konfiguracji PORTUGALSKI CHAOS — 2026-10-18 UTC

**Status: READY TO PUBLISH — konfiguracja lokalna i pliki do publikacji gotowe.**
**Publikacja ustawień środowiska Codex Cloud i uruchomienie GitHub Actions: niewykonane.**

## Repozytorium i dostęp do archiwum

- Repozytorium: https://github.com/gambitheslave-hub/portugalski-chaos-qa
- Sprawdzony commit `main`: `615965fa919e43ef49a8fd24c83ce82eb0116e24`.
- Archiwum rzeczywiście dostępne w tym commicie:
  `PORTUGALSKI_CHAOS_0_4_1_INTEGRITY_HARDENING_PAKIET.zip`, 432 705 bajtów.
- Git blob: `588166275216282a79ffd0363189b16ddb5816d6`; lokalne bajty zgodne.
- SHA-256: `079234f995485697579d64741742758b345dd5bba9285afde8649546b6ba3b1f`.
- ZIP CRC: PASS; manifest 0.4.1: **82/82 PASS**; manifest baseline: **38/38 PASS**.

Git z terminala nie mógł połączyć się z proxy środowiska. Pliki pobrano przez
działający konektor GitHub. Lokalny płytki checkout odtworzono z obiektów Git:
oryginalny podpisany commit, tree oraz oba bloby mają identyczne identyfikatory
jak w GitHub. Nie utworzono zastępczej historii i nie zmieniono zdalnego repozytorium.

## Sprawdzone środowisko

| Składnik | Wersja / stan |
| --- | --- |
| Linux | Debian GNU/Linux 13, x86_64 |
| Python | 3.12.14 |
| Node.js | 24.19.0, LTS Krypton |
| npm | 11.9.0 |
| Python Playwright | 1.62.0, dostępny przez `.venv/bin/python` |
| Git, unzip, sha256sum, venv | dostępne i sprawdzone |
| Setup | `bash scripts/codex/setup.sh`, PASS, ponowne uruchomienie PASS |
| Sekrety | niewymagane |

Setup nie instaluje przeglądarki. GitHub Actions instaluje Chromium i jego
biblioteki na runnerze Ubuntu 24.04. Nie instalowano aplikacji Android
i nie jest potrzebne urządzenie fizyczne.

## Walidacja

| Sprawdzenie | Wynik |
| --- | --- |
| Oryginalne testy silnika Node | **21/21 PASS**, brak skipped/cancelled |
| Oryginalne testy hardening Node | **14/14 PASS**, brak skipped/cancelled |
| Stress replay | **PASS**: 60 sesji, 2145 przejść, 657 prób |
| Integralność backupów stress | 60 poprawnych; 60 uszkodzonych odrzuconych |
| Odtwarzalny build | **PASS**, HTML identyczny bajtowo |
| Składnia JavaScript w aktywnym `src/`, testach i probes | **PASS** |
| Składnia skryptów Python i Bash | **PASS** |
| YAML workflow, wyzwalacze, uprawnienia odczytu | **PASS** lokalnej kontroli struktury |
| Import Python API Playwright | **PASS** |
| Brak ZIP lub zmieniona suma ZIP | **PASS**: proces zwraca błąd `BLOCKED` |
| Naruszenie rozpakowanego źródła albo manifestu | **PASS**: weryfikacja odrzuca zmianę |
| Natywny Chromium w GitHub Actions | **NOT RUN** — workflow przygotowany |

Nowe logi ostatniego kompletnego uruchomienia znajdują się w
`.qa/results/20261018T165147Z-node-bwqujyru/`. Są oddzielone od historii w ZIP
i ignorowane przez Git. Runner uruchamia każdy plik testowy we własnym procesie
Node, używa raportera TAP i sprawdza dokładną liczbę testów 21 i 14.

## Zakres zmian i publikacja

Dodano wyłącznie konfigurację, skrypty obsługi środowiska, nowy test CI
i dokumentację. Oryginalne README i ZIP są niezmienione względem `main`.
Gra, oryginalne testy, historyczne logi, raporty i baseline nie były edytowane.
Test odtwarzalności wykonuje zapis HTML w usuwanej kopii roboczej.

Gałąź lokalna: `codex/portugalski-chaos-cloud-setup`.
Zmiany są przygotowane do przeglądu i publikacji; nie wykonano push, PR ani merge.

Instrukcja konfiguracji i publikacji: [CODEX_CLOUD.md](CODEX_CLOUD.md).
Po publikacji plików ustaw w Codex Cloud polecenie setup:
`bash scripts/codex/setup.sh`, sprawdź jego podgląd i opublikuj wersję środowiska.
Nie istnieje potwierdzenie zapisania tych ustawień w panelu konta w tej sesji.
Pierwszy run Actions ma dopiero potwierdzić wynik natywnego Chromium.
