# Browser / IndexedDB QA 0.4.1

## Układ repozytorium

- Oryginalny ZIP w katalogu głównym: niezmieniony materiał wejściowy.
- `releases/0.4.1/`: wszystkie 83 pliki rozpakowane bajt w bajt z ZIP.
  `src/` i wydany HTML to 0.4.1; `tests/` to oryginalne testy;
  `SHA256SUMS.txt`, `RAPORT_QA_0_4_1.md` i `AUDYT_ASTRA_FUNDAMENT_0_4.md`
  zawierają oryginalny manifest i raporty; `baseline/` zachowuje wydanie 0.4.
- `qa/native_chromium.py`, `qa/scenarios.py`: nowe T01–T10, poza źródłami gry.
- `qa/report.py`: raport Markdown i CSV z rzeczywistych wyników lub jawnej blokady.
- `qa/android_emulator.cjs`: osobny eksperymentalny test emulatora.
- `evidence/`: dowody tej sesji; brak śladów wykonania Chromium.

`python3 scripts/qa.py verify` sprawdza ZIP, oba manifesty, wymagany SHA HTML
i zgodność każdego pliku `releases/0.4.1/` z ZIP. `python3 scripts/qa.py node`
uruchamia oryginalne testy w usuwanej kopii roboczej. Nie zmienia źródeł,
historycznych logów ani R12. Nie wykonuje migracji.

## Granice dowodu natywnego

Workflow `Browser IndexedDB 0.4.1 certification` instaluje prawdziwy Chromium
przez `python -m playwright install --with-deps chromium`. Jest to Pythonowy
odpowiednik instalacji silnika przez `npx playwright install`.

Każdy scenariusz ma osobny profil tymczasowy. Restarty zamykają persistent
context i cały proces Chromium; zapisany PID musi zniknąć z `/proc`,
a kolejny start musi mieć inny PID. Origin pozostaje ten sam. Odczyt kontrolny
obejmuje surowe `kv` i `events` z prawdziwych object stores oraz walidację
backupu przez wydany silnik. Nie ma fake-indexeddb ani adaptera pamięciowego.

T02 i część T04 dodają hak do natywnych metod `IDBObjectStore.add/put` w profilu
testowym. Oba rzeczywiste żądania najpierw raportują `success`; hak wykonuje
`transaction.abort()` przed commit. Oba object stores muszą pozostać identyczne
z poprzednim snapshotem. Hak nie zmienia pliku HTML ani implementacji storage.

T04 rozróżnia szkic zatwierdzony i niezapisany. Zatwierdzony przeżywa restart.
Przy błędzie niezapisany tekst ma pozostać w UI i pobieranym pliku ratunkowym;
nie oczekujemy automatycznego zachowania niezatwierdzonych danych po zabiciu
procesu. T10 używa faktycznego limitu aplikacji 10000 zdarzeń zapisanych do
IndexedDB; nie certyfikuje fizycznego wyczerpania przydziału dyskowego.

T07 uruchamia niezmieniony HTML 0.4, tworzy historię w natywnym IndexedDB,
zamyka Chromium i uruchamia HTML 0.4.1 w tym samym profilu i originie.
Wynik musi pozostać identyczny, bez migracji lub bezpośredniej edycji bazy.

T09 blokuje żądania stron spoza originu localhost i sprawdza kontrolny fetch.
To dowód działania strony bez zewnętrznej sieci przy HTTP localhost;
nie oznacza odłączenia całego systemu runnera od internetu.
`file://`, Android `content://`, fizyczny telefon i retencja 24 h to osobne
obszary i nie uzyskują statusu PASS na podstawie tych testów.

## Uruchomienie i artefakty

Push na `qa/browser-indexeddb-041` oraz PR uruchamiają workflow bez zmiany main.
Ręczny dispatch jest także zadeklarowany; dostępność przycisku zależy od
udostępnienia workflow na domyślnej gałęzi GitHub. Push/PR wystarcza do pierwszego
runu. Każdy job używa uprawnienia `contents: read`, bez sekretów i bez merge.

Artefakty mają run ID i attempt w nazwie; przechowywane są 30 dni:
`node-*`, `native-chromium-*`, `android-emulator-*`.
Każdy T01–T10 zachowuje trace osobno dla każdego uruchomienia procesu,
screenshot, log przeglądarki i przyczynę błędu. `results.json`, raport Markdown
i macierz CSV zawierają commit SHA, branch, run URL/ID, wersję Chromium,
system, SHA HTML, oczekiwany i faktyczny wynik oraz użycie natywnego IndexedDB.

Job emulatora startuje dopiero po sukcesie wszystkich T01–T10. Wykorzystuje
AVD API 35, Playwright Android i rzeczywistą aplikację Chrome z obrazu
`google_apis_playstore`. Brak Chrome, KVM, obrazu albo sterownika daje BLOCKED.
Po wejściu w natywny scenariusz niezgodność danych daje FAIL. Emulator nie jest
fizycznym telefonem, a test HTTP emulatora nie jest testem `content://`.

## Stan tej sesji

Tworzenie zdalnej gałęzi zostało odrzucone: HTTP 403
`Resource not accessible by integration` (`POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs`).
CLI dodatkowo zgłasza `socket: operation not permitted` przy połączeniu z proxy.
Nie utworzono zdalnego PR/runu i nie istnieją artefakty Chromium do pobrania.
T01–T10 mają BLOCKED, a Android NOT RUN. Kod przeglądarkowy został sprawdzony
statycznie, ale nie ma potwierdzenia jego poprawności z wykonania na runnerze.

## Bezpieczne zastosowanie

W czystym klonie repozytorium przejdź na osobną gałąź z commitu bazowego
`615965fa919e43ef49a8fd24c83ce82eb0116e24`, sprawdź patch, a następnie go zastosuj:

```bash
git switch -c qa/browser-indexeddb-041 615965fa919e43ef49a8fd24c83ce82eb0116e24
git apply --check /sciezka/browser-indexeddb-041.patch
git apply /sciezka/browser-indexeddb-041.patch
python3 scripts/qa.py verify
git add .
git commit -m "Add native browser and IndexedDB QA for frozen 0.4.1"
bash scripts/publish_browser_qa.sh
```

Skrypt używa istniejącego uwierzytelnienia Git/gh i nie pobiera ani nie zapisuje
haseł lub tokenów. Publikuje tylko wskazaną gałąź, tworzy draft PR, czeka na run,
pobiera logi i artefakty także po niepowodzeniu. Nie dotyka main.
Po runie należy odczytać poszczególne joby i wyniki T01–T10, poprawić wyłącznie
infrastrukturę przy jej awarii i wykonać retest. Aktualny raport BLOCKED
pozostaje historycznym dowodem tej sesji; nie zastępuje raportu z Actions.
