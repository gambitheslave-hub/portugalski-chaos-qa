Dodaje niezależne testy prawdziwego Chromium i IndexedDB dla zamrożonego wydania 0.4.1: T01–T10, izolowane profile, restarty procesów, atomowy abort, konflikt kart, eksport/import, zgodność 0.4 oraz limit dziennika. Wszystkie 83 pliki wydania są identyczne z oryginalnym ZIP; HTML, mechanika, treści, identyfikatory, historia i R12 pozostają bez zmian.

Workflow na Ubuntu 24.04 instaluje prawdziwy Chromium, zbiera trace/screenshoty/logi oraz raport Markdown i CSV z per-case statusami. Oddzielny job emulatora Android uruchamia się dopiero po sukcesie głównych testów.

Walidacja lokalna: integralność pakietu i HTML PASS; 21/21 + 14/14 Node PASS; stress i odtwarzalny build PASS; składnia skryptów i struktura workflow PASS. Natywne T01–T10 w sesji przygotowawczej: BLOCKED przez HTTP 403 integracji; Android NOT RUN. Wyniki Actions trzeba odczytać z artefaktów nowego runu; sama konfiguracja i testy Node nie certyfikują IndexedDB.
