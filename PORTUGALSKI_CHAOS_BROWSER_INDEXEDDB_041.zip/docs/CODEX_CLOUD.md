# PORTUGALSKI CHAOS — Codex Cloud

## Konfiguracja do publikacji

- Repozytorium: `gambitheslave-hub/portugalski-chaos-qa`, baza: `main`.
- Linux x86_64, Python 3.12+, Node.js 24 LTS (`.nvmrc`).
- Polecenie konfiguracji w ustawieniach Codex Cloud: `bash scripts/codex/setup.sh`.
- Polecenie testów: `python3 scripts/qa.py node`.
- Skrypt konfiguracji nie potrzebuje sekretów; nie pobiera Chromium ani aplikacji Android.
- Python Playwright: `1.62.0`, zapisany w `requirements-qa.txt`.

Wybierz obraz Linux udostępniający Python 3.12 z `venv`, Node 24 LTS,
Git, `unzip` i `sha256sum`. Pliki `.python-version` i `.nvmrc` wskazują wersje;
skrypt setup sprawdza dostępne narzędzia, ale nie zmienia systemowego Pythona ani Node.
W tej sesji wymagane narzędzia były już zainstalowane i zostały sprawdzone.
Playwright jest udostępniany przez lokalne `.venv` z przypiętą wersją.
Jeżeli obraz nie ma tej wersji pakietu, setup instaluje ją przez pip
(wymagany dostęp do `pypi.org` i `files.pythonhosted.org`).

Po opublikowaniu plików w repozytorium ustaw powyższe polecenie konfiguracji
w edytorze środowiska Codex Cloud, wykonaj podgląd setup i opublikuj wersję
środowiska. Ta sesja nie zapisuje ani nie publikuje ustawień konta Codex Cloud.

## Ochrona pakietu

Oryginalny ZIP oraz README pozostają bez zmian. SHA-256 pobranego archiwum:

```text
079234f995485697579d64741742758b345dd5bba9285afde8649546b6ba3b1f
```

To suma referencyjna obliczona z pliku pobranego z podanego repozytorium,
powiązanego z Git blob `588166275216282a79ffd0363189b16ddb5816d6`.
Nie jest odrębnym podpisem wydawcy. Wewnętrzne manifesty są dostarczone w ZIP.

```bash
sha256sum -c SHA256SUMS.archive.txt
python3 scripts/qa.py verify
python3 scripts/qa.py node
```

Brak archiwum albo niezgodna suma powodują przerwanie z kodem 1 i komunikatem
`BLOCKED`. Rozpakowanie sprawdza CRC i ścieżki wpisów ZIP. Katalog
`.qa/frozen/PORTUGALSKI_CHAOS_0_4_1_HARDENING/` zawiera kopię pakietu.
Każda weryfikacja porównuje manifest z oryginalnym ZIP, sprawdza 82 wpisy
manifestu 0.4.1 oraz 38 wpisów manifestu `baseline/`.

Testy Node i `tests/check_build.py` działają na kolejnej kopii tymczasowej.
Build może zapisać HTML wyłącznie w tej kopii; wynik musi pozostać identyczny.
Nowe logi trafiają do unikalnych katalogów `.qa/results/`. Żaden historyczny
plik `logs/`, `results/`, `history/` ani `baseline/` z ZIP nie jest nadpisywany.
Skrypt `probes.cjs` i historyczne testy przeglądarkowe pozostają bez zmian.

## GitHub Actions i natywny Chromium

Workflow `.github/workflows/qa.yml` uruchamia się przy PR, push do `main`
lub ręcznie po udostępnieniu go na domyślnej gałęzi.

1. Ubuntu 24.04, Python 3.12 i Node 24: integralność, 21 testów silnika,
   14 testów hardening, stress, odtwarzalność buildu i składnia JavaScript.
2. Po sukcesie: instalacja Python Playwright oraz Chromium wraz z bibliotekami
   systemowymi na runnerze GitHub Actions.
3. `qa/native_chromium.py` udostępnia niezmieniony HTML przez HTTP
   na `127.0.0.1` i używa prawdziwego IndexedDB oraz profili tymczasowych.
   Sprawdza szkic po przeładowaniu i ponownym uruchomieniu Chromium,
   rzeczywisty plik eksportu JSON oraz import do osobnego pustego profilu.
4. Nowe logi, JSON i zrzut ekranu są artefaktami Actions przechowywanymi 14 dni.

Nowy test wymaga `GITHUB_ACTIONS=true`; setup nie uruchamia przeglądarki lokalnie.
Nie stosuje adaptera pamięciowego, `page.set_content` ani zmian w źródłach gry.
Nie certyfikuje `file://`, `content://`, Androida, konfliktów kart ani retencji 24 h.
Historyczne wyniki dotyczące tych obszarów zachowują pierwotne znaczenie.

## Publikacja

Sprawdź raport `docs/CONFIGURATION_REPORT.md` i publikuj wyłącznie dodane
pliki konfiguracji, skryptów i dokumentacji. `.qa/` oraz `.venv/` są ignorowane.
Po publikacji PR workflow wykona pierwszą walidację natywnego Chromium;
do jej zakończenia wynik E2E to **NOT RUN**, a nie PASS.
