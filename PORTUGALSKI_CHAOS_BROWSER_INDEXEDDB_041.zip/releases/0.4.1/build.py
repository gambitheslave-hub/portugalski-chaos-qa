from pathlib import Path
import hashlib
root=Path(__file__).parent
content=(root/'src/template.html').read_text(encoding='utf-8')
for name in ('catalog','engine','storage','ui'):
    source=(root/f'src/{name}.js').read_text(encoding='utf-8')
    if '</script' in source.lower():raise ValueError('Niebezpieczne zakończenie skryptu')
    content=content.replace(f'/*__{name.upper()}__*/',source)
if '/*__' in content:raise ValueError('Brak podstawienia modułu')
out=root/'URUCHOM_PORTUGALSKI_CHAOS_0_4_1_HARDENING_OFFLINE.html'
out.write_text(content,encoding='utf-8')
print('BUILT',out.name,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
