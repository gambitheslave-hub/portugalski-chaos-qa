'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const E=require('../src/engine.js');
const C=require('../src/catalog.js');
const ROOT=path.resolve(__dirname,'..');
const HTML=fs.readFileSync(path.join(ROOT,'URUCHOM_PORTUGALSKI_CHAOS_0_4_1_HARDENING_OFFLINE.html'),'utf8');
const scripts=[...HTML.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
assert.equal(scripts.length,4);
const tick=async()=>{for(let i=0;i<15;i++)await new Promise(r=>setImmediate(r))};
function reachLimit(){let state=E.fresh(),events=[];for(let i=1;i<=10000;i++){
 const action='SELECT',payload={missionId:'SC04.STORM'};
 // Need active question at limit, so START at event #2.
 const a=i===2?'START':action,p=i===2?{lesson:false}:payload;
 const out=E.reduce(state,a,p,i);state=out.next;events.push(out.event);
 }const backup={kind:'CHAOS_04_BACKUP',version:E.SCHEMA,state,events};assert.equal(E.validateBackup(backup),true);return backup;
}
function prepare(){let state=E.fresh();for(const [a,p,t] of [['SELECT',{missionId:'SC04.STORM'},1],['START',{lesson:false},2]])state=E.reduce(state,a,p,t).next;return state}
async function boot(initial,opts={}){
 class N{constructor(tag){this.tag=tag;this.children=[];this.dataset={};this.textContent='';this.value='';this.disabled=false;}append(...n){this.children.push(...n)}replaceChildren(...n){this.children=n}remove(){}click(){this.onclick?.()}}
 const body=new N('body'),toolbar=new N('div');body.append(toolbar);
 for(const id of ['content','status','save-state','progress','missions','pause','export','refresh','import']){const n=new N(['missions','pause','export','refresh'].includes(id)?'button':id==='import'?'input':'div');n.id=id;if(id==='import')n.type='file';body.append(n);}
 const all=()=>{const list=[];function rec(n){list.push(n);n.children.forEach(rec)}rec(body);return list};
 const doc={body,createElement:t=>new N(t),getElementById:id=>all().find(n=>n.id===id),querySelector:()=>toolbar,querySelectorAll:q=>all().filter(n=>q.startsWith('textarea')?n.tag==='textarea'||n.tag==='input'&&n.type!=='file':n.tag==='button'||n.tag==='select'||n.tag==='input'&&n.type==='file')};
 let committed=structuredClone(initial),backupCalls=0,downloads=0,confirmCalls=0,commitCalls=0;
 const S={open:async()=>({close(){}}),read:async()=>structuredClone(committed),commit:async(_db,rev,next)=>{commitCalls++;if(opts.failCommit)throw Error('INJECTED_CONFLICT');committed=next},backup:async()=>{backupCalls++;return {kind:'BACKUP',state:structuredClone(committed)}},restore:async()=>{}};
 const ctx={document:doc,Date,console,setTimeout,clearTimeout,Blob,URL:{createObjectURL:()=>{if(opts.failDownload)throw Error('INJECTED_DOWNLOAD_FAILURE');downloads++;return 'blob:mock'},revokeObjectURL(){}},addEventListener(){},confirm:()=>{confirmCalls++;return opts.confirm??true}};
 vm.createContext(ctx);vm.runInContext(scripts[0],ctx);vm.runInContext(scripts[1],ctx);ctx.ChaosStorage04=S;vm.runInContext(scripts[3],ctx);await tick();
 return {get:id=>doc.getElementById(id),state:()=>committed,stats:()=>({backupCalls,downloads,confirmCalls,commitCalls}),async click(id){const n=doc.getElementById(id);assert.ok(n,'missing '+id);assert.equal(n.disabled,false,'disabled '+id);await n.onclick();await tick()},type(id,text){const n=doc.getElementById(id);assert.ok(n,'missing '+id);n.value=text;n.oninput()}};
}
// Contract tests: no mutation of shipping catalog is allowed during a negative test.
function invalidCatalog(edit){const m=C.missions[0],before=structuredClone(m);try{edit(m);assert.throws(()=>E.validateCatalog());}finally{for(const k of Object.keys(m))m[k]=before[k];assert.equal(E.validateCatalog(),true)}}
test('A04-01: reject negative revisions before SELECT, valid zero and maximum',()=>{
 const state=E.fresh();for(const rev of [-1,-20]){const bad=structuredClone(state);bad.revision=rev;assert.throws(()=>E.assertValid(bad));assert.throws(()=>E.reduce(bad,'SELECT',{missionId:'SC04.STORM'},1));}
 assert.equal(E.assertValid(state),true);const z=E.reduce(state,'SELECT',{missionId:'SC04.STORM'},1);assert.equal(z.event.id,1);
 const max=reachLimit().state;assert.equal(max.revision,10000);assert.equal(E.assertValid(max),true);assert.throws(()=>E.reduce(max,'SELECT',{missionId:'SC04.STORM'},10001));
});
test('A04-02: reject invalid mission version independently',()=>invalidCatalog(m=>{m.version=-7}));
test('A04-02: reject blank competency ID independently',()=>invalidCatalog(m=>{m.competency_id=''}));
test('A04-02: reject nonstring target level independently',()=>invalidCatalog(m=>{m.target_level=123}));
test('A04-02: reject invalid prerequisites and duplicate prerequisites',()=>{invalidCatalog(m=>{m.prerequisite_ids=[null]});invalidCatalog(m=>{m.prerequisite_ids=['PTBR.X','PTBR.X']});});
test('A04-02: accept external dependency IDs that do not yet map to missions',()=>{assert.equal(E.validateCatalog(),true);assert.deepEqual(C.missions[0].prerequisite_ids,['PTBR.TENSE.PRESENT.2','PTBR.TENSE.PERF.3']);});
test('A04-02: reject inconsistent tense form keys, answer missing from selected tense',()=>{
 invalidCatalog(m=>{m.items[3].slots[0].formsByTense.perfeito=['bla'] ;m.items[3].slots[0].formsByTense.imperfeito=['foo']});
 invalidCatalog(m=>{m.items[3].slots[0].formsByTense.hypothetical=['other']});
});
test('A04-02: reject mis-typed goals, rubric version and item IDs',()=>{
 invalidCatalog(m=>{m.learning_goal=12});invalidCatalog(m=>{m.rubric_version=''});invalidCatalog(m=>{m.items[1].id=' '});
});
test('A04-03: reachable event limit cannot claim failed DRAFT is saved, pause prevented, refresh gated, scratch retained',async()=>{
 const p=await boot(reachLimit().state);
 p.type('field-0','UNSAVED_AT_LIMIT');await p.click('pause');
 assert.equal(p.state().runs['SC04.STORM'].draft,null);
 assert.match(p.get('save-state').textContent,/NIEZAPISANY|niepowodzenie/i);
 assert.doesNotMatch(p.get('save-state').textContent,/Wszystkie zlecone zmiany zatwierdzone/);
 assert.equal(p.get('resume'),undefined,'pause never confirmed');
 assert.equal(p.get('field-0').value,'UNSAVED_AT_LIMIT');
 await p.click('refresh');assert.equal(p.get('field-0').value,'UNSAVED_AT_LIMIT');
 assert.equal(p.stats().confirmCalls,0,'refresh blocked until draft download');
 await p.click('draft-download');await p.click('refresh');
 assert.equal(p.stats().confirmCalls,1);assert.equal(p.get('field-0').value,'');
});
test('A04-04: exported committed backup is downloaded after injected commit failure',async()=>{
 const p=await boot(prepare(),{failCommit:true});p.type('field-0','UNSAVED');await p.click('pause');
 assert.match(p.get('status').textContent,/INJECTED_CONFLICT|nie zosta/i);assert.equal(p.get('export').disabled,false);
 await p.click('export');assert.equal(p.stats().backupCalls,1);assert.equal(p.stats().downloads,1);
 assert.match(p.get('status').textContent,/zatwierdzonej|ZATWIERDZONEJ/);
 await p.click('refresh');assert.match(p.get('status').textContent,/WSTRZYMANE/);
 assert.equal(p.get('field-0').value,'UNSAVED');
});
test('A04-03: malformed draft is a protected save failure, not just an invalid ANSWER',async()=>{
 const p=await boot(prepare());p.type('field-0','x'.repeat(121));await p.click('pause');
 assert.match(p.get('status').textContent,/NIEZAPISANY|nie został/);
 assert.match(p.get('save-state').textContent,/niepowodzenie|NIEZAPISANY/i);
 assert.equal(p.get('resume'),undefined);
 assert.equal(p.get('field-0').value,'x'.repeat(121));
 await p.click('refresh');assert.match(p.get('status').textContent,/WSTRZYMANE/);
});
test('A04-03: failed draft-download does not authorize destructive refresh',async()=>{
 const p=await boot(reachLimit().state,{failDownload:true});p.type('field-0','DRAFT_TO_PROTECT');await p.click('pause');
 await p.click('draft-download');assert.match(p.get('status').textContent,/Nie udało/);
 await p.click('refresh');assert.match(p.get('status').textContent,/WSTRZYMANE/);
 assert.equal(p.stats().confirmCalls,0);assert.equal(p.get('field-0').value,'DRAFT_TO_PROTECT');
});
test('invalid submitted answer does not cause false fatal write failure',async()=>{
 const p=await boot(prepare());
 const form=p.get('answer').tag==='button'?null:null;
 assert.ok(p.get('field-0')); // Simulate a rejected ANSWER through form submit with blank.
 const f=p.get('content').children[0].children.find(n=>n.tag==='form');
 await f.onsubmit({preventDefault(){}});await tick();
 assert.match(p.get('status').textContent,/Polecenie odrzucone/);
 assert.match(p.get('save-state').textContent,/Odrzucono/);
 assert.equal(p.get('refresh').disabled,false); // no fatal lock for a bad answer
});
test('original 0.4 source and 0.4.1 patch preserve state format, catalog, storage name',()=>{
 const old=fs.readFileSync(path.join(ROOT,'baseline/src/storage.js'),'utf8');const now=fs.readFileSync(path.join(ROOT,'src/storage.js'),'utf8');assert.equal(old,now);
 assert.equal(E.VERSION,'foundation-0.4.0');assert.equal(E.SCHEMA,5);assert.equal(C.VERSION,'registry-0.4.0');
 assert.equal(fs.readFileSync(path.join(ROOT,'baseline/src/catalog.js'),'utf8'),fs.readFileSync(path.join(ROOT,'src/catalog.js'),'utf8'));
});
