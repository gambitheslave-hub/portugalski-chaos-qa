"""Chromium DOM only: substitutes an in-memory journal for IndexedDB.
NEVER describe this as a real IndexedDB test or offline file:// certification.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).parents[1]
html=(root/'src/template.html').read_text()
mock=r'''(function(root){'use strict';const E=root.ChaosEngine04;let state=E.fresh(),events=[];
root.ChaosStorage04={NAME:'MEMORY_ONLY_NOT_INDEXEDDB',open:async()=>({}),read:async()=>state,
commit:async(_db,expected,next,event)=>{if(expected!==state.revision)throw Error('MEMORY_CONFLICT');const actual=E.reduce(state,event.action,event.payload,event.at);if(E.canon(actual.next)!==E.canon(next))throw Error('INVALID_NEXT');state=next;events.push(event);return next;},
backup:async()=>({kind:'CHAOS_04_BACKUP',version:E.SCHEMA,state,events}),restore:async(_db,b)=>{E.validateBackup(b);if(events.length)throw Error('NONEMPTY');state=b.state;events=b.events;return state;}};
})(globalThis);'''
for name in ('catalog','engine','ui'):
    html=html.replace('/*__'+name.upper()+'__*/',(root/f'src/{name}.js').read_text())
html=html.replace('/*__STORAGE__*/',mock)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':360,'height':740},accept_downloads=True)
    page_errors=[]
    page.on('pageerror',lambda error:page_errors.append(str(error)))
    page.set_content(html)
    page.get_by_role('heading',name='Wybierz ścieżkę nauki').wait_for()
    assert page.locator('.mission').count()==2
    print('PASS Chromium DOM: two-mission registry navigation')
    page.locator('[id="select-SC04.STORM"]').click()
    page.locator('#recall').click()
    page.locator('#answer').click()
    assert 'Polecenie odrzucone' in page.locator('#status').inner_text()
    assert page.locator('#answer').is_enabled()
    print('PASS Chromium DOM: blank submission does not freeze UI')
    page.locator('#field-0').fill('acaba')
    page.locator('#answer').click()
    page.locator('#repair').wait_for()
    page.locator('#repair').click()
    page.locator('#field-0').fill('acabou')
    page.locator('#answer').click()
    page.locator('#next').wait_for()
    page.locator('summary').click()
    assert 'Próba naprawcza' in page.locator('details').inner_text()
    print('PASS Chromium DOM: wrong + repair retained')
    page.locator('#next').click()
    page.locator('#field-0').fill('brinc')
    page.locator('#help').click()
    page.locator('#back').wait_for()
    page.locator('#back').click()
    assert page.locator('#field-0').input_value()=='brinc'
    print('PASS Chromium DOM: pending draft survives help/back')
    page.locator('#missions').click()
    page.locator('.mission').first.wait_for()
    page.locator('[id="select-SC04.FEIRA"]').click()
    page.locator('#learn').click()
    page.locator('#back').click()
    for a in ('de','para','por'):
        page.locator('#field-0').fill(a)
        page.locator('#answer').click()
        page.locator('#next').wait_for()
        page.locator('#next').click()
    page.locator('#field-0').fill('de')
    page.locator('#field-1').fill('para')
    page.locator('#answer').click()
    page.locator('#next').click()
    page.locator('#skip-open').wait_for()
    page.locator('#skip-open').click()
    assert 'NOT_ATTEMPTED' in page.locator('#content').inner_text()
    print('PASS Chromium DOM: second mission through skip-open')
    page.locator('#missions').click()
    page.locator('[id="select-SC04.STORM"]').click()
    assert page.locator('#field-0').input_value()=='brinc'
    print('PASS Chromium DOM: switching missions preserves first draft')
    with page.expect_download() as dl:
        page.locator('#export').click()
    download=dl.value
    assert download.suggested_filename=='PORTUGALSKI_CHAOS_04_BACKUP.json'
    print('PASS Chromium DOM: JSON download initiated (in-memory adapter only)')
    for width in (320,360,390,412):
        page.set_viewport_size({'width':width,'height':740})
        measured=page.evaluate('({inner:innerWidth,scroll:document.documentElement.scrollWidth})')
        assert measured['scroll']<=measured['inner'],f'horizontal overflow at {width}: {measured}'
    print('PASS Chromium DOM: four mobile widths without horizontal overflow')
    assert not page_errors,page_errors
    print('PASS Chromium DOM: no uncaught JS exceptions')
    browser.close()
