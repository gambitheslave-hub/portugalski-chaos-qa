from pathlib import Path
from playwright.sync_api import sync_playwright
path=Path(__file__).parents[1]/'URUCHOM_PORTUGALSKI_CHAOS_0_4_1_HARDENING_OFFLINE.html'
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page()
 try:
  page.goto(path.as_uri(),wait_until='domcontentloaded',timeout=8000)
  print('FILE_NAVIGATION','PASS',page.url)
  print('STORAGE_STATUS',page.locator('#status').inner_text())
 except Exception as e:
  print('FILE_NAVIGATION_BLOCKED',str(e).splitlines()[0])
 page2=browser.new_page()
 page2.set_content(path.read_text())
 print('SET_CONTENT_ORIGIN',page2.evaluate('location.origin'))
 print('SET_CONTENT_NATIVE_IDB_STATUS',page2.locator('#status').inner_text())
 browser.close()
