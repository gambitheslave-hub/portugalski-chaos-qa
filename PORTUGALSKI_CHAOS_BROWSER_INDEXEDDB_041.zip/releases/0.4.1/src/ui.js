(function(){'use strict';
const E=globalThis.ChaosEngine04,S=globalThis.ChaosStorage04,$=id=>document.getElementById(id),container=$('content');
let db=null,state=E.fresh(),queue=Promise.resolve(),pending=0,failed=false,paused=false,draft=null,timer=null,showDashboard=false;
let dirty=false,draftSecured=false,lastRejected=false;
const node=(tag,txt)=>{const n=document.createElement(tag);if(txt!==undefined)n.textContent=txt;return n;};
const btn=(id,txt,fn)=>{const b=node('button',txt);b.type='button';b.id=id;b.onclick=fn;return b;};
const add=(el,...els)=>{el.append(...els);return el;};
function notice(msg,bad=false){$('status').textContent=msg;$('status').dataset.kind=bad?'error':'ok';}
function lock(){document.querySelectorAll('button,input[type=file],select').forEach(n=>n.disabled=pending>0||failed);document.querySelectorAll('textarea,input:not([type=file])').forEach(n=>n.readOnly=pending>0||failed);if(failed){$('refresh').disabled=false;$('export').disabled=false;$('draft-download').disabled=false;}}
function payloadDraft(){return JSON.parse(JSON.stringify(draft));}
function flush(){if(timer){clearTimeout(timer);timer=null;return send('DRAFT',payloadDraft());}return Promise.resolve(true);}
function send(action,payload={},done){
 if(failed||!db)return Promise.resolve(false);
 if(action!=='DRAFT')flush();
 pending++;lock();$('save-state').textContent='Zapisuję — nie zamykaj karty.';
 queue=queue.then(async()=>{
  try{
   if(failed)return false;
   lastRejected=false;
   let out;
   try{out=E.reduce(state,action,payload,Math.max(Date.now(),state.lastClock));}
   catch(err){
    lastRejected=true;
    if(action==='DRAFT'){
     failed=true;dirty=true;
     notice('SZKIC NIEZAPISANY. Nie odświeżaj ani nie zamykaj karty. Pobierz bieżący szkic. Przyczyna: '+err.message,true);
    }else notice('Polecenie odrzucone — zmiany nie zapisano: '+err.message,true);
    return false;
   }
   try{await S.commit(db,state.revision,out.next,out.event);}
   catch(err){
    failed=true;lastRejected=true;
    if(action==='DRAFT')dirty=true;
    notice('ZAPIS NIEPOTWIERDZONY. Możesz pobrać osobno zatwierdzoną historię i bieżący szkic. Przyczyna: '+err.message,true);
    return false;
   }
   state=out.next;
   if(action==='DRAFT')dirty=false;
   else draft=state.selected?state.runs[state.selected].draft:null;
   notice('Zapis potwierdzony · rewizja '+state.revision);
   done?.();return true;
  }finally{
   pending--;lock();
   $('save-state').textContent=failed?'UWAGA: zapis niepowodzenie / szkic do zabezpieczenia przed odświeżeniem.':
     pending?'Zapis w toku.':dirty?'Szkic NIEZAPISANY — nie odświeżaj.':
     lastRejected?'Odrzucono ostatnie polecenie; ta zmiana NIE jest zapisana.':
     'Wszystkie zlecone zmiany zatwierdzone.';
  }
 });return queue;
}
function draftChange(target,values){draft={target,values};dirty=true;draftSecured=false;clearTimeout(timer);$('save-state').textContent='Szkic niezatwierdzony — oczekuje na zapis.';timer=setTimeout(()=>{timer=null;send('DRAFT',payloadDraft());},350);}
function download(data,name){const u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'})),a=node('a');a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000);}
function missionPick(){container.replaceChildren();const p=node('section');p.className='panel';p.append(node('h2','Wybierz ścieżkę nauki'));p.append(node('p','Obie ścieżki korzystają z tego samego silnika i oddzielnej bazy 0.4. To eksperyment, nie zamiennik R12.'));
for(const m of E.C.missions){const r=state.runs[m.id],card=node('div');card.className='mission';card.append(node('h3',m.title),node('p','Rozdział '+m.chapter_id+' · '+m.learning_goal),node('p','Postęp: '+r.phase+' · próby: '+r.attempts.length),btn('select-'+m.id,'Otwórz ścieżkę',()=>send('SELECT',{missionId:m.id},()=>{showDashboard=false;render();})));p.append(card);}p.append(node('p','Zawartość oznaczona REVIEW_PENDING. Nie interpretuj ćwiczeń jako potwierdzenia poziomu A2/B1.'));container.append(p);lock();}
function fieldsForm(p,m,r,t){p.append(node('h2',r.repair?'Powtórna próba — po pokazanym kluczu':t.scene),node('p',t.prompt));const f=node('form'),inputs=[],choosers=[];const existing=draft?.target===t.id?draft.values:r.draft?.target===t.id?r.draft.values:[];
for(let i=0;i<t.slots.length;i++){const slot=t.slots[i],label=node('label',slot.name),inp=node('input');inp.id='field-'+i;label.htmlFor=inp.id;inp.lang='pt-BR';inp.autocomplete='off';inp.maxLength=120;inp.value=existing[i]??'';add(f,label,inp);inputs.push(inp);}
if(t.evaluation==='ASPECT_AND_FORM'){for(let i=0;i<t.slots.length;i++){const label=node('label','Wybierz czas: '+t.slots[i].name),s=node('select');s.id='tense-'+i;label.htmlFor=s.id;for(const [value,txt] of [['','— wybierz —'],['imperfeito','Pretérito imperfeito'],['perfeito','Pretérito perfeito']]){const o=node('option',txt);o.value=value;s.append(o);}s.value=existing[t.slots.length+i]??'';add(f,label,s);choosers.push(s);}}
const save=()=>draftChange(t.id,[...inputs.map(x=>x.value),...choosers.map(x=>x.value)]);inputs.forEach(x=>x.oninput=save);choosers.forEach(x=>x.onchange=save);const submit=btn('answer','Zapisz i sprawdź',()=>{});submit.type='submit';f.append(submit);f.onsubmit=e=>{e.preventDefault();send('ANSWER',{forms:inputs.map(x=>x.value),...(choosers.length?{tenses:choosers.map(x=>x.value)}:{})},render);};p.append(f,btn('help','Zachowaj szkic i pokaż regułę',()=>send('HELP',{},render)),node('p','Ścisłe klucze oceniają podane luki, a nie każdą poprawną parafrazę. Pomoc i pokazane rozwiązania obniżają niezależność dowodu.'));
}
function feedback(p,m,r,t){const a=r.attempts.at(-1);p.append(node('h2',a.autoMatch?'Zgodne z kluczem':'Niepasujące do klucza'),node('p','Wartość dowodu: '+E.evidenceText(a.evidence)));for(let i=0;i<t.slots.length;i++){const slot=t.slots[i];p.append(node('p','Twoja forma: '+a.forms[i]+'. Klucz: '+slot.answers[0]+'. '+slot.why));if(a.aspect)p.append(node('p','Luka '+(i+1)+': dobór czasu '+(a.aspect[i]?'zgodny':'niezgodny')+'; odmiana w wybranym czasie '+(a.morphology[i]?'zgodna':'niezgodna')+'.'));}p.append(node('p',t.explanation));if(r.phase==='feedback'){if(!a.autoMatch)p.append(btn('repair','Spróbuj ponownie (wynik pierwotny zostaje)',()=>send('REPAIR',{},render)));p.append(btn('next',a.autoMatch?'Dalej':'Kontynuuj bez zaliczenia',()=>send('NEXT',{},render)));}}
function render(){if(!db){container.replaceChildren(node('p','Baza niedostępna; misja nie została uruchomiona.'));return;}if(showDashboard||!state.selected){missionPick();return;}const m=E.mission(state.selected),r=state.runs[m.id];container.replaceChildren();const p=node('section');p.className='panel';container.append(p);p.append(node('p',m.title+' · kompetencja '+m.competency_id));
if(paused){p.append(node('h2','Pauza'),node('p','Szkic i postępy zatwierdzono przed pauzą.'),btn('resume','Wróć',()=>{paused=false;render();}));lock();return;}
switch(r.phase){
case 'intro':p.append(node('h2',m.narrative_goal),node('p','Cel: '+m.learning_goal),node('p','Nowy temat? Zacznij od lekcji. Znasz już temat? Możesz spróbować z pamięci.'),btn('learn','Najpierw lekcja',()=>send('START',{lesson:true},render)),btn('recall','Znam już — przypomnienie',()=>send('START',{lesson:false},render)));break;
case 'lesson':p.append(node('h2','Reguła i kontekst'));for(const line of m.lesson)p.append(node('p',line));p.append(btn('back','Ukryj lekcję i wróć',()=>send('BACK',{},render)));break;
case 'question':fieldsForm(p,m,r,m.items[r.index]);break;
case 'feedback':feedback(p,m,r,m.items[r.index]);break;
case 'open':{p.append(node('h2','Użyj języka w wiadomości'),node('p',m.open_prompt));const l=node('label','Twoja wypowiedź (bez automatycznej oceny)'),area=node('textarea');l.htmlFor='open-text';area.id='open-text';area.lang='pt-BR';area.maxLength=4000;area.rows=5;area.value=draft?.target==='open'?draft.values[0]:r.draft?.target==='open'?r.draft.values[0]:'';area.oninput=()=>draftChange('open',[area.value]);p.append(l,area,btn('finish','Zapisz jako UNVERIFIED',()=>send('SAVE_OPEN',{text:area.value},render)),btn('skip-open','Pomiń — NOT_ATTEMPTED',()=>send('SKIP_OPEN',{},render)));break;}
case 'complete':p.append(node('h2',r.openText.status==='NOT_ATTEMPTED'?'Wypowiedź pominięta':'Wypowiedź zachowana'),node('p','Status: '+r.openText.status),node('p','Odroczona próba będzie dostępna po 24 godzinach według zegara urządzenia. Nie jest to certyfikat retencji.'));if(E.due(r,Date.now()))p.append(btn('delayed','Wykonaj próbę odroczoną',()=>send('START_DELAYED',{},render)));else p.append(btn('date','Sprawdź termin',render));break;
case 'delayed':fieldsForm(p,m,r,m.delayed);break;
case 'delayed_feedback':feedback(p,m,r,m.delayed);p.append(node('p','To pojedyncza obserwacja odroczona, nie dowód opanowania całej kompetencji.'));break;
}
const history=node('details'),summary=node('summary','Historia prób i ujawnionych rozwiązań');history.append(summary);for(const a of r.attempts)history.append(node('p',a.itemId+' · '+(a.autoMatch?'zgodne':'niezgodne')+' · '+E.evidenceText(a.evidence)));p.append(history);$('progress').textContent='Misja '+m.id+' · etap '+r.phase+' · globalna rewizja '+state.revision;lock();}
$('missions').onclick=async()=>{flush();await queue;if(!db||failed||pending||dirty){notice('Nie można zmienić widoku bez zatwierdzenia szkicu. Pobierz szkic, jeśli zapis się nie udał.',true);return;}paused=false;showDashboard=true;render();};
$('pause').onclick=async()=>{flush();await queue;if(failed||pending||dirty||!db){notice('Nie można potwierdzić pauzy: szkic nie został bezpiecznie zapisany. Pobierz go osobno.',true);return;}paused=true;render();};
$('export').onclick=async()=>{
 flush();await queue;
 if(!db){notice('Eksport niedostępny: brak bazy.',true);return;}
 try{
  const b=await S.backup(db);
  download(b,'PORTUGALSKI_CHAOS_04_BACKUP.json');
  notice((dirty||failed?'Uruchomiono pobieranie OSTATNIEJ ZATWIERDZONEJ historii. Bieżący szkic nie musi znajdować się w tej kopii — pobierz go osobno.':'Uruchomiono pobieranie zatwierdzonej historii.')+' Sprawdź plik w Pobranych.',dirty||failed);
 }catch(e){notice('Eksport zatwierdzonej historii niedostępny: '+e.message+'. Bieżący szkic można pobrać osobno.',true);}
};
const draftButton=btn('draft-download','Pobierz bieżący szkic',()=>{
 try{
  download({kind:'CHAOS_04_UNCOMMITTED_DRAFT',draft,selected:state.selected,baseRevision:state.revision},'CHAOS_04_SZKIC.json');
  if(draft!==null)draftSecured=true;
  notice('Uruchomiono pobieranie szkicu. Sprawdź plik w Pobranych; dopiero potem decyduj o odświeżeniu.',dirty||failed);
 }catch(err){draftSecured=false;notice('Nie udało się rozpocząć pobierania szkicu: '+err.message,true);}
});document.querySelector('.toolbar').append(draftButton);
$('refresh').onclick=async()=>{
 flush();await queue;
 if(pending||!db)return;
 if(dirty||failed){
  if(draft!==null&&!draftSecured){notice('ODŚWIEŻENIE WSTRZYMANE: najpierw pobierz bieżący szkic i sprawdź plik. Zatwierdzony zapis nie obejmuje wszystkich zmian.',true);return;}
  if(!confirm('Odświeżenie zastąpi formularz ostatnim zatwierdzonym stanem. Czy pobrano i sprawdzono kopię niezapisanego szkicu (jeśli istnieje)?')){
   notice('Odświeżenie anulowane. Niezapisany tekst pozostaje w pamięci tej karty.',true);return;
  }
 }
 try{
  const read=await S.read(db);
  state=read;draft=state.selected?state.runs[state.selected].draft:null;
  failed=false;dirty=false;draftSecured=false;lastRejected=false;paused=false;render();
  notice('Odczyt i replay dziennika zakończone.');
 }catch(e){notice('Odczyt niemożliwy: '+e.message,true);}
};
$('import').onchange=async e=>{const file=e.target.files[0];if(!file||!db)return;flush();await queue;if(failed||pending)return;try{if(file.size>30*1024*1024)throw Error('Kopia przekracza 30 MB');const b=JSON.parse(await file.text());E.validateBackup(b);state=await S.restore(db,b);draft=state.selected?state.runs[state.selected].draft:null;paused=false;render();notice('Dziennik i stan odtworzone w pustej bazie 0.4.');}catch(err){notice('Import odrzucony: '+err.message,true);}e.target.value='';};
addEventListener('beforeunload',e=>{if(pending||failed||timer||dirty){e.preventDefault();e.returnValue='';}});
(async()=>{try{db=await S.open();state=await S.read(db);draft=state.selected?state.runs[state.selected].draft:null;notice('Nowa, oddzielna baza 0.4 dostępna.');$('save-state').textContent='Dziennik odczytany.';render();}catch(err){db?.close();db=null;notice('BLOCKED: '+err.message,true);render();}})();
})();
