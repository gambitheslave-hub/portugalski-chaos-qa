/* PORTUGALSKI CHAOS 0.4: generic, pure mission engine. */
(function(root,factory){'use strict';const c=typeof module==='object'&&module.exports?require('./catalog.js'):root.ChaosCatalog04;const api=factory(c);if(typeof module==='object'&&module.exports)module.exports=api;root.ChaosEngine04=api;})(typeof globalThis!=='undefined'?globalThis:this,function(C){'use strict';
const VERSION='foundation-0.4.0',SCHEMA=5,DAY=86400000;
const canon=x=>{if(Array.isArray(x))return '['+x.map(canon).join(',')+']';if(x&&typeof x==='object')return '{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canon(x[k])).join(',')+'}';return JSON.stringify(x);};
const same=(a,b)=>canon(a)===canon(b),cpy=x=>JSON.parse(JSON.stringify(x));
function need(ok,where){if(!ok)throw Error('Dane lub stan nieprawidłowe: '+where);}
const obj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x),nat=x=>Number.isSafeInteger(x)&&x>=0;
const str=(x,max)=>typeof x==='string'&&x.length<=max;
const exact=(x,ks)=>{need(obj(x),'wymagany obiekt');need(same(Object.keys(x).sort(),ks.split(' ').filter(Boolean).sort()),'klucze '+ks);};
const norm=s=>String(s??'').normalize('NFC').trim().toLocaleLowerCase('pt-BR').replace(/[.!?]+$/,'').replace(/\s+/g,' ');
const tokens=s=>[...new Set(String(s).normalize('NFC').toLocaleLowerCase('pt-BR').match(/[\p{L}]+/gu)||[])];
function validateCatalog(){
 const allIds=new Set(),compIds=new Set();
 const ident=x=>typeof x==='string'&&/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(x)&&x.length<=120;
 const nonempty=(x,max)=>str(x,max)&&x.trim().length>0;
 const forms=x=>Array.isArray(x)&&x.length>0&&x.length<=10&&x.every(a=>nonempty(a,80)&&a===a.normalize('NFC'));
 need(C?.VERSION==='registry-0.4.0'&&Array.isArray(C.missions)&&C.missions.length>=2,'rejestr');
 for(const m of C.missions){
  exact(m,'id version chapter_id competency_id target_level mode_target title narrative_goal learning_goal source_ref rubric_version content_status prerequisite_ids lesson items open_prompt delayed leakage_policy');
  need(ident(m.id)&&!allIds.has(m.id),'identyfikator misji');allIds.add(m.id);
  need(ident(m.competency_id)&&!compIds.has(m.competency_id),'identyfikator kompetencji');compIds.add(m.competency_id);
  need(Number.isSafeInteger(m.version)&&m.version>=1&&m.version<=100000,'wersja misji');
  need(Number.isInteger(m.chapter_id)&&m.chapter_id>0&&m.chapter_id<=46,'rozdział');
  need(m.target_level==='A2+/B1-'&&m.mode_target==='P','poziom i tryb');
  need(nonempty(m.title,120)&&nonempty(m.narrative_goal,500)&&nonempty(m.learning_goal,500)&&nonempty(m.open_prompt,1000),'cele i polecenia');
  need(nonempty(m.source_ref,500)&&m.source_ref.trim().length>15&&ident(m.rubric_version),'pochodzenie i rubryka');
  need(m.content_status==='REVIEW_PENDING','status treści');
  need(Array.isArray(m.prerequisite_ids)&&m.prerequisite_ids.length<=200&&m.prerequisite_ids.every(ident),'wymagania wstępne');
  need(new Set(m.prerequisite_ids).size===m.prerequisite_ids.length&&!m.prerequisite_ids.includes(m.competency_id),'duplikat/cykl bezpośredni prerekwizytu');
  // Prerekwizyt może odwoływać się do szerszego katalogu kompetencji, bez grywalnej misji.
  need(Array.isArray(m.lesson)&&m.lesson.length>=2&&m.lesson.every(x=>nonempty(x,1000)),'lekcja');
  need(Array.isArray(m.items)&&m.items.length===4,'cztery zadania');
  for(const t of [...m.items,m.delayed]){
   exact(t,'id version kind scene prompt slots explanation evaluation');
   need(ident(t.id)&&!allIds.has(t.id),'unikalny id zadania');allIds.add(t.id);
   need(t.version===1&&nonempty(t.scene,200)&&nonempty(t.prompt,1200)&&nonempty(t.explanation,1200),'metadane zadania');
   need(['A','B','C_SCAFFOLDED','DELAYED_PROBE'].includes(t.kind),'typ zadania');
   need(['CLOSED_FORM','ASPECT_AND_FORM'].includes(t.evaluation),'typ oceny');
   need(Array.isArray(t.slots)&&t.slots.length>=1&&t.slots.length<=3,'luki');
   for(const slot of t.slots){
    exact(slot,t.evaluation==='ASPECT_AND_FORM'?'name answers why tense formsByTense':'name answers why');
    need(nonempty(slot.name,100)&&nonempty(slot.why,500)&&forms(slot.answers),'rubryka');
    if(t.evaluation==='ASPECT_AND_FORM'){
     need(['perfeito','imperfeito'].includes(slot.tense),'czas w rubryce');
     exact(slot.formsByTense,'perfeito imperfeito');
     need(forms(slot.formsByTense.perfeito)&&forms(slot.formsByTense.imperfeito),'odmiany w rubryce');
     need(slot.answers.every(a=>slot.formsByTense[slot.tense].some(b=>norm(a)===norm(b))),'klucz vs odmiana wybranego czasu');
    }
   }
  }
  need(m.delayed.kind==='DELAYED_PROBE','odroczenie');
  need(m.leakage_policy==='FORM_STRICT'||m.leakage_policy==='FUNCTION_WORD_CONTEXT','polityka wycieku');
 }
 return true;
}
validateCatalog();
const map=new Map(C.missions.map(m=>[m.id,m]));
const newRun=()=>({phase:'intro',index:0,sessionId:null,startedAt:null,completedAt:null,attempts:[],exposures:[],openText:null,draft:null,repair:false,helpReturn:null});
const fresh=()=>({schema:SCHEMA,version:VERSION,revision:0,lastClock:0,selected:null,runs:Object.fromEntries(C.missions.map(m=>[m.id,newRun()]))});
const current=(run,m)=>run.phase==='delayed'||run.phase==='delayed_feedback'||run.helpReturn==='delayed'?m.delayed:m.items[run.index];
function grade(t,forms,tenses=[]){need(Array.isArray(forms)&&forms.length===t.slots.length&&forms.every(x=>str(x,120)&&x.trim()),'odpowiedzi');need(Array.isArray(tenses)&&tenses.length===(t.evaluation==='ASPECT_AND_FORM'?t.slots.length:0),'liczba czasów');if(tenses.length)need(tenses.every(x=>['imperfeito','perfeito'].includes(x)),'wybór czasu');const f=forms.map(s=>s.trim());const aspect=tenses.length?t.slots.map((slot,i)=>slot.tense===tenses[i]):null;const morphology=tenses.length?t.slots.map((slot,i)=>slot.formsByTense[tenses[i]].some(x=>norm(x)===norm(f[i]))):null;const matched=aspect?aspect.every(Boolean)&&morphology.every(Boolean):t.slots.every((slot,i)=>slot.answers.some(x=>norm(x)===norm(f[i])));return {forms:f,tenses,aspect,morphology,matched};}
const feedbackWords=t=>[t.prompt,t.explanation,...t.slots.flatMap(s=>[...s.answers,s.why])].join(' ');
const exposureForms=(m,t,kind)=>tokens(kind==='rule'?m.lesson.join(' '):feedbackWords(t));
function evidence(run,t){const ex=run.exposures;return {priorRule:ex.some(x=>x.kind==='rule'),ruleForItem:ex.some(x=>x.kind==='rule'&&x.itemId===t.id),itemKey:ex.some(x=>x.kind==='key'&&x.itemId===t.id),answerFormsSeen:t.slots.map(slot=>ex.some(x=>x.forms.some(v=>slot.answers.some(a=>norm(a)===v)))),repair:run.repair,exposureCount:ex.length,lastExposureAt:ex.length?ex.at(-1).at:null};}
const evidenceText=e=>e.repair?'Próba naprawcza po kluczu':e.itemKey?'Po obejrzeniu klucza zadania':e.answerFormsSeen.some(Boolean)?'Po zobaczeniu form odpowiedzi':e.ruleForItem?'Po pomocy do zadania':e.priorRule?'Po lekcji':'Bez zarejestrowanej pomocy';
function validateRun(r,m,s){exact(r,'phase index sessionId startedAt completedAt attempts exposures openText draft repair helpReturn');need(['intro','lesson','question','feedback','open','complete','delayed','delayed_feedback'].includes(r.phase),'etap');need(Number.isInteger(r.index)&&r.index>=0&&r.index<4,'indeks');need(typeof r.repair==='boolean','korekta');need(r.helpReturn===null||['question','delayed'].includes(r.helpReturn),'powrót');need((r.phase==='lesson')===(r.helpReturn!==null),'pomoc a etap');if(r.phase==='intro'){need(same(r,newRun()),'wstępny stan misji');return;}
 need(nat(r.startedAt)&&r.startedAt<=s.lastClock&&str(r.sessionId,100)&&r.sessionId.length>0,'identyfikacja sesji');need(Array.isArray(r.exposures)&&r.exposures.length<=1000,'ekspozycje');let prev=0;for(let i=0;i<r.exposures.length;i++){const x=r.exposures[i];exact(x,'kind itemId at order forms');need(['rule','key'].includes(x.kind)&&nat(x.at)&&x.at>=prev&&x.at<=s.lastClock&&x.order===i+1,'ekspozycja');need(x.itemId===null||[...m.items,m.delayed].some(t=>t.id===x.itemId),'identyfikator ekspozycji');need(x.kind!=='key'||x.itemId!==null,'klucz bez id');need(Array.isArray(x.forms)&&x.forms.length<=250&&x.forms.every(w=>str(w,120)&&w===norm(w)&&tokens(w).length===1),'formy ekspozycji');prev=x.at;}
 need(Array.isArray(r.attempts)&&r.attempts.length<=100,'próby');let at=0;const ids=new Set();for(const a of r.attempts){exact(a,'id itemId itemVersion rubricVersion competencyId sessionId at forms tenses aspect morphology autoMatch evidence status');const t=[...m.items,m.delayed].find(t=>t.id===a.itemId);need(t&&/^AT-[1-9]\d*$/.test(a.id)&&!ids.has(a.id),'id próby');ids.add(a.id);need(a.itemVersion===t.version&&a.rubricVersion===m.rubric_version&&a.competencyId===m.competency_id&&a.sessionId===r.sessionId,'pochodzenie dowodu');need(nat(a.at)&&a.at>=at&&a.at<=s.lastClock,'czas próby');at=a.at;const g=grade(t,a.forms,a.tenses);need(same(a.forms,g.forms)&&same(a.aspect,g.aspect)&&same(a.morphology,g.morphology)&&a.autoMatch===g.matched,'ocena próby');need(a.status===(g.matched?'CLOSED_MATCH':'CLOSED_NO_MATCH'),'status próby');exact(a.evidence,'priorRule ruleForItem itemKey answerFormsSeen repair exposureCount lastExposureAt');need(Number.isInteger(a.evidence.exposureCount)&&a.evidence.exposureCount>=0&&a.evidence.exposureCount<=r.exposures.length,'liczba ekspozycji');const reconstruct=evidence({...r,repair:a.evidence.repair,exposures:r.exposures.slice(0,a.evidence.exposureCount)},t);need(same(reconstruct,a.evidence),'dowód a historia');need(!a.evidence.repair||a.evidence.itemKey,'korekta bez klucza');}
 const reached=['open','complete','delayed','delayed_feedback'].includes(r.phase)?4:r.index;for(let i=0;i<reached;i++)need(r.attempts.some(a=>a.itemId===m.items[i].id),'pominięte zadanie');need(r.attempts.every(a=>a.itemId===m.delayed.id?r.phase==='delayed_feedback':m.items.findIndex(x=>x.id===a.itemId)<=r.index),'zadanie z przyszłości');if(['feedback','delayed_feedback'].includes(r.phase))need(r.attempts.at(-1)?.itemId===current(r,m).id,'brak feedbacku');if(r.repair)need(['lesson','question','feedback'].includes(r.phase)&&r.attempts.some(a=>a.itemId===m.items[r.index].id&&!a.autoMatch),'bezpodstawna korekta');
 const complete=['complete','delayed','delayed_feedback'].includes(r.phase)||r.helpReturn==='delayed';if(complete){exact(r.openText,'text at status');need(str(r.openText.text,4000)&&((r.openText.status==='NOT_ATTEMPTED'&&r.openText.text==='')||(r.openText.status==='UNVERIFIED'&&r.openText.text.trim())),'tekst otwarty');need(nat(r.completedAt)&&r.completedAt===r.openText.at&&r.completedAt>=r.startedAt&&r.completedAt<=s.lastClock&&r.index===3,'koniec misji');}else need(r.openText===null&&r.completedAt===null,'nieoczekiwane zakończenie');
 if(r.draft!==null){exact(r.draft,'target values');const t=current(r,m),target=r.phase==='open'?'open':t.id;need(['lesson','open','question','delayed'].includes(r.phase)&&r.draft.target===target,'szkic a zadanie');const required=target==='open'?1:t.slots.length+(t.evaluation==='ASPECT_AND_FORM'?t.slots.length:0);need(Array.isArray(r.draft.values)&&r.draft.values.length===required&&r.draft.values.every(x=>str(x,target==='open'?4000:120)),'pola szkicu');}
}
function assertValid(s){exact(s,'schema version revision lastClock selected runs');need(s.schema===SCHEMA&&s.version===VERSION&&nat(s.lastClock)&&nat(s.revision)&&s.revision<=10000,'schemat');need(s.selected===null||map.has(s.selected),'wybrana misja');need(same(Object.keys(s.runs).sort(),[...map.keys()].sort()),'zbiór misji');for(const m of C.missions)validateRun(s.runs[m.id],m,s);return true;}
function due(run,now){return run.phase==='complete'&&nat(now)&&now>=run.completedAt&&now>=Math.max(run.completedAt,...run.exposures.map(e=>e.at))+DAY;}
function reduce(state,action,payload={},now){assertValid(state);need(obj(payload),'payload akcji');need(nat(now)&&now>=state.lastClock,'zegar');const s=cpy(state);let run=s.selected?s.runs[s.selected]:null,m=s.selected?map.get(s.selected):null;
 const expose=(kind,t)=>run.exposures.push({kind,itemId:t?.id??null,at:now,order:run.exposures.length+1,forms:exposureForms(m,t,kind)});
 if(action==='SELECT'){exact(payload,'missionId');need(map.has(payload.missionId),'misja');s.selected=payload.missionId;}
 else {need(!!run&&!!m,'wybierz misję');const t=current(run,m);
 switch(action){
 case 'START':exact(payload,'lesson');need(run.phase==='intro'&&typeof payload.lesson==='boolean','rozpoczęcie');run.phase='question';run.startedAt=now;run.sessionId='S04-'+m.id+'-'+now;if(payload.lesson){run.helpReturn='question';run.phase='lesson';expose('rule',null);}break;
 case 'DRAFT':exact(payload,'target values');need(['question','open','delayed'].includes(run.phase),'szkic a faza');run.draft=cpy(payload);break;
 case 'HELP':exact(payload,'');need(['question','delayed'].includes(run.phase),'pomoc');expose('rule',t);run.helpReturn=run.phase;run.phase='lesson';break;
 case 'BACK':exact(payload,'');need(run.phase==='lesson','powrót');run.phase=run.helpReturn;run.helpReturn=null;break;
 case 'ANSWER':{exact(payload,t.evaluation==='ASPECT_AND_FORM'?'forms tenses':'forms');need(['question','delayed'].includes(run.phase),'faza odpowiedzi');need(run.attempts.length<100,'limit prób');const g=grade(t,payload.forms,payload.tenses??[]);const ev=evidence(run,t);run.attempts.push({id:'AT-'+(s.revision+1),itemId:t.id,itemVersion:t.version,rubricVersion:m.rubric_version,competencyId:m.competency_id,sessionId:run.sessionId,at:now,forms:g.forms,tenses:g.tenses,aspect:g.aspect,morphology:g.morphology,autoMatch:g.matched,evidence:ev,status:g.matched?'CLOSED_MATCH':'CLOSED_NO_MATCH'});expose('key',t);run.phase=run.phase==='delayed'?'delayed_feedback':'feedback';run.draft=null;break;}
 case 'REPAIR':exact(payload,'');need(run.phase==='feedback'&&!run.attempts.at(-1)?.autoMatch,'korekta');run.phase='question';run.repair=true;run.draft=null;break;
 case 'NEXT':exact(payload,'');need(run.phase==='feedback','następne');run.repair=false;if(run.index===3)run.phase='open';else{run.index++;run.phase='question';}break;
 case 'SAVE_OPEN':exact(payload,'text');need(run.phase==='open'&&str(payload.text,4000)&&payload.text.trim(),'wypowiedź');run.openText={text:payload.text,at:now,status:'UNVERIFIED'};run.completedAt=now;run.phase='complete';run.draft=null;break;
 case 'SKIP_OPEN':exact(payload,'');need(run.phase==='open','pominięcie');run.openText={text:'',at:now,status:'NOT_ATTEMPTED'};run.completedAt=now;run.phase='complete';run.draft=null;break;
 case 'START_DELAYED':exact(payload,'');need(due(run,now),'próba odroczona');run.phase='delayed';break;
 default:throw Error('Nieznana akcja '+action);
 }}
 need(s.revision<10000,'limit dziennika');s.revision++;s.lastClock=now;assertValid(s);return {next:s,event:{id:s.revision,action,payload:cpy(payload),at:now}};
}
function validateBackup(b){exact(b,'kind version state events');need(b.kind==='CHAOS_04_BACKUP'&&b.version===SCHEMA&&Array.isArray(b.events)&&b.events.length<=10000,'kopia');let s=fresh();for(let i=0;i<b.events.length;i++){const e=b.events[i];exact(e,'id action payload at');need(e.id===i+1,'numer zdarzenia');const out=reduce(s,e.action,e.payload,e.at);need(same(out.event,e),'integralność zdarzenia');s=out.next;}assertValid(b.state);need(same(s,b.state),'stan a dziennik');return true;}
function contentAudit(){return C.missions.map(m=>{let prior=m.lesson.join(' ');const checks=[];for(const t of [...m.items,m.delayed]){const words=new Set(tokens(prior+' '+t.prompt));checks.push({itemId:t.id,rawFormOverlap:t.slots.map(x=>x.answers.some(a=>words.has(norm(a))))});prior+=' '+feedbackWords(t);}return {missionId:m.id,policy:m.leakage_policy,checks,scope:'Exact token overlap only; no semantic independence guaranteed'};});}
return Object.freeze({VERSION,SCHEMA,DAY,C,validateCatalog,fresh,assertValid,grade,norm,evidence,evidenceText,reduce,validateBackup,due,contentAudit,canon,mission:id=>map.get(id),current});
});
