/* PORTUGALSKI CHAOS 0.4: registry only; never touches legacy profiles. */
(function(root, factory){'use strict';const mod=factory();if(typeof module==='object'&&module.exports)module.exports=mod;root.ChaosCatalog04=mod;})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';
const missions=[
 {id:'SC04.STORM',version:1,chapter_id:4,competency_id:'PTBR.TENSE.PERF_IMPF.4_3',target_level:'A2+/B1-',mode_target:'P',title:'Burza nad São Capivara',narrative_goal:'Wyjaśnić organizatorom, co działo się podczas awarii',learning_goal:'Rozróżnić tło i zdarzenie w pretérito imperfeito/perfeito',source_ref:'PIERWSZA WERSJA KATALOGU KOMPETENCJI, rozdz. 4.3, s. 9',rubric_version:'SC04-R1',content_status:'REVIEW_PENDING',prerequisite_ids:['PTBR.TENSE.PRESENT.2','PTBR.TENSE.PERF.3'],lesson:[
 'Pretérito imperfeito opisuje między innymi dawny zwyczaj i trwające tło. Pretérito perfeito ujmuje zdarzenie jako zamknięte. To sposób opowiedzenia sytuacji, a nie mechaniczne słowo-klucz.',
 'Eu cozinhava quando o telefone tocou. — Gotowałem, gdy zadzwonił telefon.',
 'Preparar: ele preparava, nós preparávamos. Começar: eu comecei, ela começou. To przykłady, nie cała tabela.'
 ],
 items:[
  {id:'SC04.T01',version:1,kind:'A',scene:'Awaria oświetlenia',prompt:'Wczoraj prąd nagle zgasł: „Ontem, a energia ___ (acabar) de repente.”',slots:[{name:'Forma acabar',answers:['acabou'],why:'Zamknięte zdarzenie: acabou.'}],explanation:'Jednorazowe zakończone zdarzenie w perfeito.',evaluation:'CLOSED_FORM'},
  {id:'SC04.T02',version:1,kind:'A',scene:'Wspomnienie sąsiadki',prompt:'„Quando eu era criança, eu ___ (brincar) na rua todos os dias.”',slots:[{name:'Forma brincar',answers:['brincava'],why:'Zwyczaj z przeszłości: brincava.'}],explanation:'Dawny nawyk w imperfeito.',evaluation:'CLOSED_FORM'},
  {id:'SC04.T03',version:1,kind:'B',scene:'Biblioteka',prompt:'Opisz trwające tło: „A bibliotecária ___ (organizar) os livros quando ouviu um barulho.” Użyj imperfeito.',slots:[{name:'Forma organizar',answers:['organizava'],why:'Czynność trwająca w tle: organizava.'}],explanation:'Podany czas sprawia, że to ćwiczenie odmiany, nie samodzielny wybór aspektu.',evaluation:'CLOSED_FORM'},
  {id:'SC04.T04',version:1,kind:'C_SCAFFOLDED',scene:'Peron São Capivara',prompt:'Rozmawialiśmy przed zatrzymaniem pociągu i w chwili zatrzymania. Potem pasażerka weszła do wagonu. Dobierz czas i formę: „Quando o trem parou, nós ___ (conversar) na plataforma. Em seguida, uma passageira ___ (entrar) no vagão.”',slots:[{name:'Nós conversar',answers:['conversávamos'],tense:'imperfeito',formsByTense:{imperfeito:['conversávamos'],perfeito:['conversamos']},why:'Rozmowa była tłem: nós conversávamos.'},{name:'Ela entrar',answers:['entrou'],tense:'perfeito',formsByTense:{imperfeito:['entrava'],perfeito:['entrou']},why:'Zakończone wejście: entrou.'}],explanation:'Dobór aspektu i odmianę oceniamy osobno; nadal jest to zadanie kierowane.',evaluation:'ASPECT_AND_FORM'}
 ],
 open_prompt:'Napisz po portugalsku 2–3 zdania o tym, co trwało w tle i co się wydarzyło. Możesz pominąć bez kary.',
 delayed:{id:'SC04.D01',version:1,kind:'DELAYED_PROBE',scene:'Przystanek autobusowy',prompt:'„Ontem à noite, nós ___ (esperar) o ônibus quando a motorista ___ (chegar).”',slots:[{name:'Forma esperar',answers:['esperávamos'],why:'Tło: esperávamos.'},{name:'Forma chegar',answers:['chegou'],why:'Zdarzenie: chegou.'}],explanation:'Zadanie po czasie, w innym kontekście; zegar urządzenia nie potwierdza rzeczywistej retencji.',evaluation:'CLOSED_FORM'},
 leakage_policy:'FORM_STRICT'
 },
 {id:'SC04.FEIRA',version:1,chapter_id:15,competency_id:'PTBR.PREP.DE_PARA_POR.15',target_level:'A2+/B1-',mode_target:'P',title:'Targ i wiadomości',narrative_goal:'Przygotować drobne sprawunki i wiadomość dla znajomych',learning_goal:'Rozróżnić de w rządzie czasownika, para dla celu/odbiorcy i por dla powodu/środka',source_ref:'PIERWSZA WERSJA KATALOGU KOMPETENCJI, rozdz. 15.1–15.4 i 16, s. 19–22',rubric_version:'SC04-R1',content_status:'REVIEW_PENDING',prerequisite_ids:[],lesson:[
 'GOSTAR DE i PRECISAR DE to połączenia, których uczymy się razem z czasownikiem: Gosto de música; Preciso de ajuda.',
 'PARA zwykle oznacza cel, odbiorcę lub kierunek: Estudo para aprender; Comprei isso para você.',
 'POR oznacza między innymi powód, drogę, środek i cenę: Fiz isso por você; Enviei por e-mail.',
 'To różne relacje: „para você” może wskazywać odbiorcę, a „por você” — działanie z twojego powodu lub w twoim imieniu. Nie każda sytuacja daje jedną jedyną parafrazę.'
 ],
 items:[
  {id:'SC04.P01',version:1,kind:'A',scene:'Pomoc na targu',prompt:'Wpisz de / para / por zgodnie z wymaganiem czasownika: „Preciso ___ ajuda para encontrar a feira.”',slots:[{name:'Przyimek po precisar',answers:['de'],why:'Przez rząd: precisar de ajuda.'}],explanation:'Po precisar w tym znaczeniu występuje de.',evaluation:'CLOSED_FORM'},
  {id:'SC04.P02',version:1,kind:'A',scene:'Plan na wieczór',prompt:'Wpisz de / para / por: „Estudo português ___ trabalhar no Brasil.” Chodzi o cel nauki.',slots:[{name:'Przyimek oznaczający cel',answers:['para'],why:'Cel: estudar para trabalhar.'}],explanation:'Para oznacza tutaj zamiar/cel.',evaluation:'CLOSED_FORM'},
  {id:'SC04.P03',version:1,kind:'B',scene:'Wiadomość na telefonie',prompt:'Wpisz de / para / por: „Obrigado ___ esperar por mim.” Chodzi o powód podziękowania.',slots:[{name:'Przyimek po obrigado',answers:['por'],why:'Obrigado por + infinitivo: podziękowanie za działanie.'}],explanation:'To utrwalona i bardzo przydatna konstrukcja.',evaluation:'CLOSED_FORM'},
  {id:'SC04.P04',version:1,kind:'C_SCAFFOLDED',scene:'Listy dla mieszkańców',prompt:'Uzupełnij dwie luki wyłącznie de / para / por, według podanej intencji: „Preciso ___ informações. Depois vou imprimir os avisos ___ os moradores.” Druga luka oznacza odbiorców.',slots:[{name:'Przyimek po precisar',answers:['de'],why:'Precisar de informações.'},{name:'Przyimek odbiorcy',answers:['para'],why:'Avisos para os moradores = informacje przeznaczone dla mieszkańców.'}],explanation:'Dwie różne funkcje w tym samym działaniu; możliwe parafrazy poza zestawem trzech przyimków nie są tutaj oceniane.',evaluation:'CLOSED_FORM'}
 ],
 open_prompt:'Napisz krótką wiadomość w PT-BR: czego potrzebujesz i dla kogo coś przygotowujesz. Możesz pominąć.',
 delayed:{id:'SC04.PD01',version:1,kind:'DELAYED_PROBE',scene:'Korespondencja organizatorów',prompt:'Wpisz de / para / por: „Enviei o convite ___ e-mail; reservei os ingressos ___ meus colegas.” Druga luka dotyczy odbiorców.',slots:[{name:'Środek wysyłki',answers:['por'],why:'Por e-mail opisuje środek wysłania.'},{name:'Odbiorcy biletów',answers:['para'],why:'Para os meus colegas oznacza przeznaczenie dla nich.'}],explanation:'Nowy kontekst po odroczeniu. Wynik jednej próby nie wystarcza do diagnozy kompetencji.',evaluation:'CLOSED_FORM'},
 leakage_policy:'FUNCTION_WORD_CONTEXT'
 }
];
return Object.freeze({VERSION:'registry-0.4.0',missions});
});
