# Kontrakty FUNDAMENTU 0.4 i następna bramka

## Architektura

`Catalog` to wyłączne źródło opisów nowych zadań. `Engine` jest reduktorem: (poprawny stan, akcja, payload, monotoniczny znacznik czasu) → (nowy stan, nowe zdarzenie), bez I/O. `Storage` trzyma `kv/state` i `events` w jednej transakcji IndexedDB readwrite; stan widoczny w UI aktualizuje się po `tx.oncomplete`. `UI` nie wyznacza samo poprawności. `build.py` łączy cztery skrypty w jeden HTML bez zasobów sieciowych.

## Niepodważalne reguły

- Nie otwieraj `portugalski_chaos_r1_isolated` (R12), ani DB 0.3/0.3.1. Żadnych ukrytych migracji; import 0.4 wyłącznie do pustej bazy i po replay całego dziennika.
- Każdy nowy `item.id`, `competency_id`, `rubric_version` i metadane źródła muszą pozostać niezmienne po publikacji; zmiana klucza językowego oznacza nowy `item.version` i plan kompatybilności.
- Poprawna odpowiedź w zadaniu z kluczem = `CLOSED_MATCH`, NIE `MASTERED`. Tekst użytkownika: `UNVERIFIED`; pominięcie: `NOT_ATTEMPTED`; nie naliczać go do wyników językowych.
- Dowód przechowuje ekspozycję na ogólną regułę, podpowiedź zadaniową, poznany klucz i naprawę. Kontrola pokrycia dokładnych form jest konserwatywna, NIE dowodzi samodzielności czy transferu semantycznego.
- Trening daje wybór lekcji przed pierwszym testem. Żadnych streaków, audio, losowych nagród, kar za pauzę, sztucznego czasu sesji lub fikcyjnej neurobiologicznej punktacji.
- Baza prototypu może zostać niedostępna przy innym origin/URI pliku; wykonuj eksport i zachowaj stary plik w jego pierwotnym położeniu.

## Akceptacja kolejnego etapu

P0: prawdziwy Chrome Android (w tym docelowe `content://`): uruchomienie/odczyt, zapis, restart, konflikt dwóch kart, abort, quota, awaria przed/po commicie, szkice, eksport i import na PUSTEJ bazie. Każdy test osobno PASS/FAIL/BLOCKED. Zweryfikować origin, nazwy DB i brak otwarcia R12.

P1: niezależny audyt językowy nowych zadań w SC04.FEIRA; obejmuje nienaturalność, dopuszczalne alternatywy, pułapki `de/para/por`, stopień naprowadzania i jakość wariantu odroczonego.

P1: niezależny test semantycznego transferu i retencji z innymi wariantami, po czasie i bez gotowej podpowiedzi, z wyraźną niepewnością diagnozy.

P2: dopiero potem refaktoryzacja rozszerzalności harmonogramu, kilka sesji na tę samą kompetencję, skalowanie banku i połączenie z fabułą/mapą A4 przez jawne kontrakty. Nie mieszać historycznych baz ani dawnych wyników.
