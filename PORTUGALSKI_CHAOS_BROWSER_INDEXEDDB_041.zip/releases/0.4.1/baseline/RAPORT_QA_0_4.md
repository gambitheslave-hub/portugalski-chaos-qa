# PORTUGALSKI CHAOS — raport odbiorowy eksperymentalnego fundamentu 0.4

Data: 18.10.2026. Zakres: odrębna gałąź 0.4, a NIE produkcyjna gra R12 ani certyfikacja A4.

## Wynik

**Wydanie rozwojowe gotowe do inspekcji i dalszych testów, ale NIE do integracji z R12.** Obejmuje dwie misje w jednym pliku HTML i jednym silniku; odrębną nazwę IndexedDB: `portugalski_chaos_foundation_v0_4_ODDZIELNA`. Rejestr i historia nie są migrowane z 0.3/0.3.1/R12.

| Kontrola | Status | Dowód / ograniczenie |
|---|---|---|
| Zgodność wygenerowanego HTML ze źródłami, brak zewnętrznych zależności | **PASS** | `logs/BUILD_VERIFY_FINAL.log`, `tests/check_build.py` |
| Testy silnika/kontraktów | **PASS 21/21** | `logs/ENGINE_FINAL_RECHECK.log`, rzeczywisty Node test runner |
| Deterministyczne modelowanie dwóch misji, 60 sesji | **PASS** | `logs/STRESS_FINAL_RECHECK.log`: 2145 przejść stanu, 657 prób, 60 zweryfikowanych kopii i 60 celowo uszkodzonych odrzuconych; to NIE IndexedDB |
| Scenariusze Chromium DOM z adapterem pamięciowym | **PASS w podanym zakresie** | `logs/DOM_FINAL_RECHECK.log`: nawigacja, korekty, szkice, przełączanie misji, uruchomienie eksportu, 4 szerokości; to NIE natywny zapis |
| Uruchomienie natywnego offline HTML przez `file://` | **BLOCKED** | `logs/NATIVE_BROWSER_PROBE_RECHECK.log`: ERR_BLOCKED_BY_ADMINISTRATOR |
| Natywne otwarcie IndexedDB w tej przeglądarce | **BLOCKED** | W badanym kontekście o origin `null` dostęp do IDB jest zabroniony; brak testu rzeczywistego commit/abort/reopen |
| Testy Android Chrome / `content://` | **NOT RUN** | Brak dostępnej certyfikacji na fizycznym urządzeniu |
| Retencja rzeczywista po 24h, transfer z użytkownikiem | **NOT RUN** | Wyłącznie logika harmonogramu i zadania, bez danych empirycznych |
| Niezależny audyt językowy treści 0.4 | **NOT RUN** | Nowa misja przyimkowa ma `REVIEW_PENDING`; nie uznawać za zweryfikowany bank |
| R12 — regresja Node | **PASS 49/49** | `logs/R12_NODE_REGRESSION.log`; wykonane osobno, bez zmiany źródeł R12 |
| R12 — walidator treści | **PASS** | `logs/R12_VERIFY.log`: 1436 rekordów, zachowane ID/odpowiedzi |

## Zmiana względem gałęzi 0.3.1

1. Jeden rejestr dwóch kompetencji/ścieżek — SC04.STORM (perfeito/imperfeito) i SC04.FEIRA (de/para/por).
2. Wspólny czysty silnik, wersjonowanie kompetencji, pozycji i rubryk; automatyczne sprawdzanie unikalności identyfikatorów i poprawności metadanych.
3. Każda ścieżka otrzymuje cztery zadania, lekcję, jawne wyjaśnienie wyniku, własną wypowiedź UNVERIFIED lub NOT_ATTEMPTED, jeden odroczony wariant po minimum 24 godzinach według czasu urządzenia.
4. Oddzielenie zgodności z kluczem od jakości dowodu (ekspozycja na regułę/rozwiązanie, próba naprawcza) oraz oddzielenie wyboru aspektu od morfologii tam, gdzie rubryka tego wymaga.
5. Jeden chronologiczny dziennik działań, odtwarzalne kopie, blokowanie importu do niepustej bazy, próba ochrony zapisów przez commit-before-advance i kontrolę rewizji (CAS). **To jest implementacja i weryfikacja modelowa, a nie potwierdzona niezawodność natywnego IDB.**

## Historia niepowodzeń i retestów

- Pierwszy przebieg 21 testów nowego silnika wykazał FAIL spowodowany utrzymywaniem identyfikatorów rejestru między wywołaniami walidacji; poprawiono lokalny zbiór identyfikatorów; pierwotny log zachowany (`logs/ENGINE_FIRST.log`), retest PASS (`logs/ENGINE_RETEST.log`).
- Pierwsze próby Chromium DOM i poprawek widoku zachowane (`logs/DOM_FIRST.log`, `logs/DOM_RETEST.log`, `logs/DOM_WIDTH_FIRST.log`), obecny wynik w `logs/DOM_FINAL_RECHECK.log`.
- Wszelkie wyniki dotyczą osobnych przebiegów; nie sumować ich jako jednej certyfikacji produktu.

## Ryzyka i bramki odbiorowe

- **P0: natywne IndexedDB:** przed jakąkolwiek integracją z R12 wykonać realne testy offline `file://`/`content://` na urządzeniu użytkownika, odczyt po restarcie, utratę zasilania/wyjście w trakcie commitu, transakcję odrzuconą, konflikty dwóch kart, eksport i import do pustej bazy i odmowę importu do niepustej. Zachować logi/artefakty.
- **P0: historia:** dane R12 oraz 0.3.1 pozostają nietknięte; starych prób NIE przeliczać nowymi rubrykami. Przed ewentualną migracją niezbędny backup i plan rollback.
- **P1: treść PT-BR:** druga misja i nowe objaśnienia wymagają niezależnego audytu nauczycielskiego. Zamknięte przyimki nie oznaczają zweryfikowanego transferu komunikacyjnego.
- **P1: nauka:** jedna poprawna próba po upływie 24h to obserwacja; brak podstaw do ogłaszania opanowania A2+/B1–. Ograniczenia i podpowiedzi powinny być jawne.
- **P1: ochrona szkiców:** 350 ms debounce i wymuszenie przed zmianą ekranu redukują ryzyko, ale ostatnie znaki przy nagłym zamknięciu mogą nie zostać zapisane. Część prób w browser DOM korzystała z pamięciowego adaptera.
- **P2: skala:** obecna gałąź jest fundamentem wielomisyjnym, nie implementacją wszystkich 46 rozdziałów i bogatej przygody A4.

## Decyzja

Wolno kontynuować niezależny development 0.4 i przygotowywać kolejne moduły wraz z ich audytem. **Nie wolno oznaczyć 0.4 jako produkcyjnego następcy R12 ani jako Browser E2E PASS.**
