from pathlib import Path
import hashlib, re,subprocess
r=Path(__file__).parents[1]
p=r/'URUCHOM_PORTUGALSKI_CHAOS_FUNDAMENT_0_4_OFFLINE.html'
before=p.read_bytes()
subprocess.run(['python3','build.py'],cwd=r,check=True,capture_output=True,text=True)
after=p.read_bytes()
assert before==after, 'build not deterministic'
html=after.decode()
assert '<script src=' not in html and '<link rel="stylesheet"' not in html
assert 'https://' not in html and 'http://' not in html
assert not re.search(r'<(?:audio|video|iframe)\b',html,re.I)
assert 'portugalski_chaos_r1_isolated' not in html
assert 'portugalski_chaos_foundation_v0_4_ODDZIELNA' in html
assert 'SC04.FEIRA' in html and 'SC04.STORM' in html
print('PASS static build: exact reproducibility; one offline HTML; no external URL, audio, iframe, or R12 DB reference; sha256='+hashlib.sha256(after).hexdigest())
