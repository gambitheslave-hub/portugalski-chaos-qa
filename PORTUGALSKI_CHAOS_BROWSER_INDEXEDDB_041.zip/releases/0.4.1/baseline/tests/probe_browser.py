from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 try:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=browser.new_page()
  page.set_content('<!doctype html><html><body><h1 id="hello">TEST</h1><script>document.body.dataset.scriptRun="yes";</script></body></html>')
  print('CHROMIUM_DOM',page.locator('#hello').inner_text(),page.locator('body').get_attribute('data-script-run'))
  print('IDB_AVAILABLE',page.evaluate('typeof indexedDB'))
  browser.close()
 except Exception as e:print('BLOCKED',type(e).__name__,str(e)[:1200])
