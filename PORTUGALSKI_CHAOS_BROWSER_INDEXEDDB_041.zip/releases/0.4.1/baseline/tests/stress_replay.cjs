'use strict';
const E=require('../src/engine.js');
let seed=20261018;function rnd(){seed=(Math.imul(1664525,seed)+1013904223)>>>0;return seed/4294967296;}
let total=0,attempts=0;
for(let run=0;run<60;run++){
 let st=E.fresh(),events=[],t=1000000+run*100000000;
 function act(a,p={}){const out=E.reduce(st,a,p,++t);st=out.next;events.push(out.event);total++;}
 for(const m of E.C.missions){
  act('SELECT',{missionId:m.id});const lesson=rnd()<.5;act('START',{lesson});if(lesson)act('BACK');
  for(const item of m.items){
   if(rnd()<.35){act('DRAFT',{target:item.id,values:[...item.slots.map(x=>x.answers[0].slice(0,1)),...(item.evaluation==='ASPECT_AND_FORM'?item.slots.map(_x=>''):[])]});}
   if(rnd()<.2){act('HELP');act('BACK');}
   if(rnd()<.27){act('ANSWER',{forms:item.slots.map(()=>'nada'),...(item.evaluation==='ASPECT_AND_FORM'?{tenses:item.slots.map(()=> 'perfeito')}: {})});attempts++;if(rnd()<.5)act('REPAIR');}
   const phase=st.runs[m.id].phase;
   if(phase==='question'){
    act('ANSWER',{forms:item.slots.map(x=>x.answers[0]),...(item.evaluation==='ASPECT_AND_FORM'?{tenses:item.slots.map(x=>x.tense)}:{})});attempts++;
   }
   act('NEXT');
  }
  if(rnd()<.6)act('SKIP_OPEN');else act('SAVE_OPEN',{text:'Escrevi meu texto, sem avaliação automática.'});
  const r=st.runs[m.id];t=Math.max(t,...r.exposures.map(e=>e.at),r.completedAt)+E.DAY;
  act('START_DELAYED');
  act('ANSWER',{forms:m.delayed.slots.map(s=>s.answers[0])});attempts++;
 }
 const b={kind:'CHAOS_04_BACKUP',version:E.SCHEMA,state:st,events};E.validateBackup(b);
 if(events.length){const bad=structuredClone(b);bad.events[0].payload.missionId='UNKNOWN';let caught=false;try{E.validateBackup(bad);}catch(_e){caught=true;}if(!caught)throw Error('tamper accepted');}
}
console.log('PASS deterministic replay stress: 60 dual-mission sessions; '+total+' state transitions; '+attempts+' attempts; 60 intact backups; 60 tampered backups rejected; seed 20261018');
