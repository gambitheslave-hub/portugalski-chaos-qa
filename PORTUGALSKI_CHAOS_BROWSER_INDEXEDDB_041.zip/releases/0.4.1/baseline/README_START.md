# PORTUGALSKI CHAOS — FUNDAMENT WIELOMISYJNY 0.4

**Stan:** eksperymentalny fragment odbudowy. **Bieżąca gra:** nadal R12 z pierwotnego pakietu przekazania. 0.4 NIE jest R13, R14 ani zamiennikiem R12. Data wykonania: 18.10.2026.

## Jak uruchomić

Otwórz **URUCHOM_PORTUGALSKI_CHAOS_FUNDAMENT_0_4_OFFLINE.html** w przeglądarce. Nie trzeba internetu, instalatora, serwera, audio ani innych plików. Dane 0.4 są w nowej, niezależnej bazie `portugalski_chaos_foundation_v0_4_ODDZIELNA`. Jeśli środowisko blokuje IndexedDB (np. specyficzne `file://` lub `content://`), program wyświetla BLOCKED i nie udaje, że zapis działa.

**UWAGA:** Nie usuwaj danych przeglądarki ani dotychczasowych plików R12/0.3/0.3.1. Przeniesienie lokalnego HTML lub zmiana URI może zmienić origin i dostępność istniejących baz. Eksport pobiera pełną zatwierdzoną historię 0.4; użytkownik powinien sprawdzić pobrany plik. Import przyjmowany jest WYŁĄCZNIE w pustej bazie 0.4, po odtworzeniu dziennika i kontroli stanu. Nie ma scalania ani migracji starych profili.

## Co nowego w porównaniu z 0.3.1

- **Jeden rejestr dwóch kompetencji i dwóch misji**, z których każdą można osobno wybrać i wznowić; to jeden HTML i jeden generyczny silnik, nie dwa skopiowane programy.
- `SC04.STORM` (rozdz. 4.3): pretérito perfeito i imperfeito — rozbudowa pionowej misji 0.3.1 w nowym rejestrze, w nowej przestrzeni identyfikatorów. `SC04.FEIRA` (rozdz. 15.1–15.4 i 16): de / para / por w sytuacjach komunikacyjnych.
- Każda ścieżka ma: wybór lekcji/przypomnienia, regułę, 4 zadania treningowe, kryteria informacji zwrotnej, pomijany lub zapisany jako UNVERIFIED tekst otwarty, oraz osobny wariant po minimum 24 h według zegara urządzenia.
- Rejestr określa trwałe `competency_id`, `chapter_id`, `item.id`, `version`, `rubric_version`, `source_ref`, priorytet treści, cel narracyjny i edukacyjny. Walidator odrzuca duplikaty ID, wadliwe metadane, uszkodzone zapisy i niezgodność dziennika.
- Historia zapisuje próby, oryginalne błędy, naprawy, wybór czasu i morfologię w MS04, ekspozycje na lekcję/klucz i oznaczenie `NOT_ATTEMPTED` vs `UNVERIFIED`.
- Szkice przechodzą przez wspólną kolejkę zapisu z potwierdzeniem transakcji; automatyczne zatwierdzanie po 350 ms bezczynności i wymuszenie przed pomocą/przejściem. Ostatnie znaki przed fizyczną awarią nie są gwarantowane.
- Zero audio, sieci, presji codziennych logowań, automatycznego uznania kompetencji lub deklaracji osiągniętego poziomu CEFR.

## Limity dydaktyczne

Druga misja to **nowa zawartość projektowa — REVIEW_PENDING**, wymagająca niezależnej recenzji PT-BR. Uzupełnianie przyimków z zamkniętej listy sprawdza rozróżnienia w kontrolowanym kontekście, nie dowodzi naturalnej swobodnej produkcji. Ponieważ `de`, `para`, `por` występują z konieczności w lekcji, audyt nie może automatycznie uznać ich powtórzenia za „przeciek” lub jego brak. Polityka `FUNCTION_WORD_CONTEXT` wymaga oceny kontekstu, nadal NOT RUN przez człowieka.

Jedna próba odroczona po upływie minimum 24 godzin z lokalnego zegara to **obserwacja, a nie wiarygodnie zmierzona retencja ani certyfikat kompetencji**. Nie wykonano jeszcze prawdziwego badania z uczniem.

## Struktura

- `src/catalog.js` — pojedynczy rejestr wersjonowanych kompetencji i zadań.
- `src/engine.js` — czysty reducer, walidacja, grading, replay, kontrola ekspozycji.
- `src/storage.js` — odizolowana IndexedDB, CAS, atomowa historia i import/eksport.
- `src/ui.js` — polski interfejs, dwie ścieżki, szkice, pomoce i obsługa awarii.
- `src/template.html` + `build.py` — deterministyczny pojedynczy HTML.
- `tests/` — Node, deterministyczny stress i test Chromium DOM z symulowanym magazynem; osobny negatywny test natywnej przeglądarki.
- `logs/` i `RAPORT_QA_0_4.md` — wyniki rzeczywiste, FAIL/RETEST/BLOCKED/NOT RUN.
- `history/` — niezmienione referencyjne artefakty 0.3.1; żadna konwersja ich historii nie jest wykonywana.

## Development

```
python3 build.py
node --test tests/engine.test.cjs
node tests/stress_replay.cjs
python3 tests/dom_smoke.py
python3 tests/native_browser_probe.py
```

Nie licz testów Node, statycznych i scenariuszy Chromium z adapterem pamięciowym jako certyfikacji prawdziwego IndexedDB, R12 ani Androida. R12 nie został zmieniony.
