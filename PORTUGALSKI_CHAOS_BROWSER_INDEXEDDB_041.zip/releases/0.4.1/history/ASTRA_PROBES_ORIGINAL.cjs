'use strict';
const a=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const base=path.join(__dirname,'PORTUGALSKI_CHAOS_FUNDAMENT_0_4');
const E=require(base+'/src/engine.js');
const result=[];
const s=E.fresh();s.revision=-1;a.equal(E.assertValid(s),true);
const next=E.reduce(s,'SELECT',{missionId:E.C.missions[0].id},1);a.equal(next.event.id,0);
result.push({id:'A04-01',finding:'Negative revision accepted and emits event id 0',revision:s.revision,eventId:next.event.id});
const C=require(base+'/src/catalog.js');
const saved={version:C.missions[0].version,competency_id:C.missions[0].competency_id,target_level:C.missions[0].target_level,prerequisite_ids:C.missions[0].prerequisite_ids};
Object.assign(C.missions[0],{version:-7,competency_id:'',target_level:123,prerequisite_ids:[null]});a.equal(E.validateCatalog(),true);
result.push({id:'A04-02',finding:'Invalid catalog metadata accepted',mutations:{version:-7,competency_id:'',target_level:123,prerequisite_ids:[null]}});Object.assign(C.missions[0],saved);
// Full reachable state at journal limit, not a fabricated revision.
let limit=E.fresh(),events=[];let t=0;function act(action,payload){const c=E.reduce(limit,action,payload,++t);limit=c.next;events.push(c.event)}
act('SELECT',{missionId:'SC04.STORM'});act('START',{lesson:false});while(limit.revision<10000)act('SELECT',{missionId:'SC04.STORM'});
a.equal(E.validateBackup({kind:'CHAOS_04_BACKUP',version:5,state:limit,events}),true);
const scripts=[...fs.readFileSync(base+'/URUCHOM_PORTUGALSKI_CHAOS_FUNDAMENT_0_4_OFFLINE.html','utf8').matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const tick=async()=>{for(let i=0;i<12;i++)await new Promise(r=>setImmediate(r));};
async function boot(initial,failCommit=false){
 class N{constructor(tag){this.tag=tag;this.children=[];this.dataset={};this.textContent='';this.value='';this.disabled=false;}append(...n){this.children.push(...n)}replaceChildren(...n){this.children=n}remove(){}click(){this.onclick?.()}}
 const body=new N('body'),toolbar=new N('div');body.append(toolbar);
 for(const id of ['content','status','save-state','progress','missions','pause','export','refresh','import']){const n=new N(['missions','pause','export','refresh'].includes(id)?'button':id==='import'?'input':'div');n.id=id;if(id==='import')n.type='file';body.append(n);}
 const all=()=>{const list=[];function rec(n){list.push(n);n.children.forEach(rec)}rec(body);return list};
 const doc={body,createElement:t=>new N(t),getElementById:id=>all().find(n=>n.id===id),querySelector:()=>toolbar,querySelectorAll:q=>all().filter(n=>q.startsWith('textarea')?n.tag==='textarea'||n.tag==='input'&&n.type!=='file':n.tag==='button'||n.tag==='select'||n.tag==='input'&&n.type==='file')};
 let backupCalls=0,downloads=0,state=structuredClone(initial);
 const S={open:async()=>({close(){}}),read:async()=>structuredClone(state),commit:async(_db,rev,next)=>{if(failCommit)throw Error('INJECTED_CONFLICT');state=next},backup:async()=>{backupCalls++;return {state}},restore:async()=>{}};
 const ctx={document:doc,Date,console,setTimeout,clearTimeout,Blob,URL:{createObjectURL:()=>{downloads++;return 'blob:mock'},revokeObjectURL(){}},addEventListener(){},confirm:()=>true};vm.createContext(ctx);vm.runInContext(scripts[0],ctx);vm.runInContext(scripts[1],ctx);ctx.ChaosStorage04=S;vm.runInContext(scripts[3],ctx);await tick();return {get:id=>doc.getElementById(id),state:()=>state,stats:()=>({backupCalls,downloads}),async click(id){a.equal(doc.getElementById(id).disabled,false);await doc.getElementById(id).onclick();await tick();},type(id,text){const n=doc.getElementById(id);n.value=text;n.oninput();}};
}
(async()=>{
 const p=await boot(limit);p.type('field-0','UNSAVED_AT_LIMIT');await p.click('pause');
 a.equal(p.state().runs['SC04.STORM'].draft,null);a.ok(p.get('resume'));a.equal(p.get('save-state').textContent,'Wszystkie zlecone zmiany zatwierdzone.');
 await p.click('resume');a.equal(p.get('field-0').value,'UNSAVED_AT_LIMIT');
 await p.click('refresh');a.equal(p.get('field-0').value,'');
 result.push({id:'A04-03',finding:'At reachable 10000 event limit, rejected draft allows pause; claims all changes confirmed; refresh discards draft without failed-state confirmation',nativeIDB:false});
 let st=E.reduce(E.fresh(),'SELECT',{missionId:'SC04.STORM'},1).next;st=E.reduce(st,'START',{lesson:false},2).next;
 const f=await boot(st,true);f.type('field-0','draft');await f.click('pause');a.match(f.get('status').textContent,/INJECTED_CONFLICT/);a.equal(f.get('export').disabled,false);await f.click('export');a.deepEqual(f.stats(),{backupCalls:0,downloads:0});
 result.push({id:'A04-04',finding:'Export enabled after failed commit, but handler returns silently; backup never called',nativeIDB:false,stats:f.stats()});
 console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
