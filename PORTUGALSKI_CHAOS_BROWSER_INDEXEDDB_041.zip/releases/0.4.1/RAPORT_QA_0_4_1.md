# PORTUGALSKI CHAOS 0.4.1 — raport wydania po niezależnym audycie

**Data:** 18.10.2026  
**Zakres:** punktowa naprawa A04-01, A04-02, A04-03, A04-04, bez nowych treści lub migracji.  
**Bazowy plik 0.4 SHA-256:** `5a4487d6f5209f7dbc89a92951dcb139c07fa4b9df4ac532a8ffd7d1c0a6cc7e`  
**Nowy HTML 0.4.1 SHA-256:** `98033fbebc8c5fefafdaa2d8e07e41faee25d5fc9681a132077b6417a9f75b87`

## 1. Reprodukcja przed naprawą

Na oryginalnym 0.4 uruchomiono `node probes.cjs` z audytu Astry: **4/4 problemy odtworzone**. Wynik historyczny znajduje się w `logs/ASTRA_ORIGINAL_PROBES_BEFORE.log` i `logs/HISTORICAL_REPRO_AFTER_PATH_ADJUST.log`. Nie są to PASS funkcjonalności produktu; są dowodem występowania usterek w oryginalnym wydaniu.

## 2. Zmiany

| ID | Wprowadzone zabezpieczenie | Dowód regresji |
|---|---|---|
| A04-03 P1 | Odrzucony `DRAFT` w reduktorze traktowany jako błąd zapisu. UI zachowuje szkic w pamięci, ustawia dirty/fatal flag, nie pozwala na potwierdzoną pauzę i nie deklaruje sukcesu. Wczytanie ostatniego zatwierdzonego stanu wymaga osobnego pobrania szkicu i potwierdzenia użytkownika. | `hardening.test.cjs`: testy 9, 11, 12 |
| A04-04 P1 | Eksport nie wykonuje już milczącego `return` po nieudanej transakcji. Wywołuje backup ostatniej zatwierdzonej historii, a komunikat odróżnia tę kopię od bieżącego szkicu. | test 10, test pobierania szkicu 12 |
| A04-01 P2 | `assertValid()` wymaga rewizji bez znaku minus; reduktor odrzuca niepoprawny stan przed akcją. 0 pozostaje poprawne, 10000 pozostaje czytalne, zapis 10001 jest odrzucany. | test 1 |
| A04-02 P2 | `validateCatalog()` sprawdza ID, wersję, cel i poziom, obowiązkowe teksty, pochodzenie, prerekwizyty, pola zadań i zgodność `answers` z odmianą czasu. Zewnętrzne kompetencje jako prerekwizyty są dozwolone. | testy 2–8 |

**Dodatkowo:** błędna odpowiedź na zadanie nie ustawia blokady fatalnej transmisji; aplikacja podaje komunikat o odrzuceniu takiego polecenia, bez fałszywego „wszystkie zapisane” (test 13). Test 14 potwierdza niezmienność katalogu, storage i wersji danych.

## 3. Wyniki faktycznie wykonane

| Kontrola | Status | Log |
|---|---|---|
| Baseline Astry — reprodukcje w 0.4 | **4/4 REPRODUCED** | `logs/HISTORICAL_REPRO_AFTER_PATH_ADJUST.log` |
| Oryginalne testy Node engine | **21/21 PASS** | `logs/ENGINE_21_FINAL.log` |
| Nowe testy hardening Node / mock DOM | **14/14 PASS** | `logs/HARDENING_14_FINAL.log` |
| Deterministyczne przejścia stanu i backup replay | **PASS** — 60 sesji / 2145 transitions / 657 attempts / 60 backup PASS / 60 uszkodzonych odrzuconych | `logs/STRESS_FINAL.log` |
| Deterministyczna przebudowa HTML, offline statyczny | **PASS** | `logs/BUILD_REPRODUCIBLE.log` |
| Składnia modułów Node | **PASS** | `logs/SYNTAX.log` |
| Chromium DOM, pamięciowy storage adapter | **9 kontroli PASS**, nie IndexedDB | `logs/DOM_MEMORY_ADAPTER_FINAL.log` |
| `file://` w rzeczywistym Chromium | **BLOCKED** — `ERR_BLOCKED_BY_ADMINISTRATOR` | `logs/NATIVE_BROWSER_PROBE.log` |
| IndexedDB w osadzonym HTML `origin=null` | **BLOCKED** — API denied | `logs/NATIVE_BROWSER_PROBE.log` |
| Native IndexedDB commit/abort, reload, dwa taby, quota | **NOT RUN** | brak uruchamialnego uprawnionego origin |
| Android Chrome i `content://` | **NOT RUN** | brak fizycznego testu |
| R12 regresja w tym sprincie | **NOT RUN** (nienaruszone, brak kodu R12 w zestawie źródłowym tego audytu) | tylko zachowane historyczne dowody 0.4 |
| Dydaktyka/PT-BR, retencja użytkownika po 24h | **NOT RUN** | wymaga danych z nauki / niezależnej oceny |

Nie sumować suite'ów Node, stress i Chromium w jedną metrykę. Testy mock DOM odpalają kod UI z wynikowego HTML, ale nie wykonują prawdziwych transakcji IDB.

## 4. Zgodność i historia

- `baseline/` i `history/` zawierają zamrożone źródła i audyt Astry; R12 oraz starsze 0.3/0.3.1 nie były modyfikowane.
- Bez zmian: `src/catalog.js`, `src/storage.js`, nazwa IndexedDB, schemat 5, `version=foundation-0.4.0`, format kopii `CHAOS_04_BACKUP`, klucze ocen w `attempts`.
- Zmieniono: silnik `validateCatalog()` i `assertValid()`, UI obsługę niepowodzeń i komunikaty, drobny tekst etykiety wydania. Nie migrowano istniejących danych.
- Poprawka jest kompatybilna na poziomie **modelu i źródeł** z zapisami osiągalnymi w 0.4; zgodności prawdziwych origin/storage nie potwierdzono testem native E2E.

## 5. Ryzyka nadal otwarte

1. Wydajność pełnego replay dziennika, limity quota i stany błędów transakcji IDB w prawdziwym Android Chrome nie są sprawdzone.
2. Przeglądarka nie daje gwarancji, że pobieranie zostało skutecznie zapisane na dysku — UI wyraźnie prosi o sprawdzenie pliku.
3. W pamięci RAM może zniknąć ostatnia niezapisana zmiana przy brutalnym zamknięciu procesu. To nie jest rozwiązane przez komunikaty i eksport szkicu.
4. Adaptacyjna retencja / transfer oraz niezależny audyt całego banku językowego nadal nie są ukończone.

**Rekomendowany kolejny krok:** niezależna recenzja 0.4.1 + rzeczywisty E2E Android Chrome/IndexedDB w kontrolowanym profilu testowym. Nie integrować jeszcze z R12.
