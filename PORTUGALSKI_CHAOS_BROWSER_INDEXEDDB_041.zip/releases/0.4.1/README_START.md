# PORTUGALSKI CHAOS 0.4.1 — Integrity & Contract Hardening

**Uruchom:** `URUCHOM_PORTUGALSKI_CHAOS_0_4_1_HARDENING_OFFLINE.html`.

To wyłącznie eksperymentalna gałąź dwumisyjna. R12 pozostaje obowiązującą wersją gry. Nie zastępuj nim R12 i nie usuwaj danych ani poprzednich HTML. Program nie zawiera audio ani zasobów pobieranych z Internetu.

## Zakres wydania

Cztery naprawy A04-01/02/03/04 z niezależnego audytu Astry. Bez nowych misji, bez zmiany treści pytań, bez zmiany bazy R12, bez zmiany formatu zapisanych ocen, schematu 5 ani nazwy osobnej bazy 0.4. Poprawione komunikaty błędów i ochrona niezapisanego szkicu.

**Kompatybilność:** kod silnika nadal deklaruje `foundation-0.4.0`, katalog `registry-0.4.0`, IndexedDB `portugalski_chaos_foundation_v0_4_ODDZIELNA`, schemat 5, eksport `CHAOS_04_BACKUP`. Tak jest celowo: 0.4.1 jest poprawką wykonawczą bez migracji danych. Podczas uruchomienia na tym samym origin co 0.4, kod ma odczytywać wcześniejszy zapis. Nie zostało to jednak potwierdzone natywnym Browser E2E, więc wykonaj kopię przed testami na faktycznym profilu. Nie otwieraj równolegle starego 0.4 i 0.4.1 na tym samym profilu do czasu testów konfliktów kart.

## Co robić w razie nieudanego zapisu

1. Pozostaw kartę otwartą. Program nie powinien już twierdzić, że niezapisany szkic został zatwierdzony.
2. Wybierz `Pobierz bieżący szkic` i sprawdź, czy plik rzeczywiście pojawił się w Pobranych.
3. `Eksport zatwierdzonej historii JSON` pobiera **wyłącznie ostatni zatwierdzony** dziennik; nie traktuj go jako kopii niezapisanego szkicu.
4. Przy błędzie zapisu `Wczytaj zapis` wymaga wcześniej rozpoczętego pobierania szkicu oraz osobnego potwierdzenia. Nadal sam użytkownik musi sprawdzić rzeczywisty plik.

## Wykonane testy i granice

- Oryginalny suite silnika: 21 PASS.
- Nowe negatywne/regresyjne: 14 PASS.
- Stress: 60 sesji, 2145 przejść stanu, 657 prób; 60 prawidłowych backupów, 60 odrzuconych uszkodzonych.
- Chromium DOM z **adapterem pamięciowym**: dziewięć odrębnych kontroli PASS, bez native IndexedDB.
- Natywne `file://` BLOCKED (`ERR_BLOCKED_BY_ADMINISTRATOR`), osadzona strona ma `origin=null` i odmawia IndexedDB.
- Fizyczny Android, `content://`, rzeczywista trwałość po restarcie, konflikty kart i retencja 24 h: NOT RUN.

Nie interpretuj tych testów jako gwarancji braku utraty danych. Zobacz `RAPORT_QA_0_4_1.md`.

## Jak odtworzyć testy

```bash
node --test tests/engine.test.cjs
node --test tests/hardening.test.cjs
node tests/stress_replay.cjs
python tests/check_build.py
node probes.cjs     # potwierdza historyczne błędy W ZAMROŻONYM 0.4, NIE w 0.4.1
```

Oryginalne źródła 0.4 znajdują się w `baseline/`; raport Astry i oryginalny skrypt w `history/`. Nowe `src/` i wydany HTML to 0.4.1. `baseline/` nie był modyfikowany. `probes.cjs` ma tylko skorygowaną ścieżkę do `baseline/`.
