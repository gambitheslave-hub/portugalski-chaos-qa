# PORTUGALSKI CHAOS 0.4 — niezależny audyt Astry

Data: 18.10.2026. Badano zamrożony załącznik `PORTUGALSKI_CHAOS_FUNDAMENT_0_4_PAKIET.zip`. Nie poprawiano kodu produktu. Autor rozwoju: Sol; ten pakiet zawiera recenzję i reprodukcje.

## Werdykt
Wielomisyjna architektura działa w zakresie dostarczonych testów modelowych. Potwierdzono jednak **cztery luki**, w tym odrzucony szkic oznaczany jako zapisany oraz niedziałający eksport po błędzie transakcji. Nie zatwierdzam jeszcze fundamentu jako gotowego do większej rozbudowy wspólnego silnika. Zalecam punktową naprawę obsługi niepowodzeń i kontraktów walidacji, bez nowych misji. Integracja z R12 pozostaje zablokowana również przez brak natywnego QA.

Nie wykryto uszkodzenia istniejącej historii R12. R12 nie był otwierany ani testowany w tym przebiegu. Odrębna nazwa bazy 0.4 jest obecna w kodzie; nie jest to natywna certyfikacja izolacji baz.

## Wyniki rzeczywiście wykonane tutaj

| Kontrola | Wynik | Dowód |
|---|---|---|
| Manifest oryginalnego pakietu | **38/38 PASS** | results/MANIFEST.log |
| Dostarczony zestaw silnika | **21 PASS / 0 FAIL** | results/ENGINE.log |
| Dostarczony deterministyczny stress | **PASS: 60 sesji, 2145 przejść, 657 prób, 60 poprawnych kopii i 60 odrzuconych kopii** | results/STRESS.log; ten sam seed i generator co u Sola |
| Przebudowa HTML | **PASS**, identyczny SHA256 | results/BUILD.log; `5a4487d6f5209f7dbc89a92951dcb139c07fa4b9df4ac532a8ffd7d1c0a6cc7e` |
| Cztery własne reprodukcje | **4 problemy odtworzone** | results/INDEPENDENT_PROBES.json, probes.cjs |
| Chromium DOM Sola w tym środowisku | **BLOCKED** | Python: brak modułu playwright; results/DOM.log |
| Natywny test przeglądarki | **BLOCKED** | Python: brak playwright; dodatkowa próba Node: brak executable Chromium; results/NATIVE.log i NATIVE_NODE.log |
| Android/content://, quota, zabicie procesu, restart prawdziwej przeglądarki | **NOT RUN** | brak wykonania |
| R12: 49 testów / 1436 rekordów | **NOT RUN w tym audycie** | w załączniku znajdują się historyczne logi Sola; samych źródeł R12 w tym wydaniu nie ma |
| Niezależny audyt nauczycielski PT-BR i empiryczna retencja | **NOT RUN** | nie przyznano zaliczenia |

Nie sumować 21 testów, 2145 przejść i czterech reprodukcji w jedną liczbę PASS. Stress jest powtórzeniem tego samego generatora, nie nowym niezależnym fuzzingiem. Własne próby UI uruchamiają kod wyjęty z HTML w Node z minimalnym symulowanym DOM i magazynem. Nie zastępują transakcji IndexedDB.

## A04-03 — P1: odrzucony szkic przedstawiony jako zatwierdzony

**Źródło:** src/ui.js, send() (linie 11–12), obsługa pause (37) i refresh (40); src/engine.js, limit dziennika w reduce().

**Reprodukcja wykonana:**
1. SELECT SC04.STORM; START bez lekcji; kolejne legalne SELECT aż do globalnej rewizji 10000. Powstały stan i wszystkie 10000 zdarzeń przechodzą validateBackup — to stan osiągalny przez reduktor, nie ręcznie podmieniony numer.
2. W formularzu wpisać `UNSAVED_AT_LIMIT` i wybrać pauzę. flush() kolejkuje DRAFT.
3. Reducer odrzuca zapis z powodu limitu. Catch nie ustawia `failed` ani innego trwałego stanu niezapisanego szkicu. Finally ustawia tekst: „Wszystkie zlecone zmiany zatwierdzone.”
4. Pauza pojawia się i oznajmia, że zapis potwierdzono, choć stan trwały nadal ma draft=null.
5. Powrót zachowuje tekst w pamięci. Następnie „Odśwież zapis” usuwa go bez potwierdzenia zabezpieczenia szkicu, ponieważ failed=false.

To nie jest dowód fizycznego uszkodzenia IndexedDB. To odtworzona utrata niezapisanego tekstu po odczycie oraz fałszywe zapewnienie o zapisie na granicy obsługiwanego limitu. Limit osiągnięto sztucznie wieloma wyborami misji; nie twierdzimy, że zwykła krótka sesja ma 10000 zdarzeń.

**Kryterium naprawy:** odrzucony DRAFT zachowuje jawny dirty/error i treść; pauza nie deklaruje potwierdzonego zapisu; odświeżenie wymaga zabezpieczenia szkicu. Rozdzielić odrzucenie błędnej odpowiedzi od niepowodzenia zapisu szkicu. Testować również odrzucenie DRAFT inne niż błąd S.commit, nie tylko awarię adaptera.

## A04-04 — P1: eksport pozornie dostępny po awarii zapisu

**Źródło:** src/ui.js lock() (8) oraz handler export (38).

**Reprodukcja wykonana:** rozpocząć misję, wpisać szkic, wymusić odrzucenie commit (`INJECTED_CONFLICT` w symulowanym magazynie). lock() pozostawia przycisk eksportu aktywny. Kliknięcie nie wywołuje backup ani pobierania: handler wykonuje `if(!db||failed)return`. Nie informuje, dlaczego nic się nie dzieje. W próbie liczba wywołań backup=0 i pobrań=0.

Pobieranie bieżącego szkicu jest odrębną ścieżką i pozostaje dostępne; nie twierdzimy, że wszystkie możliwości zabezpieczenia danych są zablokowane.

**Kryterium naprawy:** albo dopuścić eksport ostatniej zatwierdzonej, zwalidowanej historii mimo niezapisanego szkicu i jasno rozdzielić oba pliki, albo wyłączyć eksport z konkretnym wyjaśnieniem. Aktywny przycisk nie może milcząco odrzucać działania. Test powinien weryfikować rzeczywiste wywołanie backup/pobrania lub widoczny komunikat, nie sam stan enabled.

## A04-01 — P2: ujemna rewizja przechodzi walidator

**Źródło:** src/engine.js assertValid() (32).

**Wykonane:** `s=E.fresh(); s.revision=-1; E.assertValid(s)` zwraca true. Następnie legalny SELECT daje `event.id=0`, sprzeczne z numeracją dziennika zaczynającą się od 1. Warunek sprawdza isSafeInteger i <=10000, ale nie >=0.

**Granica:** ta próba podaje celowo wadliwy stan bezpośrednio do API silnika. Nie pochodzi ze zwykłej nawigacji. Pełny validateBackup odtwarza historię od fresh i chroni import przed takim podstawieniem. To luka kontraktu walidatora/reduktora, nie wykazany exploit importu.

**Kryterium:** odrzucenie -1 i innych ujemnych rewizji przez assertValid i reduce przed zmianą stanu; zachowanie poprawnej obsługi 0 i 10000.

## A04-02 — P2: walidator katalogu akceptuje wadliwe metadane

**Źródło:** src/engine.js validateCatalog() (12–15); src/catalog.js eksport katalogu.

**Wykonane w pamięci procesu, bez modyfikacji plików:** w pierwszej misji ustawiono jednocześnie `version=-7`, `competency_id=''`, `target_level=123`, `prerequisite_ids=[null]`. validateCatalog() nadal zwrócił true. Następnie przywrócono oryginalne wartości. Samo exact() sprawdza obecność kluczy, nie semantykę wszystkich wartości.

Obecny opublikowany katalog nie zawiera tych podstawionych wartości. Problem dotyczy deklarowanej bariery bezpieczeństwa dla kolejnych modułów. Object.freeze eksportu jest płytkie; walidator nie jest kompletnym kontraktem wejścia.

**Kryterium:** osobne negatywne testy dla wersji, pustych/nieprawidłowych ID, typu poziomu i elementów prerequisite_ids. Dodatkowo sprawdzić zgodność answers z formsByTense i zdefiniować zasady referencji do zewnętrznych kompetencji. Nie wymagać, aby każde wymaganie wstępne było już grywalną misją, jeśli katalog kompetencji jest szerszy od gry.

## Ocena architektury i dydaktyki
- Realny postęp: katalog dwóch misji, jeden reduktor, rozdzielone przebiegi i jeden globalny dziennik. Pełny replay kopii jest mocniejszą kontrolą niż samo sprawdzanie JSON.
- Trwałe identyfikatory i wersjonowanie są deklarowane, lecz na razie katalog jest zaszyty w jednej wersji aplikacji. Nie ma planu kompatybilności nowych rubryk ani migracji — prawidłowo nie należy ich dorabiać po cichu.
- Nazwa „generyczny silnik” ma ograniczony zakres: bieżące kontrakty wymuszają dokładnie cztery zadania, unikalną kompetencję na misję i jedną sesję na misję. To ograniczenia obecnego fundamentu, nie nowo odkryte awarie.
- MS04 zachowuje rozdział aspektu i odmiany; NOT_ATTEMPTED i UNVERIFIED nie dają fikcyjnego zaliczenia.
- Dla de/para/por jawnie zastosowano FUNCTION_WORD_CONTEXT, więc dokładne powtarzanie krótkich przyimków nie wystarcza do oceny niezależności zadania. Wariant odroczony nadal ma tę samą relację „por e-mail” co lekcja. Jest to powtórka zastosowania znanej konstrukcji; nie przypisywać jej dowodu swobodnego transferu. Nie wydajemy tu niezależnego językowego certyfikatu poprawności banku.
- Ekspozycje są przechowywane per misja; nie jest to jeszcze globalny model przenikania materiału między kompetencjami. Przy dwóch ścieżkach to jawne ograniczenie do uwzględnienia przed skalowaniem, nie odtworzony błąd zaliczenia kompetencji.

## Polecenie naprawcze dla Sola
Na zamrożonej bazie 0.4 odtworzyć probes.cjs; poprawić A04-03 i A04-04, następnie A04-01 i A04-02. Dodać regresje oczekujące poprawnego zachowania, zachowując ten pakiet reprodukcji jako historię wykrytych usterek. Nie zmieniać R12, schematu zapisanych ocen ani treści misji w ramach tej naprawy. Jeśli poprawka wymaga zmiany formatu, opisać zgodność przed wydaniem. Dostarczyć poprawiony artefakt i osobne logi. Natywne commit/abort/restart/konflikt kart/quota/Android pozostają osobną bramką.

## Odtwarzanie audytu
Rozpakuj paczkę audytu. Obok probes.cjs znajduje się niezmieniony katalog PORTUGALSKI_CHAOS_FUNDAMENT_0_4. Uruchom `node probes.cjs`. Skrypt ma zakończyć się kodem 0 tylko po odtworzeniu wszystkich czterech problemów obecnego wydania — NIE po ich naprawieniu. JSON to dowody usterek, nie lista zaliczonych kryteriów produktu.
