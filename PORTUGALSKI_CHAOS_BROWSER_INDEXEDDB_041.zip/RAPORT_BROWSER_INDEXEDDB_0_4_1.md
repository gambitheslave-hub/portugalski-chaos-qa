# RAPORT BROWSER / INDEXEDDB 0.4.1

Statusy pochodzą z wykonania scenariuszy albo z jawnie opisanej blokady infrastruktury. Testy Node nie są dowodem natywnego IndexedDB.

## Kontekst

```json
{
  "timestamp_utc": "2026-10-18T17:11:08.798798+00:00",
  "repository": "gambitheslave-hub/portugalski-chaos-qa",
  "head_commit_sha": "792c6a8fa588eeb4c878f6d98848af8eaed4464a",
  "commit_scope": "LOCAL UNPUSHED infrastructure commit; never executed in GitHub Actions",
  "base_commit_sha": "615965fa919e43ef49a8fd24c83ce82eb0116e24",
  "branch": "qa/browser-indexeddb-041",
  "run_id": null,
  "run_url": null,
  "pr_url": null,
  "chromium_version": "NOT RUN",
  "system": "GitHub Actions runner: NOT RUN; local Node tooling: Debian GNU/Linux 13 x86_64",
  "html_sha256": "98033fbebc8c5fefafdaa2d8e07e41faee25d5fc9681a132077b6417a9f75b87",
  "archive_sha256": "079234f995485697579d64741742758b345dd5bba9285afde8649546b6ba3b1f",
  "scope": "No native browser execution; not an IndexedDB certification",
  "remote_actions_runs_observed": 0
}
```

## Macierz

| Test | Status | Natywny IndexedDB w wykonaniu |
| --- | --- | --- |
| T01 — Commit i restart procesu | BLOCKED | False |
| T02 — Atomowy abort | BLOCKED | False |
| T03 — Konflikt dwóch kart | BLOCKED | False |
| T04 — Ochrona szkicu | BLOCKED | False |
| T05 — Eksport i import JSON | BLOCKED | False |
| T06 — Uszkodzona kopia | BLOCKED | False |
| T07 — Zgodność 0.4 → 0.4.1 | BLOCKED | False |
| T08 — Dwie misje po restarcie | BLOCKED | False |
| T09 — Bez zewnętrznej sieci | BLOCKED | False |
| T10 — Limit szkicu | BLOCKED | False |
| ANDROID_EMULATOR — Oddzielny emulator Android | NOT RUN | False |

## T01 — BLOCKED

Oczekiwane: Zatwierdzony stan i dziennik identyczne po zakończeniu procesu Chromium i uruchomieniu nowego PID z tym samym profilem i originem.

Rzeczywiste:

```text
BLOCKED: POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs => HTTP 403 FORBIDDEN: Resource not accessible by integration. CLI fallback: proxyconnect tcp, socket: operation not permitted. Branch not published; PR and Actions run not created.
```

Dowody: evidence/publication-error.json, evidence/cli-access-error.txt, evidence/github-actions-runs.json

## T02 — BLOCKED

Oczekiwane: Abort natywnej transakcji po success obu provisional requests; brak zmiany kv/state i events.

Rzeczywiste:

```text
BLOCKED: POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs => HTTP 403 FORBIDDEN: Resource not accessible by integration. CLI fallback: proxyconnect tcp, socket: operation not permitted. Branch not published; PR and Actions run not created.
```

Dowody: evidence/publication-error.json, evidence/cli-access-error.txt, evidence/github-actions-runs.json

## T03 — BLOCKED

Oczekiwane: Zapis ze starą rewizją odrzucony; historia zwycięzcy niezmieniona, szkic przegranej karty dostępny.

Rzeczywiste:

```text
BLOCKED: POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs => HTTP 403 FORBIDDEN: Resource not accessible by integration. CLI fallback: proxyconnect tcp, socket: operation not permitted. Branch not published; PR and Actions run not created.
```

Dowody: evidence/publication-error.json, evidence/cli-access-error.txt, evidence/github-actions-runs.json

## T04 — BLOCKED

Oczekiwane: Zatwierdzony szkic przeżywa pauzę, pomoc i restart. Przy abort niezapisany tekst zostaje w UI i pobranym pliku; refresh wymaga zabezpieczenia szkicu.

Rzeczywiste:

```text
BLOCKED: POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs => HTTP 403 FORBIDDEN: Resource not accessible by integration. CLI fallback: proxyconnect tcp, socket: operation not permitted. Branch not published; PR and Actions run not created.
```

Dowody: evidence/publication-error.json, evidence/cli-access-error.txt, evidence/github-actions-runs.json

## T05 — BLOCKED

Oczekiwane: Pobrany plik zawiera zatwierdzony stan i dziennik; import do pustego profilu odtwarza je dokładnie i przeżywa restart.

Rzeczywiste:

```text
BLOCKED: POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs => HTTP 403 FORBIDDEN: Resource not accessible by integration. CLI fallback: proxyconnect tcp, socket: operation not permitted. Branch not published; PR and Actions run not created.
```

Dowody: evidence/publication-error.json, evidence/cli-access-error.txt, evidence/github-actions-runs.json

## T06 — BLOCKED

Oczekiwane: Uszkodzony JSON odrzucony w pustej i zapełnionej bazie; surowe dane obu object stores niezmienione.

Rzeczywiste:

```text
BLOCKED: POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs => HTTP 403 FORBIDDEN: Resource not accessible by integration. CLI fallback: proxyconnect tcp, socket: operation not permitted. Branch not published; PR and Actions run not created.
```

Dowody: evidence/publication-error.json, evidence/cli-access-error.txt, evidence/github-actions-runs.json

## T07 — BLOCKED

Oczekiwane: Historia i szkic z niezmienionego HTML 0.4 odczytane bez zmian przez HTML 0.4.1 na identycznym originie.

Rzeczywiste:

```text
BLOCKED: POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs => HTTP 403 FORBIDDEN: Resource not accessible by integration. CLI fallback: proxyconnect tcp, socket: operation not permitted. Branch not published; PR and Actions run not created.
```

Dowody: evidence/publication-error.json, evidence/cli-access-error.txt, evidence/github-actions-runs.json

## T08 — BLOCKED

Oczekiwane: Próby i szkice obu misji zachowane we wspólnym dzienniku po restarcie; przełączenie misji zachowuje wcześniejsze zdarzenia.

Rzeczywiste:

```text
BLOCKED: POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs => HTTP 403 FORBIDDEN: Resource not accessible by integration. CLI fallback: proxyconnect tcp, socket: operation not permitted. Branch not published; PR and Actions run not created.
```

Dowody: evidence/publication-error.json, evidence/cli-access-error.txt, evidence/github-actions-runs.json

## T09 — BLOCKED

Oczekiwane: Przy blokadzie żądań spoza localhost UI i natywny zapis działają po restarcie; kontrolny fetch zewnętrzny odrzucony.

Rzeczywiste:

```text
BLOCKED: POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs => HTTP 403 FORBIDDEN: Resource not accessible by integration. CLI fallback: proxyconnect tcp, socket: operation not permitted. Branch not published; PR and Actions run not created.
```

Dowody: evidence/publication-error.json, evidence/cli-access-error.txt, evidence/github-actions-runs.json

## T10 — BLOCKED

Oczekiwane: Przy rzeczywistym limicie 10000 zdarzeń szkic nie jest fałszywie potwierdzony; stan i dziennik niezmienione, szkic można pobrać.

Rzeczywiste:

```text
BLOCKED: POST /repos/gambitheslave-hub/portugalski-chaos-qa/git/refs => HTTP 403 FORBIDDEN: Resource not accessible by integration. CLI fallback: proxyconnect tcp, socket: operation not permitted. Branch not published; PR and Actions run not created.
```

Dowody: evidence/publication-error.json, evidence/cli-access-error.txt, evidence/github-actions-runs.json

## ANDROID_EMULATOR — NOT RUN

Oczekiwane: Po sukcesie T01-T10: natywny zapis w Chrome emulatora i identyczny odczyt po force-stop/relaunch.

Rzeczywiste:

```text
Warunek sukcesu głównych testów nie został osiągnięty z powodu blokady GitHub. Nie uruchomiono AVD, Chrome Android ani fizycznego urządzenia.
```

Dowody: evidence/publication-error.json

## Granice

Zakres: Linux Chromium przez HTTP localhost. `file://` i Android `content://`: NOT RUN. Retencja 24 h: NOT RUN. Test kontrolowanego abortu nie symuluje magazynu danych; operacje i rollback wykonuje natywne IndexedDB. Test limitu dotyczy 10000 zdarzeń aplikacji, nie fizycznego wyczerpania dysku.

Emulator Android jest osobnym jobem, uruchamianym wyłącznie po sukcesie głównych testów. Nie jest fizycznym telefonem.

## Faktycznie wykonane przygotowanie i regresja

- ZIP rzeczywiście dostępny, 432705 bajtów; CRC PASS.
- SHA-256 HTML zgodny z wymaganym: `98033fbebc8c5fefafdaa2d8e07e41faee25d5fc9681a132077b6417a9f75b87`.
- Manifest 0.4.1: 82/82 PASS; baseline: 38/38 PASS.
- Wszystkie 83 pliki `releases/0.4.1/` identyczne bajtowo z ZIP, włącznie ze źródłami, raportami, testami i historią.
- Node: 21/21 silnika i 14/14 hardening PASS, zero skipped/cancelled.
- Stress: 60 sesji, 2145 przejść, 657 prób; 60 poprawnych i 60 odrzuconych uszkodzonych backupów.
- Build odtwarzalny: PASS, identyczny HTML.
- Składnia Python, Bash, CJS, wstrzykniętych wyrażeń JavaScript, import API Playwright i struktura YAML: PASS kontroli statycznej.
- Logi rzeczywistej lokalnej regresji: `evidence/local-node-20261018T170749Z/`. To nie są logi certyfikacji przeglądarki.

## Stan operacji GitHub

| Etap | Wynik | Przyczyna / dowód |
| --- | --- | --- |
| Odczyt repozytorium i ZIP | PASS | Konektor GitHub, dokładne bajty i obiekty Git |
| Utworzenie zdalnej gałęzi QA | BLOCKED | HTTP 403 `Resource not accessible by integration`, POST `/git/refs` |
| CLI jako droga alternatywna | BLOCKED | Proxy socket: `operation not permitted` |
| Push / PR | NOT RUN | Brak działającego uprawnionego kanału zapisu |
| Wyzwolenie i oczekiwanie na Actions | NOT RUN | Brak opublikowanej gałęzi i workflow; odczyt API wskazuje 0 przebiegów |
| Odczyt jobów i pobranie ich artefaktów | NOT RUN | Run ID nie istnieje; nie ma artefaktów do pobrania |
| Retest w Actions | NOT RUN | Wykonanie blokuje dostęp, nie zaobserwowano awarii uruchomionych testów |
| Emulator Android | NOT RUN | Nie osiągnięto warunku sukcesu głównego Chromium |

## Zachowanie integralności

Oryginalny ZIP, README, wydany HTML i wszystkie źródła oraz historyczne logi pozostały bez zmian. R12 nie zmieniono. Nie wykonano migracji. Trzy końcowe podwójne spacje w historycznym raporcie Markdown zachowano dokładnie z ZIP; nie wykonano automatycznej korekty whitespace.

## Kontynuacja bez hasła i tokenu

Instrukcja: `docs/BROWSER_INDEXEDDB_0_4_1.md`. Sprawdzony patch i bundle zachowują pracę lokalną. Na uprawnionym klonie można zastosować patch na osobnej gałęzi, zatwierdzić go i wykonać `bash scripts/publish_browser_qa.sh`. Skrypt używa istniejącego uwierzytelnienia Git/gh, publikuje wyłącznie gałąź QA, tworzy draft PR, oczekuje na rzeczywisty run oraz pobiera jego logi i artefakty. Nie scala zmian do main. Pierwsze wykonanie musi zweryfikować także poprawność nowej infrastruktury; obecny raport nie jest certyfikacją IndexedDB.
